# Information requirements for fossil fuel retirement decisions

This directory contains the frozen analytical inputs, calculation code, tests,
and figure source data for the Omega manuscript. It is independent of the older
analyses elsewhere in Cap_sub_energy. Run commands from this directory. The first command checks and expands data.zip and expected.zip automatically; no manual extraction is needed.

## Reproduction

Use Python 3.12 and the versions in requirements.txt. The recorded reference
environment is Python 3.12.4, NumPy 2.2.6, SciPy 1.18.0 and its bundled HiGHS
1.12.0. No commercial solver, account, API key or network request is required.

```sh
python -m venv .venv
python -m pip install -r requirements.txt
python reproduce.py --mode check
python reproduce.py --mode tests
python reproduce.py --mode verify
python reproduce.py --mode rerun
```

Activate the virtual environment before installing. On Windows use
`.venv/Scripts/activate`; on macOS or Linux use `. .venv/bin/activate`.
The last command recomputes project windows, annual portfolios, chronological
calibration and sensitivities, stability diagnostics, concealed-plan review,
and fixed-portfolio minimum record sets. It compares scientific JSON values
and CSV bytes with expected/. A run report is saved in run_results/.
Solver/platform changes can select different tied optima; use the recorded
environment for the exact-result comparison rather than relaxing it silently.

## Analytical starting point

The annual analysis starts from processed panels in data/processed/phase84,
including 152 paired observations for 65 generators. The 296-generator source
cohort is larger than this measurement-supported sample. The origin ledger,
annual validation records and alternative panels are included. Paired forecast
errors for all three support specifications are recalculated. The upstream
EIA workbook and national CEMS reconstruction is not rerun by this entry point.

The three project-window cases retain the original panel values and raw daily
CEMS columns for seven generators. CASE_SUBSETS.json records the exact retained
plant/unit pairs and hashes of the original state files. Other units were
removed without changing retained observations. The exclusive-link crosswalk
is subsetted to those pairs. Official clauses, dates, source URLs, page locators
and upstream PDF-check hashes are retained in data/raw/phase82/orders.json,
data/raw/phase83/cases.json and source_checks.json. Source-document recovery and
legal interpretation are upstream inputs, not newly inferred by the replay.

## Code and checks

Scientific modules and original runners are copied without alteration. The
public reproduce.py replaces only private development-archive integrity checks
with INPUTS.json, and replaces the source-PDF recheck with the frozen source
check ledger. All numerical functions, case calculations and independent
measurement checks remain the original functions. The archive-size fields
protected_files, protected_file_count and frozen_files are excluded from JSON
comparison; scientific fields, solver diagnostics and query counts are not.
The historic phase numbers in file paths are stable provenance identifiers.
Use reproduce.py, not the old freeze or upstream reconstruction commands.

Expected results include 108 annual settings, 81 chronological calibrations,
216 margin diagnostics and 1,512 review paths. The minimum-record calculation
uses each adaptive path's own returned portfolio as its fixed offline target.
It does not optimise an adaptive policy. Queried answers are updated plan
forecasts; observed outcomes only score a completed replay. Settings are
sensitivities on repeated observations, not independent samples.

FIGURE_SOURCES.json maps the six main figures to machine-readable values.
The reviewed figure PDFs and numeric/table inputs are provided unchanged.
INPUTS.json protects code, specifications, starting panels, source data and
expected outputs. RELEASE_MANIFEST.json inventories the whole delivered tree.
Do not change INPUTS.json to conceal a failed numerical comparison.

## Sources

EIA monthly inventory: https://www.eia.gov/electricity/data/eia860m/
EIA annual generation: https://www.eia.gov/electricity/data/eia923/
EPA monitored emissions: https://campd.epa.gov/
Case document URLs and page locators are recorded in the case input files.
The saved 2025 EIA file was an early release and the panel is retrospective,
not a publication-vintage prediction trial. CEMS short tons are converted with
0.90718474; EIA net MWh and CEMS gross MWh are not interchangeable.
