"""Public entry point: reproduce the analyses from the released frozen panels."""
import argparse
import csv
import hashlib
import importlib
import json
import math
from pathlib import Path
import platform
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, allow_nan=False) + '\n',
                    encoding='utf-8')


def extract_archives(root=ROOT):
    index = root / 'ARCHIVES.json'
    if not index.exists():
        return 0
    count = 0
    for name, expected in read(index)['archives'].items():
        archive = root / name
        if name not in {'data.zip', 'expected.zip'} or digest(archive) != expected:
            raise ValueError('Invalid or changed release archive')
        with zipfile.ZipFile(archive) as source:
            members = source.infolist()
            if sum(m.file_size for m in members) > 1024**3:
                raise ValueError('Archive expansion exceeds release limit')
            for member in members:
                path = Path(member.filename)
                target = (root / path).resolve()
                if (not target.is_relative_to(root.resolve()) or path.is_absolute()
                    or '..' in path.parts or path.parts[0] not in {'data', 'expected'}
                    or (member.external_attr >> 16) & 0o170000 == 0o120000):
                    raise ValueError('Unsafe release archive member')
                if member.is_dir():
                    continue
                if not target.exists():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with source.open(member) as incoming, target.open('wb') as outgoing:
                        import shutil
                        shutil.copyfileobj(incoming, outgoing)
                    count += 1
    return count


def validate_inputs(root=ROOT):
    extract_archives(root)
    files = read(root / 'INPUTS.json')['files']
    for name, expected in files.items():
        target = (root / name).resolve()
        if not target.is_relative_to(root.resolve()):
            raise ValueError('Input outside release: ' + name)
        if not target.is_file() or digest(target) != expected:
            raise ValueError('Changed or missing release input: ' + name)
    return len(files)


def scientific_view(value):
    # Only archive-size metadata differs from the full private development tree.
    if isinstance(value, dict):
        return {k: scientific_view(v) for k, v in value.items()
                if k not in {'protected_files', 'protected_file_count', 'frozen_files'}}
    if isinstance(value, list):
        return [scientific_view(v) for v in value]
    return value


def compare_expected(names):
    checked = []
    for name in names:
        current, expected = ROOT / name, ROOT / 'expected' / name
        if name.endswith('.json'):
            if scientific_view(read(current)) != scientific_view(read(expected)):
                raise ValueError('Scientific result differs: ' + name)
        elif current.read_bytes() != expected.read_bytes():
            raise ValueError('CSV differs: ' + name)
        checked.append(name)
    return checked


def annual_support():
    from scripts.run_phase84_support import paired_error_summary, csv_rows
    from transition_assets.phase85_integration import panel_counts
    root = ROOT / 'data/processed'
    ledger = csv_rows(root / 'phase84/origin_ledger.csv')
    for row in ledger:
        row['year'] = int(row['year'])
    expected = read(root / 'phase84/results.json')
    modes = {'original_M': root / 'phase73/panel.json',
             'annual_M_AM': root / 'phase84/annual_pair_panel.json',
             'reported_annual': root / 'phase84/reported_annual_pair_panel.json'}
    errors = {}
    for mode, source in modes.items():
        panel = read(source)
        rows = [r for r in ledger if r['mode'] == mode]
        value = paired_error_summary(panel, rows)
        if value != expected['sample_modes'][mode]['paired_errors']:
            raise ValueError('Paired error summary differs: ' + mode)
        errors[mode] = value
    counts = panel_counts(read(modes['reported_annual']))
    if (counts['rows'], counts['generators'], counts['plants'], counts['exit_rows']) != (152, 65, 37, 12):
        raise ValueError('Published panel counts differ')
    write(ROOT / 'run_results/annual_support.json', dict(status='pass', panel=counts,
          paired_errors=errors, scope='recalculation from frozen processed panels'))
    return 3


def case_module():
    module = importlib.import_module('scripts.run_phase83_action_windows')
    module.preserved = validate_inputs
    # Source-document checks were completed upstream. The release freezes the
    # clause ledger and original check metadata; it does not redistribute PDFs.
    module.source_check = lambda: read(ROOT / 'data/raw/phase83/source_checks.json')
    return module


def verify_existing():
    validate_inputs()
    annual_support()
    cases = case_module()
    computed = cases.compute()
    cases.verify(computed)
    if scientific_view({k: v for k, v in computed.items() if k != 'daily_records'}) != scientific_view(read(cases.OUT / 'results.json')):
        raise ValueError('Project-window calculation differs')
    checked = []
    for phase in [85, 86, 87, 89]:
        module = importlib.import_module({85: 'scripts.run_phase85_integration',
            86: 'scripts.run_phase86_margins', 87: 'scripts.run_phase87_review',
            89: 'scripts.run_phase89_information'}[phase])
        module.preserved = validate_inputs
        module.verify()
        checked.extend(compare_expected(['data/processed/phase%d/%s' % (phase, n)
                                         for n in module.PRODUCTS]))
    checked.extend(compare_expected(['data/processed/phase83/' + n for n in
        ['results.json', 'snapshots.csv', 'comparisons.csv', 'unit_totals.csv', 'daily_records.csv']]))
    return checked


def rerun():
    validate_inputs()
    annual_support()
    cases = case_module()
    result = cases.compute()
    cases.emit(result, cases.OUT)
    cases.verify(result)
    names = ['data/processed/phase83/' + n for n in
             ['results.json', 'snapshots.csv', 'comparisons.csv', 'unit_totals.csv', 'daily_records.csv']]
    compare_expected(names)
    for phase, name in [(85, 'integration'), (86, 'margins'), (87, 'review'), (89, 'information')]:
        suffix = {85: 'integration', 86: 'margins', 87: 'review', 89: 'information'}[phase]
        module = importlib.import_module('scripts.run_phase%d_%s' % (phase, suffix))
        module.preserved = validate_inputs
        print('Recomputing', name, flush=True)
        module.run()
        if phase != 85:
            module.verify()
        products = ['data/processed/phase%d/%s' % (phase, p) for p in module.PRODUCTS]
        compare_expected(products)
        names.extend(products)
    return names


def run_tests():
    subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests',
                    '-p', 'test_*.py'], cwd=ROOT, check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['check', 'tests', 'verify', 'rerun'], default='check')
    args = parser.parse_args()
    count = validate_inputs()
    if args.mode == 'tests':
        run_tests()
        return
    if args.mode == 'check':
        print('Release inputs verified:', count)
        return
    checked = verify_existing() if args.mode == 'verify' else rerun()
    import numpy
    import scipy
    from scipy.optimize._highspy._core import HIGHS_VERSION_MAJOR, HIGHS_VERSION_MINOR, HIGHS_VERSION_PATCH
    report = dict(status='pass', mode=args.mode, input_files=count,
        compared_products=checked, python=sys.version, numpy=numpy.__version__, scipy=scipy.__version__,
        highs='%d.%d.%d' % (HIGHS_VERSION_MAJOR, HIGHS_VERSION_MINOR, HIGHS_VERSION_PATCH),
        platform=platform.platform(), comparison='exact parsed JSON and exact CSV bytes; only archive-size metadata excluded')
    write(ROOT / ('run_results/' + args.mode + '.json'), report)
    print('Scientific reproduction passed:', len(checked), 'products', flush=True)


if __name__ == '__main__':
    main()
