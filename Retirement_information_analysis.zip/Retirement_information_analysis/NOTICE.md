# Use and source attribution

This supplement does not set a new software licence. Retain any licence applying to the host repository; authors should select an explicit licence before public reuse is granted. Official observations and documents retain their original source terms. Source PDFs are referenced, not redistributed.
