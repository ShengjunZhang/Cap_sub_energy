"""Date-filtered order windows, distinct from causal abatement benefits."""
from datetime import date, datetime, time, timedelta
import math
from zoneinfo import ZoneInfo

LOCAL = ZoneInfo('America/Detroit')
SHORT_TON_TO_METRIC_TONNE = 0.90718474


def _date(value):
    return date.fromisoformat(value)


def _instant(value):
    result = datetime.fromisoformat(value)
    if result.tzinfo is None:
        raise ValueError('An explicit source timezone is required')
    return result


def _midnight(day):
    return datetime.combine(day, time(), LOCAL)


def validate_orders(orders):
    ids = set()
    for order in orders:
        if order['id'] in ids:
            raise ValueError('Duplicate order ID')
        ids.add(order['id'])
        issued, start, end = (_instant(order[k]) for k in ('issued', 'effective', 'expires'))
        if not issued <= start < end:
            raise ValueError('Invalid order chronology')
    return orders


def known_orders(orders, asof):
    validate_orders(orders)
    day = _date(asof)
    return sorted([r for r in orders if _instant(r['issued']).astimezone(LOCAL).date() <= day],
                  key=lambda r: (_instant(r['issued']), r['id']))


def closure_lower_bound(orders, action_date):
    """Earliest daily action date not blocked for irreversible closure."""
    validate_orders(orders)
    action = _date(action_date)
    remaining = [_instant(r['expires']) for r in orders
                 if _instant(r['expires']) > _midnight(action)]
    if not remaining:
        return action.isoformat()
    # A known future availability obligation also prevents irreversible closure now.
    expiry = max(remaining).astimezone(LOCAL)
    day = expiry.date()
    if expiry > _midnight(day):
        day += timedelta(days=1)
    return max(action, day).isoformat()


def full_day_membership(orders, day):
    validate_orders(orders)
    d = _date(day)
    start, end = _midnight(d), _midnight(d + timedelta(days=1))
    inside, partial = [], []
    for order in orders:
        a, b = _instant(order['effective']), _instant(order['expires'])
        if a <= start and end <= b:
            inside.append(order['id'])
        elif a < end and start < b:
            partial.append(order['id'])
    return sorted(inside), sorted(partial)


def forecast_window(orders, asof, annual_tonnes, year, plan_end_inclusive):
    if not math.isfinite(annual_tonnes) or annual_tonnes < 0:
        raise ValueError('Invalid annual forecast')
    origin = _date(asof)
    first, end = date(year, 1, 1), date(year + 1, 1, 1)
    if not first - timedelta(days=1) <= origin < end:
        raise ValueError('Snapshot outside the specified year')
    action = max(first, origin + timedelta(days=1))
    known = known_orders(orders, asof)
    lower = _date(closure_lower_bound(known, action.isoformat()))
    total_days = (end - action).days
    outside_days = max(0, (end - lower).days)
    plan_next = _date(plan_end_inclusive) + timedelta(days=1)
    cutoff_days = max(0, (min(end, plan_next) - action).days)
    rate = annual_tonnes / (end - first).days
    return {'asof': asof, 'action_date': action.isoformat(),
            'known_orders': [r['id'] for r in known],
            'closure_lower_bound': lower.isoformat(),
            'remaining_days': total_days, 'outside_blocking_days': outside_days,
            'remaining_forecast_tonnes': rate * total_days,
            'known_blocking_forecast_tonnes': rate * (total_days - outside_days),
            'outside_blocking_forecast_tonnes': rate * outside_days,
            'date_cutoff_forecast_tonnes': rate * cutoff_days,
            'annual_rate_tonnes_per_day': rate}


def _number(value):
    if value is None or not str(value).strip():
        return None
    result = float(value)
    if not math.isfinite(result) or result < 0:
        raise ValueError('Invalid nonnegative daily value')
    return result


def clean_daily_record(row):
    day = _date(row['Date'])
    hours = _number(row['Sum of the Operating Time'])
    if hours is not None and hours > 24:
        raise ValueError('Daily operating hours exceed24')
    co2 = _number(row['CO2 Mass (short tons)'])
    gross = _number(row['Gross Load (MWh)'])
    structural = co2 is None and hours == 0
    if structural:
        co2 = 0.
    if gross is None and hours == 0:
        gross = 0.
    return {'facility_id': str(row['Facility ID']), 'unit': str(row['Unit ID']),
            'date': day.isoformat(), 'operating_hours': hours,
            'co2_tonnes': None if co2 is None else co2 * SHORT_TON_TO_METRIC_TONNE,
            'gross_mwh': gross, 'structural_co2_zero': structural,
            'positive_co2_zero_hours': hours == 0 and co2 is not None and co2 > 0}


def index_daily(records):
    result = {}
    for row in records:
        key = (row['facility_id'], row['unit'], row['date'])
        if key in result:
            raise ValueError('Duplicate facility/unit/day')
        result[key] = row
    return dict(sorted(result.items()))


def sum_records(records):
    records = list(records)
    missing = sum(r['co2_tonnes'] is None for r in records)
    missing_gross = sum(r['gross_mwh'] is None for r in records)
    missing_hours = sum(r['operating_hours'] is None for r in records)
    return {'unit_days': len(records), 'missing_co2_unit_days': missing,
            'missing_gross_unit_days': missing_gross, 'missing_hours_unit_days': missing_hours,
            'co2_tonnes': None if missing else math.fsum(r['co2_tonnes'] for r in records),
            'gross_mwh': None if missing_gross else math.fsum(r['gross_mwh'] for r in records),
            'operating_hours': None if missing_hours else math.fsum(r['operating_hours'] for r in records),
            'operating_unit_days': sum((r['operating_hours'] or 0) > 0 for r in records),
            'structural_co2_zero_unit_days': sum(r['structural_co2_zero'] for r in records)}
