"""Conditional exposure ceilings under different retirement authorities."""
from datetime import date, timedelta
import math

from transition_assets.phase82_windows import closure_lower_bound, known_orders


def assess_window(case, asof, annual_co2, annual_net_mwh, capacity_mw, mu,
                  deadline_key='boiler_end_inclusive'):
    for value in [annual_co2, annual_net_mwh, capacity_mw, mu]:
        if not math.isfinite(value) or value < 0:
            raise ValueError('Expected finite nonnegative forecast, intensity and rating')
    if capacity_mw == 0:
        raise ValueError('Positive rating required')
    year = case['year']
    first, end = date(year, 1, 1), date(year + 1, 1, 1)
    snapshot = date.fromisoformat(asof)
    if not first - timedelta(days=1) <= snapshot < end:
        raise ValueError('Snapshot outside the specified year')
    action = max(first, snapshot + timedelta(days=1))
    annual_days, remaining = (end - first).days, (end - action).days
    kind = case['constraint_type']
    clauses = [r for r in case.get('clauses', []) if r['published'] <= asof]
    ids = [r['id'] for r in clauses]
    earliest, latest = None, None
    left, right = action, end
    status = 'not_identified'
    if kind == 'availability_mandate':
        orders = known_orders(case['orders'], asof)
        earliest = closure_lower_bound(orders, action.isoformat())
        left = max(action, min(end, date.fromisoformat(earliest)))
        ids = [r['id'] for r in orders]
        status = 'necessary_lower_bound_only'
    elif kind == 'court_latest_operation':
        deadlines = [date.fromisoformat(r[deadline_key]) for r in clauses if deadline_key in r]
        if deadlines:
            latest_day = min(deadlines)
            latest = latest_day.isoformat()
            right = max(action, min(end, latest_day + timedelta(days=1)))
    elif kind == 'conditional_contract_release':
        if any(r.get('release_date') is not None for r in clauses):
            raise ValueError('A known contract release needs a separately specified action model')
    elif kind != 'conditional_contract_release':
        raise ValueError('Unsupported constraint type')
    # These bounds restrict a fixed-rate accounting window, not a causal benefit.
    ceiling_days = max(0, (right - left).days)
    co2_rate = annual_co2 / annual_days
    signed_net = (annual_co2 - mu * annual_net_mwh) / annual_days
    net_rate = max(0., signed_net)
    ceiling = net_rate * ceiling_days
    return {
        'case_id': case['id'], 'year': year, 'asof': asof,
        'action_date': action.isoformat(), 'constraint_type': kind,
        'mu': mu, 'annual_days': annual_days, 'remaining_days': remaining,
        'known_clause_ids': ids, 'earliest_not_blocked': earliest,
        'latest_operation_date': latest, 'release_status': status,
        'ceiling_start_inclusive': left.isoformat(), 'ceiling_end_exclusive': right.isoformat(),
        'ceiling_days': ceiling_days, 'remaining_forecast_tonnes': co2_rate * remaining,
        'remaining_signed_net_tonnes': signed_net * remaining,
        'remaining_net_exposure_ceiling_tonnes': net_rate * remaining,
        'window_forecast_tonnes': co2_rate * ceiling_days,
        'excluded_forecast_tonnes': co2_rate * (remaining - ceiling_days),
        'signed_net_tonnes_per_day': signed_net, 'net_accounting_tonnes_per_day': net_rate,
        'net_exposure_ceiling_tonnes': ceiling, 'benefit_lower_bound_tonnes': 0.,
        'net_exposure_ceiling_tonnes_per_mw': ceiling / capacity_mw,
        'break_even_ceiling_per_mw_at_v100': 100 * ceiling / capacity_mw,
        'deadline_key': deadline_key if kind == 'court_latest_operation' else None,
        'interpretation': 'fixed-rate conditional ceiling; additionality and full feasibility not identified'
    }


def compare_ceilings(a, b):
    if (a['year'], a['asof'], a['mu']) != (b['year'], b['asof'], b['mu']):
        raise ValueError('Only common-year/date/intensity comparisons allowed')
    av, bv = a['net_exposure_ceiling_tonnes_per_mw'], b['net_exposure_ceiling_tonnes_per_mw']
    if math.isclose(av, bv, rel_tol=1e-12, abs_tol=1e-12):
        larger = 'tie'
    else:
        larger = a['case_id'] if av > bv else b['case_id']
    return {'year': a['year'], 'asof': a['asof'], 'mu': a['mu'],
            'case_a': a['case_id'], 'case_b': b['case_id'],
            'a_ceiling_tonnes_per_mw': av, 'b_ceiling_tonnes_per_mw': bv,
            'larger_ceiling_case': larger, 'project_order': 'not_identified',
            'reason': 'zero benefit remains possible; ceilings do not establish strict project dominance'}
