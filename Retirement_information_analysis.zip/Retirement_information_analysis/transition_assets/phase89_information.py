"""Response-dependent fixed-action verification by exchange constraint generation."""
import time
import warnings

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp

from transition_assets.phase87_review import interval_regret


def revealed_intervals(lower, upper, target, query):
    lo = np.asarray(lower, dtype=float); hi = np.asarray(upper, dtype=float)
    w = np.asarray(target, dtype=float); s = np.asarray(query, dtype=int)
    return np.where(s, w, lo), np.where(s, w, hi)


def exchange_cover(lower, upper, target, x, z):
    lo = np.asarray(lower, dtype=float); hi = np.asarray(upper, dtype=float)
    w = np.asarray(target, dtype=float); x = np.asarray(x, dtype=int)
    z = np.asarray(z, dtype=int)
    coefficient = np.where(x, lo, hi)
    contrast = float(coefficient @ (z-x))
    reduction = np.where(x, w-lo, hi-w) * np.abs(z-x)
    return contrast, reduction


def _validate(lower, upper, target, capacities, budget, x, epsilon, costs):
    arrays = [np.asarray(a, dtype=float) for a in [lower, upper, target, capacities, x]]
    lo, hi, w, k, x = arrays
    if lo.ndim != 1 or not len(lo) or any(a.shape != lo.shape for a in arrays):
        raise ValueError('One finite interval, answer, capacity and action per record required')
    if any(not np.all(np.isfinite(a)) for a in arrays):
        raise ValueError('Finite inputs required')
    if np.any(lo > hi) or np.any(w < lo-1e-12) or np.any(w > hi+1e-12) or np.any(k <= 0):
        raise ValueError('Ordered intervals containing answers and positive capacities required')
    w = np.clip(w, lo, hi)
    if not np.all((x == 0) | (x == 1)):
        raise ValueError('A binary fixed portfolio is required')
    if not np.isfinite(budget) or budget < 0 or k@x > budget+1e-6:
        raise ValueError('A feasible fixed portfolio and nonnegative budget are required')
    if not np.isfinite(epsilon) or epsilon < 0:
        raise ValueError('A finite nonnegative regret tolerance is required')
    c = np.ones(len(k)) if costs is None else np.asarray(costs, dtype=float)
    if c.shape != k.shape or not np.all(np.isfinite(c)) or np.any(c <= 0):
        raise ValueError('Positive finite query costs are required')
    return lo, hi, w, k, x.astype(int), c


def minimum_records(lower, upper, target, capacities, budget, x, epsilon=0.,
                    value_complete=False, costs=None, max_iterations=512,
                    time_limit=120., acceptance=1e-9, feasible_queries=None):
    """Offline minimum verification cost for the supplied fixed portfolio only."""
    lo, hi, w, k, x, c = _validate(lower, upper, target, capacities, budget, x, epsilon, costs)
    if max_iterations < 1 or time_limit <= 0 or acceptance < 0:
        raise ValueError('Positive execution limits and nonnegative acceptance required')
    complete = interval_regret(w, w, k, budget, x)
    if complete['upper'] > epsilon + acceptance:
        raise ValueError('Even full revelation does not verify this fixed portfolio')
    active = (hi > lo) & (k <= budget+1e-6)
    possible_reduction = np.where(x, w-lo, hi-w)
    useful = active & (possible_reduction > 0)
    mandatory = active & (x == 1) & (lo < -epsilon)
    if value_complete:
        mandatory |= active & (x == 1)
        useful |= active & (x == 1)
    low = mandatory.astype(float); high = useful.astype(float)
    seed = high.astype(int)
    if feasible_queries is not None:
        indices = list(feasible_queries)
        if any(not isinstance(i, (int, np.integer)) or i < 0 or i >= len(k) for i in indices):
            raise ValueError('Invalid known query set')
        seed = np.zeros(len(k), dtype=int); seed[indices] = 1
        seed &= high.astype(int)
        seed |= mandatory.astype(int)
        l, u = revealed_intervals(lo, hi, w, seed)
        if interval_regret(l, u, k, budget, x)['upper'] > epsilon+acceptance:
            raise ValueError('Known query set does not verify the fixed portfolio')
    best = seed.copy(); best_cost = float(c@best)
    lower_bound = float(c@low)
    cuts = []; seen = set(); trace = []
    def add_cut(z):
        key = tuple(int(t) for t in z)
        a, g = exchange_cover(lo, hi, w, x, z)
        if a <= epsilon+acceptance or key in seen:
            return
        seen.add(key); cuts.append((a, g, key))
        support = np.flatnonzero((g > 0) & useful)
        if len(support) == 1:
            low[support[0]] = 1
            mandatory[support[0]] = True
    # Cheap feasible exchanges tighten the lower bound before full separation.
    selected = np.flatnonzero(x); excluded = np.flatnonzero(1-x)
    resource = float(k@x)
    for i in selected:
        z = x.copy(); z[i] = 0; add_cut(z)
        for j in excluded:
            if resource-k[i]+k[j] <= budget+1e-6:
                swapped = z.copy(); swapped[j] = 1; add_cut(swapped)
    for j in excluded:
        if resource+k[j] <= budget+1e-6:
            z = x.copy(); z[j] = 1; add_cut(z)
    start = time.monotonic(); status = 'unresolved'
    for iteration in range(max_iterations):
        remaining = time_limit-(time.monotonic()-start)
        if remaining <= 0: break
        constraints = None
        if cuts:
            matrix = np.array([g for _, g, _ in cuts])
            rhs = np.array([a-epsilon for a, _, _ in cuts])
            scales = np.maximum(1e-6, np.maximum(abs(rhs), np.max(abs(matrix), axis=1)))
            constraints = LinearConstraint(matrix/scales[:, None], rhs/scales, np.inf)
        options = dict(mip_rel_gap=0., mip_abs_gap=0., mip_feasibility_tolerance=1e-9,
                       presolve=True, time_limit=min(10., remaining))
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore', message='Unrecognized options detected.*',
                                    category=RuntimeWarning)
            ans = milp(c, integrality=np.ones(len(k)), bounds=Bounds(low, high),
                       constraints=constraints, options=options)
        if ans.status != 0 or not ans.success or ans.x is None:
            if getattr(ans, 'mip_dual_bound', None) is not None:
                lower_bound = max(lower_bound, float(ans.mip_dual_bound))
            break
        s = np.rint(ans.x).astype(int)
        if np.max(abs(s-ans.x)) > 1e-6:
            raise RuntimeError('Nonintegral verification master')
        lower_bound = max(lower_bound, float(ans.mip_dual_bound))
        l, u = revealed_intervals(lo, hi, w, s)
        sep = interval_regret(l, u, k, budget, x)
        trace.append(dict(iteration=iteration, query_count=int(s.sum()),
                          objective=float(c@s), lower_bound=lower_bound,
                          regret_upper=sep['upper'], witness=sep['witness']))
        if sep['upper'] <= epsilon + acceptance:
            if float(c@s) <= best_cost:
                best = s.copy(); best_cost = float(c@s)
            if best_cost-lower_bound <= 1e-6:
                status = 'optimal'
                break
        else:
            z = np.array(sep['witness']); a, g = exchange_cover(lo, hi, w, x, z)
            if a-g@s <= epsilon + acceptance:
                raise RuntimeError('Separation upper bound is unresolved beyond precision')
            key = tuple(int(t) for t in z)
            if key in seen:
                raise RuntimeError('Repeated violated exchange: master precision failure')
            add_cut(z)
    l, u = revealed_intervals(lo, hi, w, best)
    final = interval_regret(l, u, k, budget, x)
    if final['upper'] > epsilon + acceptance:
        raise RuntimeError('Returned upper-bound query set does not verify the action')
    if lower_bound > best_cost+1e-6:
        raise RuntimeError('Verification lower bound exceeds feasible query cost')
    return dict(status=status, objective=best_cost, lower_bound=lower_bound,
                objective_gap=max(0., best_cost-lower_bound), query_count=int(best.sum()),
                queried_indices=np.flatnonzero(best).tolist(),
                mandatory_indices=np.flatnonzero(mandatory).tolist(),
                regret_upper=final['upper'], cuts=[dict(contrast=a, reduction=g.tolist(),
                    witness=list(z)) for a, g, z in cuts], trace=trace,
                value_complete=bool(value_complete), epsilon=float(epsilon))
