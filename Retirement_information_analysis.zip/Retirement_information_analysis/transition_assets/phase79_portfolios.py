"""Exact binary selection under alternative retirement baselines."""
import numpy as np
import warnings
from scipy.optimize import Bounds, LinearConstraint, milp


OPTIONS = {'mip_rel_gap': 1e-9, 'mip_abs_gap': 0.0,
           'mip_feasibility_tolerance': 1e-9, 'presolve': False, 'time_limit': 10.0}


def validate(values, capacities, budget):
    values = np.atleast_2d(np.asarray(values, dtype=float))
    capacities = np.asarray(capacities, dtype=float)
    if values.ndim != 2 or capacities.ndim != 1 or values.shape[1] != len(capacities):
        raise ValueError('Scenario and resource dimensions do not agree')
    if not values.shape[0] or not len(capacities):
        raise ValueError('At least one scenario and candidate are required')
    if not np.all(np.isfinite(values)) or not np.all(np.isfinite(capacities)):
        raise ValueError('Finite inputs are required')
    if np.any(capacities <= 0) or not np.isfinite(budget) or budget < 0:
        raise ValueError('Positive capacities and a nonnegative limit are required')
    return values, capacities, float(budget)


def optimize(objective, integrality, bounds, matrix, lower, upper):
    # HiGHS tolerances are forwarded by SciPy; retain dual bounds for validation.
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', message='Unrecognized options detected.*mip_abs_gap.*',
                                category=RuntimeWarning)
        result = milp(c=objective, integrality=integrality, bounds=bounds,
                      constraints=LinearConstraint(matrix, lower, upper), options=OPTIONS)
    if not result.success or result.status != 0 or result.x is None:
        raise RuntimeError('HiGHS did not establish optimality: ' + result.message)
    if result.mip_gap > 1e-8:
        raise RuntimeError('HiGHS terminated above the required relative gap')
    return result


def solve_nominal(values, capacities, budget):
    values, capacities, budget = validate(values, capacities, budget)
    if values.shape[0] != 1:
        raise ValueError('The nominal problem requires one baseline')
    v = values[0]
    n = len(v)
    resource = capacities / capacities.sum()
    scale = max(1.0, float(np.abs(v).sum()))
    normalized = v / scale
    limit = min(1.0, budget / capacities.sum())
    bounds = Bounds(np.zeros(n), np.ones(n))
    first = optimize(-normalized, np.ones(n), bounds, resource[None, :],
                     np.array([-np.inf]), np.array([limit]))
    best = float(-first.fun)
    # A minimum-resource tie rule avoids selecting zero-value generators.
    second = optimize(resource, np.ones(n), bounds,
                      np.vstack([resource, normalized]),
                      np.array([-np.inf, best - 1e-9]),
                      np.array([limit, np.inf]))
    x = np.rint(second.x).astype(int)
    value = float(v @ x)
    if capacities @ x > budget + 1e-6 or best * scale - value > 2e-8 * scale:
        raise RuntimeError('Nominal solution failed independent primal validation')
    return {'x': x.tolist(), 'value': value, 'resource': float(capacities @ x),
            'gap': float(first.mip_gap), 'dual_value': float(-first.mip_dual_bound * scale)}


def solve_regret(values, capacities, budget, optima=None):
    values, capacities, budget = validate(values, capacities, budget)
    scenarios, n = values.shape
    if optima is None:
        optima = [solve_nominal(v, capacities, budget)['value'] for v in values]
    optima = np.asarray(optima, dtype=float)
    if optima.shape != (scenarios,) or not np.all(np.isfinite(optima)):
        raise ValueError('One finite optimal value per scenario is required')
    scale = max(1.0, float(np.abs(values).sum(axis=1).max()))
    resource = capacities / capacities.sum()
    normalized = values / scale
    limit = min(1.0, budget / capacities.sum())
    # Every regret constraint uses its own attainable portfolio benchmark.
    matrix = np.vstack([np.r_[resource, 0.],
                        np.column_stack([-normalized, -np.ones(scenarios)])])
    lower = np.full(scenarios + 1, -np.inf)
    upper = np.r_[limit, -optima / scale]
    bounds = Bounds(np.zeros(n + 1), np.r_[np.ones(n), np.inf])
    integers = np.r_[np.ones(n), 0]
    first = optimize(np.r_[np.zeros(n), 1.], integers, bounds, matrix, lower, upper)
    best = float(first.fun)
    matrix2 = np.vstack([matrix, np.r_[np.zeros(n), 1.]])
    # Averaging only resolves primary ties; it is not an expected-value rule.
    second = optimize(np.r_[-normalized.mean(axis=0), 0.], integers, bounds,
                      matrix2, np.r_[lower, -np.inf], np.r_[upper, best + 1e-9])
    x = np.rint(second.x[:n]).astype(int)
    payoff = values @ x
    regrets = np.maximum(0., optima - payoff)
    worst = float(regrets.max())
    if capacities @ x > budget + 1e-6 or worst - best * scale > 2e-8 * scale:
        raise RuntimeError('Regret solution failed independent primal validation')
    return {'x': x.tolist(), 'max_regret': worst,
            'mean_value': float(payoff.mean()), 'payoffs': payoff.tolist(),
            'regrets': regrets.tolist(), 'optima': optima.tolist(),
            'resource': float(capacities @ x), 'gap': float(first.mip_gap),
            'dual_regret': float(first.mip_dual_bound * scale)}
