"""Descriptive attribution of already selected portfolios, not causal effects."""
from datetime import date

import numpy as np

FACTORS = ('initial_older', 'updated_older', 'initial_recent', 'updated_recent')


def attribution(values):
    a, b, c, d = (float(values[k]) for k in FACTORS)
    if not np.isfinite([a, b, c, d]).all():
        raise ValueError('Factorial values must be finite')
    return {'date_mt': .5 * ((b-a) + (d-c)),
            'rate_mt': .5 * ((c-a) + (d-b)),
            'joint_mt': d-a, 'interaction_mt': d-b-c+a}


def exchange(keys, capacities, observed, before, after, limit):
    k, w, a, b = (np.asarray(x, dtype=float) for x in (capacities, observed, before, after))
    limit = float(limit)
    if (not keys or len(set(keys)) != len(keys) or
            any(not isinstance(key, str) for key in keys) or
            any(x.shape != (len(keys),) for x in (k, w, a, b)) or
            not np.isfinite(np.concatenate((k, w, a, b, [limit]))).all() or
            (k <= 0).any() or limit < 0 or
            not np.isin(a, [0, 1]).all() or not np.isin(b, [0, 1]).all()):
        raise ValueError('Invalid portfolio accounting inputs')
    if max(k @ a, k @ b) > limit + 1e-6:
        raise ValueError('A stored portfolio exceeds the common capacity limit')
    entered, dropped = (b > a), (a > b)
    entries = sorted([
        {'key': key, 'direction': 'enter' if entered[i] else 'drop',
         'capacity_mw': float(k[i]), 'observed_value_mt': float(w[i]),
         'contribution_mt': float(w[i] * (b[i]-a[i]))}
        for i, key in enumerate(keys) if a[i] != b[i]], key=lambda r: r['key'])
    return {'enter_value_mt': float(w[entered].sum()),
            'drop_value_mt': float(w[dropped].sum()),
            'delta_mt': float(w @ (b-a)),
            'enter_capacity_mw': float(k[entered].sum()),
            'drop_capacity_mw': float(k[dropped].sum()),
            'before_capacity_mw': float(k @ a), 'after_capacity_mw': float(k @ b),
            'before_slack_mw': float(limit-k @ a), 'after_slack_mw': float(limit-k @ b),
            'changed_units': len(entries), 'entries': entries}


def plan_state(row):
    origin = date.fromisoformat(row['origin'])
    end = date(int(row['outcome_year']), 12, 31)
    original = date.fromisoformat(row['initial_plan'])
    current = date.fromisoformat(row['current_plan'])
    def state(value):
        return 'elapsed' if value <= origin else 'horizon' if value <= end else 'later'
    return {'initial_state': state(original), 'current_state': state(current),
            'revision': 'later' if current > original else 'earlier' if current < original else 'same'}


def diagnose(case, rows, transitions, tolerance=1e-7):
    keys = case['keys']
    if len({r['key'] for r in rows}) != len(rows) or set(keys) != {r['key'] for r in rows}:
        raise ValueError('Panel identities do not match the stored candidate set')
    by_key = {r['key']: r for r in rows}
    rows = [by_key[key] for key in keys]
    if any(r['outcome_year'] != case['year'] for r in rows):
        raise ValueError('Outcome year does not match the stored case')
    w = np.asarray(case['observed_values_mt'])
    forecasts = np.asarray(case['forecast_values_mt'])
    names = (*FACTORS, 'persistence')
    x = {name: np.asarray(r['x']) for name, r in case['methods'].items()}
    values = {name: float(w @ bits) for name, bits in x.items()}
    unit_records = []
    for i, row in enumerate(rows):
        units = attribution({name: float(w[i]*x[name][i]) for name in FACTORS})
        score = {name: float(forecasts[j, i]) for j, name in enumerate(names)}
        unit_records.append({
            'key': row['key'], 'plant': row['plant'], 'fuel': row['fuel'],
            'capacity_mw': row['capacity_mw'], 'origin': row['origin'],
            'initial_plan': row['initial_plan'], 'current_plan': row['current_plan'],
            'outcome_exit': row['outcome_exit'], **plan_state(row),
            'observed_value_mt': float(w[i]),
            'observed_generation_mwh': row['g_actual'],
            'persistence_generation_mwh': row['g_forecasts']['persistence'],
            'date_score_changed': max(abs(score['updated_older']-score['initial_older']),
                                      abs(score['updated_recent']-score['initial_recent'])) > tolerance,
            'rate_score_changed': max(abs(score['initial_recent']-score['initial_older']),
                                      abs(score['updated_recent']-score['updated_older'])) > tolerance,
            **units})
    metadata = {r['key']: r for r in unit_records}
    changes = {}
    for before, after in transitions:
        result = exchange(keys, case['capacities'], w, x[before], x[after], case['limit_mw'])
        for entry in result['entries']:
            entry.update({k: metadata[entry['key']][k] for k in
                          ('plant', 'fuel', 'initial_state', 'current_state', 'revision',
                           'outcome_exit', 'initial_plan', 'current_plan')})
        groups = {}
        for state in ('elapsed', 'horizon', 'later'):
            entries = [r for r in result['entries'] if r['initial_state'] == state]
            groups[state] = {'changed_units': len(entries),
                             'net_value_mt': sum(r['contribution_mt'] for r in entries)}
        result['initial_state_groups'] = groups
        result.update({'before': before, 'after': after})
        changes[before + '->' + after] = result
    group_attribution = {}
    for field, groups in [('initial_state', ('elapsed', 'horizon', 'later')),
                          ('date_score_changed', (False, True)),
                          ('rate_score_changed', (False, True))]:
        group_attribution[field] = {
            str(group): {name: sum(r[name] for r in unit_records if r[field] == group)
                         for name in ('date_mt', 'rate_mt', 'joint_mt', 'interaction_mt')}
            for group in groups}
    reference = np.asarray(case['reference_x'])
    regret_sources = {}
    for name, bits in x.items():
        missed = (reference == 1) & (bits == 0)
        extra = (reference == 0) & (bits == 1)
        regret_sources[name] = {
            'missed_reference_value_mt': float(w[missed].sum()),
            'selected_outside_reference_value_mt': float(w[extra].sum()),
            'regret_mt': float(w @ (reference-bits)),
            'missed_reference_keys': [key for key, flag in zip(keys, missed) if flag],
            'selected_outside_reference_keys': [key for key, flag in zip(keys, extra) if flag]}
    return {**{k: case[k] for k in ('year', 'mu', 'q', 'fraction', 'n', 'limit_mw')},
            'observed_values_mt': values, 'attribution': attribution(values),
            'group_attribution': group_attribution, 'transitions': changes,
            'regret_sources': regret_sources, 'units': unit_records}
