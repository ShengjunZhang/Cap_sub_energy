"""Annual-support integration using the frozen portfolio and calibration methods."""
from collections import Counter
import numpy as np

from transition_assets.phase85_solver_v2 import solve_nominal, solve_regret
from transition_assets.phase80_calibration import calibrated_values


def panel_counts(rows):
    identities = [(r['key'], r['origin']) for r in rows]
    if len(set(identities)) != len(identities):
        raise ValueError('Duplicate unit-origin observation')
    unique = {}
    for r in rows:
        unique[r['key']] = r['capacity_mw']
    return dict(rows=len(rows), generators=len(unique),
                plants=len({r['plant'] for r in rows}),
                unique_capacity_mw=float(sum(unique.values())),
                repeated_capacity_mw=float(sum(r['capacity_mw'] for r in rows)),
                exit_rows=sum(bool(r['outcome_exit']) for r in rows),
                years=dict(Counter(str(r['outcome_year']) for r in rows)),
                fuels=dict(Counter(r['fuel'] for r in rows)))


def compare_losses(cases, method, comparator, tolerance=1e-7):
    delta = np.array([c['methods'][comparator]['observed_regret_mt']
                      - c['methods'][method]['observed_regret_mt'] for c in cases])
    return dict(n=len(cases), lower=int((delta > tolerance).sum()),
                higher=int((delta < -tolerance).sum()),
                ties=int((abs(delta) <= tolerance).sum()),
                mean_loss_difference_mt=float(delta.mean()))


def evaluate_corrected(panel, old, centers):
    year = old['year']
    rows = sorted([r for r in panel if r['outcome_year'] == year], key=lambda r: r['key'])
    if [r['key'] for r in rows] != old['keys']:
        raise ValueError('Candidate order differs from annual comparison')
    capacity = np.asarray(old['capacities'])
    actual = np.asarray(old['observed_values_mt'])
    case = {k: old[k] for k in ('year', 'mu', 'q', 'fraction', 'limit_mw',
                                'reference_value_mt', 'keys', 'capacities')}
    case['methods'] = {m: {k: ans[k] for k in ('x', 'observed_regret_mt',
                       'observed_value_mt', 'capacity_mw')} for m, ans in old['methods'].items()}
    case['calibration'] = {}
    for center in centers:
        median, values, meta = calibrated_values(panel, rows, year, center, old['mu'], old['q'])
        nominal = solve_nominal(median, capacity, old['limit_mw'])
        robust = solve_regret(values, capacity, old['limit_mw'])
        meta['coordinate_coverage'] = int(((actual >= values.min(axis=0) - 1e-9)
                                          & (actual <= values.max(axis=0) + 1e-9)).sum())
        meta['n'] = len(rows)
        meta['scenario_values_mt'] = values.tolist()
        case['calibration'][center] = meta
        for suffix, ans in [('median', nominal), ('calibrated_regret', robust)]:
            x = np.asarray(ans['x'])
            value = float(actual @ x)
            gap = (ans['max_regret'] - ans['dual_regret'] if suffix == 'calibrated_regret'
                   else ans['dual_value'] - ans['value'])
            case['methods'][center + '_' + suffix] = dict(
                x=x.tolist(), observed_value_mt=value,
                observed_regret_mt=max(0., old['reference_value_mt'] - value),
                capacity_mw=float(capacity @ x), solver_gap=ans['gap'],
                absolute_solver_gap_mt=max(0., gap),
                training_stress_max_regret_mt=float((np.asarray(robust['optima']) - values @ x).max()))
    return case
