"""Retrieve plan forecasts without giving the policy future operating outcomes."""
import warnings
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp


def nominal_selection(values, capacities, budget):
    """Same objective and capacity tie rule, with presolve enabled for this replay."""
    v=np.asarray(values,dtype=float); k=np.asarray(capacities,dtype=float)
    if v.ndim!=1 or k.shape!=v.shape or not len(v) or not np.all(np.isfinite(v)):
        raise ValueError('Invalid nominal dimensions or values')
    if not np.all(np.isfinite(k)) or np.any(k<=0) or not np.isfinite(budget) or budget<0:
        raise ValueError('Invalid capacity or budget')
    scale=max(1.,float(abs(v).sum())); norm=v/scale; resource=k/k.sum()
    options=dict(mip_rel_gap=1e-10,mip_abs_gap=0.,mip_feasibility_tolerance=1e-9,
                 presolve=True,time_limit=10.)
    def run(obj,matrix,lo,hi):
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore',message='Unrecognized options detected.*',category=RuntimeWarning)
            ans=milp(obj,integrality=np.ones(len(k)),bounds=Bounds(np.zeros(len(k)),np.ones(len(k))),
                     constraints=LinearConstraint(matrix,lo,hi),options=options)
        if not ans.success or ans.status!=0 or ans.x is None:
            raise RuntimeError('Review nominal solve did not establish optimality: '+ans.message)
        return ans
    limit=min(1.,budget/k.sum())
    first=run(-norm,resource[None,:],[-np.inf],[limit])
    second=run(resource,np.vstack([resource,norm]),[-np.inf,-first.fun-1e-9],[limit,np.inf])
    x=np.rint(second.x).astype(int); value=float(v@x); dual=float(-first.mip_dual_bound*scale)
    if (k@x>budget+1e-6 or np.max(abs(second.x-x))>1e-6
            or dual-value>1e-7 or dual+1e-7<value):
        raise RuntimeError('Review nominal primal/dual precision failed')
    return dict(x=x.tolist(),value=value,dual_value=dual)


def exposure_bounds(full_year_net, capacities, q):
    h = np.asarray(full_year_net, dtype=float)
    k = np.asarray(capacities, dtype=float)
    if h.ndim != 1 or k.shape != h.shape or not len(k):
        raise ValueError('One full-year value and capacity per record required')
    if not np.all(np.isfinite(h)) or not np.all(np.isfinite(k)) or np.any(k <= 0):
        raise ValueError('Finite values and positive capacities required')
    if not np.isfinite(q) or q < 0:
        raise ValueError('Nonnegative finite period cost required')
    cost = q*k/1e6
    return np.minimum(0., h)-cost, np.maximum(0., h)-cost


def interval_regret(lower, upper, capacities, budget, x):
    lo = np.asarray(lower, dtype=float); hi = np.asarray(upper, dtype=float)
    k = np.asarray(capacities, dtype=float); x = np.asarray(x, dtype=float)
    if lo.ndim != 1 or not len(lo) or any(v.shape != lo.shape for v in (hi, k, x)):
        raise ValueError('Dimensions do not agree')
    if any(not np.all(np.isfinite(v)) for v in (lo, hi, k, x)):
        raise ValueError('Finite inputs required')
    if np.any(lo > hi) or np.any(k <= 0) or not np.all((x == 0)|(x == 1)):
        raise ValueError('Invalid interval, capacity or binary selection')
    if not np.isfinite(budget) or budget < 0 or k@x > budget+1e-6:
        raise ValueError('Invalid budget or infeasible selection')
    coefficient = np.where(x == 1, lo, hi)
    scale = max(1., float(abs(coefficient).sum()), float(abs(lo@x)))
    options = dict(mip_rel_gap=1e-10, mip_abs_gap=0.,
                   mip_feasibility_tolerance=1e-9, presolve=True, time_limit=10.)
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', message='Unrecognized options detected.*',
                                category=RuntimeWarning)
        result = milp(-coefficient/scale, integrality=np.ones(len(k)),
            bounds=Bounds(np.zeros(len(k)), np.ones(len(k))),
            constraints=LinearConstraint((k/k.sum())[None, :], [-np.inf],
                                         [min(1., budget/k.sum())]), options=options)
    if result.status != 0 or result.x is None or not result.success:
        raise RuntimeError('Interval separation did not establish optimality: '+result.message)
    z = np.rint(result.x).astype(int)
    primal = float(coefficient@z-lo@x)
    dual = float(-result.mip_dual_bound*scale-lo@x)
    if (np.max(abs(z-result.x)) > 1e-6 or k@z > budget+1e-6
            or dual+1e-7 < primal or dual-primal > 1e-7):
        raise RuntimeError('Interval separation primal/dual precision failed')
    return dict(value=max(0., primal), upper=max(0., dual),
                witness=z.tolist(), absolute_gap=max(0., dual-primal))


def next_record(policy, lower, upper, capacities, x, witness, available,
                disagreement=None, random_order=None):
    """Only already visible data enter the next-record priority."""
    candidates = list(available)
    if not candidates:
        raise ValueError('No record remains available')
    width = np.asarray(upper)-np.asarray(lower)
    if policy == 'exchange_width':
        candidates = [i for i in candidates if x[i] != witness[i]]
        if not candidates:
            raise RuntimeError('Positive uncertainty bound without an unreviewed exchange')
        score = width
    elif policy == 'interval_width':
        score = width
    elif policy == 'capacity':
        score = capacities
    elif policy == 'initial_disagreement':
        score = disagreement
        if score is None:
            raise ValueError('Initial-rule disagreement required')
    elif policy == 'random':
        if random_order is None:
            raise ValueError('Random order required')
        return next(i for i in random_order if i in candidates)
    else:
        raise ValueError('Unknown review policy')
    return min(candidates, key=lambda i: (-float(score[i]), i))


def review_path(initial, lower, upper, capacities, budget, answer, policy,
                disagreement=None, seed=8700, tolerance=1e-7, cache=None):
    p = np.asarray(initial, dtype=float).copy()
    lo = np.asarray(lower, dtype=float).copy(); hi = np.asarray(upper, dtype=float).copy()
    k = np.asarray(capacities, dtype=float)
    if any(v.shape != p.shape for v in (lo, hi, k)) or p.ndim != 1 or not len(p):
        raise ValueError('Review dimensions do not agree')
    if not np.all(np.isfinite(p)) or np.any(p < lo-1e-9) or np.any(p > hi+1e-9):
        raise ValueError('Initial forecast must lie inside finite bounds')
    if not np.isfinite(tolerance) or tolerance < 0:
        raise ValueError('Nonnegative tolerance required')
    if disagreement is not None:
        disagreement = np.asarray(disagreement, dtype=float)
        if disagreement.shape != p.shape or not np.all(np.isfinite(disagreement)):
            raise ValueError('Invalid initial disagreement')
    interval_regret(lo, hi, k, budget, np.zeros(len(k)))
    available = {i for i in range(len(k)) if hi[i]-lo[i] > 1e-12 and k[i]<=budget+1e-6}
    order = np.random.default_rng(seed).permutation(len(k)).tolist()
    if cache is None:
        cache = {'nominal': {}, 'separation': {}}
    queried = []; states = []; max_gap = 0.
    while True:
        key = p.tobytes()
        if key not in cache['nominal']:
            cache['nominal'][key] = nominal_selection(p, k, budget)
        nominal = cache['nominal'][key]; x = nominal['x']
        skey = (lo.tobytes(), hi.tobytes(), tuple(x))
        if skey not in cache['separation']:
            cache['separation'][skey] = interval_regret(lo, hi, k, budget, x)
        uncertainty = cache['separation'][skey]
        max_gap = max(max_gap, uncertainty['absolute_gap'],
                      max(0., nominal['dual_value']-nominal['value']))
        states.append(dict(queries=len(queried), x=x, forecast_value=float(p@x),
            capacity_mw=float(k@x), regret_bound=uncertainty['value'],
            regret_upper=uncertainty['upper'], witness=uncertainty['witness']))
        if uncertainty['upper'] <= tolerance:
            return dict(policy=policy, seed=seed if policy == 'random' else None,
                queried_indices=queried, states=states, queries_to_stop=len(queried),
                maximum_absolute_solver_gap_mt=max_gap)
        if not available:
            raise RuntimeError('All forecasts retrieved but forecast optimality is unresolved')
        i = next_record(policy, lo, hi, k, x, uncertainty['witness'], available,
                        disagreement=disagreement, random_order=order)
        # The current plan is read only after the index has been chosen.
        revealed = float(answer(i))
        if not np.isfinite(revealed) or revealed < lo[i]-1e-9 or revealed > hi[i]+1e-9:
            raise ValueError('Revealed forecast is outside the exposure interval')
        p[i] = revealed; lo[i] = revealed; hi[i] = revealed
        available.remove(i); queried.append(i)
