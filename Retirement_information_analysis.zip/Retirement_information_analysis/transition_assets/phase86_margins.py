"""Exchange-specific loss and objective stability of a fixed binary portfolio."""
import warnings
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp


def inputs(values, capacity, budget, x):
    w=np.asarray(values, dtype=float); k=np.asarray(capacity, dtype=float); x=np.asarray(x, dtype=float)
    if w.ndim != 1 or k.shape != w.shape or x.shape != w.shape or not len(w):
        raise ValueError('One value, capacity and binary action per candidate required')
    if not np.all(np.isfinite(w)) or not np.all(np.isfinite(k)) or np.any(k <= 0):
        raise ValueError('Finite values and strictly positive capacities required')
    if not np.isfinite(budget) or budget < 0 or not np.all((x == 0)|(x == 1)) or k@x > budget+1e-6:
        raise ValueError('Invalid budget or infeasible action')
    return w, k, float(budget), x.astype(int)


def exchange_decomposition(forecast, actual, capacity, x, reference):
    w,k,_,x=inputs(forecast,capacity,float(np.sum(capacity)),x)
    a=np.asarray(actual,dtype=float); z=np.asarray(reference,dtype=float)
    if a.shape != w.shape or z.shape != x.shape or not np.all(np.isfinite(a)) or not np.all((z==0)|(z==1)):
        raise ValueError('Invalid realised values or reference')
    z=z.astype(int); d=z-x; delta=a-w; changed=d!=0
    return dict(loss=float(a@d), forecast_margin=float(-w@d),
                error_contrast=float(delta@d),
                exchange_absolute_error=float(abs(delta[changed]).sum()),
                total_absolute_error=float(abs(delta).sum()),
                exchanged_capacity_mw=float(k@abs(d)), changed_generators=int(changed.sum()),
                changed_indices=np.flatnonzero(changed).tolist())


def _solve(w, k, budget, x, rho, exclude):
    # The separable box maximisation is linear after fixing the incumbent.
    scale=max(1.,float(abs(w).sum()),float(abs(rho)*k.sum()))
    coef=w+rho*k*(1-2*x)
    resource=k/k.sum()
    matrix=[resource]; lower=[-np.inf]; upper=[min(1.,budget/k.sum())]
    if exclude:
        matrix.append(1-2*x); lower.append(1-int(x.sum())); upper.append(np.inf)
    options={'mip_rel_gap':1e-10,'mip_abs_gap':0.,'mip_feasibility_tolerance':1e-9,
             'presolve':True,'time_limit':10.}
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore',message='Unrecognized options detected.*',category=RuntimeWarning)
        res=milp(-coef/scale,integrality=np.ones(len(w)),bounds=Bounds(np.zeros(len(w)),np.ones(len(w))),
                 constraints=LinearConstraint(np.asarray(matrix),lower,upper),options=options)
    if res.status==2 and exclude: return None
    if not res.success or res.status!=0 or res.x is None:
        raise RuntimeError('Sensitivity optimisation did not establish optimality: '+res.message)
    z=np.rint(res.x).astype(int)
    if k@z>budget+1e-6 or np.max(abs(res.x-z))>1e-6 or (exclude and np.array_equal(z,x)):
        raise RuntimeError('Sensitivity primal check failed')
    primal=float(coef@z); dual=float(-res.mip_dual_bound*scale)
    if dual+1e-7*scale < primal or dual-primal>1e-9*scale:
        raise RuntimeError('Sensitivity objective precision failed')
    return dict(z=z,primal=primal,dual=dual,absolute_gap=max(0.,dual-primal),scale=scale)


def worst_regret(values,capacity,budget,x,rho):
    w,k,budget,x=inputs(values,capacity,budget,x)
    if not np.isfinite(rho) or rho<0: raise ValueError('Nonnegative finite radius required')
    ans=_solve(w,k,budget,x,float(rho),False)
    constant=float(-w@x+rho*k@x)
    return dict(value=float(ans['primal']+constant), upper=float(ans['dual']+constant),
                witness=ans['z'].tolist(),absolute_gap=ans['absolute_gap'])


def stability_radius(values,capacity,budget,x,resolution=1e-7,max_iterations=80):
    w,k,budget,x=inputs(values,capacity,budget,x)
    if resolution<=0: raise ValueError('Positive radius resolution required')
    first=_solve(w,k,budget,x,0.,True)
    if first is None:
        return dict(status='single_feasible_action',lower=None,upper=None,witness=None,iterations=1,
                    nominal_gap=0.,maximum_absolute_gap=0.)
    z=first['z']; gap=float(w@(x-z)); nominal_gap=max(0.,-gap)
    if gap < 0:
        return dict(status='not_nominal_optimum',lower=0.,upper=0.,witness=z.tolist(),iterations=1,
                    nominal_gap=nominal_gap,maximum_absolute_gap=first['absolute_gap'])
    upper=gap/float(k@abs(z-x)); witness=z.copy(); maxgap=first['absolute_gap']
    for iteration in range(1,max_iterations+1):
        ans=_solve(w,k,budget,x,upper,True); z=ans['z']; maxgap=max(maxgap,ans['absolute_gap'])
        constant=float(w@x-upper*k@x)
        dual_min=constant-ans['dual']
        lower=max(0.,upper+min(0.,dual_min)/float(k.min()))
        if upper-lower<=resolution:
            return dict(status='bounded',lower=float(lower),upper=float(upper),witness=witness.tolist(),
                        iterations=iteration+1,nominal_gap=nominal_gap,maximum_absolute_gap=maxgap)
        new=float(w@(x-z))/float(k@abs(z-x))
        if new < -resolution:
            return dict(status='not_nominal_optimum',lower=0.,upper=0.,witness=z.tolist(),
                        iterations=iteration+1,nominal_gap=max(nominal_gap,-float(w@(x-z))),maximum_absolute_gap=maxgap)
        if new>=upper-1e-12:
            raise RuntimeError('Radius interval remains unresolved at solver precision')
        upper=max(0.,new); witness=z.copy()
    raise RuntimeError('Stability ratio iterations exceeded fixed limit')
