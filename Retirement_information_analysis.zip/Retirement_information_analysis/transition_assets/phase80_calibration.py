"""Past-year fuel residual stresses for retirement appraisal."""
import itertools
import numpy as np


def calibrated_values(panel, candidates, year, center, mu, q):
    training = [r for r in panel if r['outcome_year'] < year]
    if not training:
        raise ValueError('At least one preceding outcome year is required')
    if any(r['fuel'] not in ('coal', 'gas') for r in training + candidates):
        raise ValueError('Only coal and gas fuel groups are defined')
    if any(r['outcome_year'] != year for r in candidates):
        raise ValueError('Candidate years must equal the evaluated year')
    if any(r['capacity_mw'] <= 0 for r in training + candidates):
        raise ValueError('Positive capacity is required')
    residuals = np.array([(r['e_actual'] - mu * r['g_actual']
                          - r['e_forecasts'][center] + mu * r['g_forecasts'][center])
                         / r['capacity_mw'] for r in training])
    levels, fuel_meta = {}, {}
    for fuel in ('coal', 'gas'):
        subset = residuals[[r['fuel'] == fuel for r in training]]
        fallback = len(subset) == 0
        source = residuals if fallback else subset
        levels[fuel] = np.quantile(source, [.1, .5, .9], method='linear')
        fuel_meta[fuel] = {'n': len(subset), 'fallback': fallback,
                           'residual_quantiles_t_per_mw': levels[fuel].tolist()}
    capacity = np.array([r['capacity_mw'] for r in candidates])
    base = np.array([r['e_forecasts'][center] - mu * r['g_forecasts'][center]
                     - q * r['capacity_mw'] for r in candidates])
    median = (base + capacity * np.array([levels[r['fuel']][1] for r in candidates])) / 1e6
    scenarios = []
    for coal_level, gas_level in itertools.product(range(3), repeat=2):
        indices = {'coal': coal_level, 'gas': gas_level}
        shift = np.array([levels[r['fuel']][indices[r['fuel']]] for r in candidates])
        scenarios.append((base + capacity * shift) / 1e6)
    meta = {'center': center, 'mu': mu, 'training_n': len(training),
            'training_years': sorted({r['outcome_year'] for r in training}),
            'fuel': fuel_meta}
    return median, np.array(scenarios), meta
