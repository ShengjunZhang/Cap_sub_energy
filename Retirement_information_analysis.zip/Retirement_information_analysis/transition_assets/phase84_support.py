"""Annual support checks and finite-period conditional appraisal."""
import calendar
from collections import defaultdict
import math

from scripts.run_phase68_horizons import checkpoint_state, recorded_event


def annual_support(record, annual_total, raw_matches, absolute=1e-6, relative=1e-10):
    result = {'status': 'complete', 'annual_mwh': None, 'rate_mw': None,
              'annual_discrepancy_mwh': None}
    if record is None:
        return dict(result, status='no_generator_year')
    if record['duplicate']:
        return dict(result, status='duplicate')
    if record['frequency'] not in {'M', 'AM'}:
        return dict(result, status='unsupported_frequency')
    values = record['values']
    if len(values) != 12 or any(x is None or not math.isfinite(x) for x in values):
        return dict(result, status='incomplete_months')
    if not raw_matches:
        return dict(result, status='raw_row_mismatch')
    if annual_total is None or not math.isfinite(annual_total):
        return dict(result, status='missing_annual_total')
    total = math.fsum(values)
    discrepancy = total - annual_total
    result['annual_discrepancy_mwh'] = discrepancy
    if abs(discrepancy) > absolute + relative * abs(annual_total):
        return dict(result, status='annual_total_mismatch')
    hours = 24 * (366 if calendar.isleap(record['year']) else 365)
    return dict(result, annual_mwh=total, rate_mw=total / hours)


def reported_annual_support(record, annual_total, raw_matches):
    result = {'status': 'complete', 'annual_mwh': None, 'rate_mw': None}
    if record is None:
        return dict(result, status='no_generator_year')
    if record['duplicate']:
        return dict(result, status='duplicate')
    if record['frequency'] not in {'M', 'AM'}:
        return dict(result, status='unsupported_frequency')
    if not raw_matches:
        return dict(result, status='raw_row_mismatch')
    if annual_total is None or not math.isfinite(annual_total):
        return dict(result, status='missing_annual_total')
    hours = 24 * (366 if calendar.isleap(record['year']) else 365)
    return dict(result, annual_mwh=annual_total, rate_mw=annual_total / hours)


def origin_grid(cohort, history, origins, census='2026-06-30'):
    hh = defaultdict(list)
    for r in history:
        hh[r['key']].append(r)
    snapshots = sorted({r['snapshot'] for r in history})
    rows = []
    seen = set()
    for u in sorted(cohort, key=lambda r: (r['eia_plant_id'], r['eia_generator_id'])):
        key = u['eia_plant_id'] + ':' + u['eia_generator_id']
        if key in seen:
            raise ValueError('Duplicate cohort unit')
        seen.add(key)
        ev = recorded_event(hh[key], census, census)
        for y in origins:
            origin = f'{y}-12-31'
            state = checkpoint_state(hh[key], snapshots, origin)
            if u['first_plan_snapshot_date'] > origin:
                status = 'before_first_qualifying_snapshot'
            elif state['snapshot'] != origin:
                status = 'no_exact_origin_snapshot'
            elif state['category'] not in {'plan_due', 'plan_future', 'plan_blank'}:
                status = 'inventory:' + state['category']
            else:
                status = 'eligible_origin'
            event = ev['date']
            exit_in_year = bool(event and origin < event <= f'{y+1}-12-31')
            stratum = ('unknown_exit_status' if ev['state'] == 'unknown' else
                       'recorded_outcome_exit' if exit_in_year else 'no_recorded_outcome_exit')
            rows.append({'key': key, 'plant': u['eia_plant_id'], 'name': u['plant_name'],
                         'fuel': u['fuel_group'], 'state': u['plant_state'],
                         'capacity_mw': float(u['eligibility_nameplate_capacity_mw']),
                         'year': y, 'origin': origin, 'outcome_year': y+1,
                         'initial_plan': u['initial_planned_retirement_date'],
                         'current_plan': state['plan_date'], 'origin_status': status,
                         'inventory_category': state['category'],
                         'risk_eligible': status == 'eligible_origin',
                         'historical_event': event, 'event_source': ev['source_snapshot'],
                         'exit_stratum': stratum, 'outcome_exit': exit_in_year,
                         'retrospectively_already_retired': bool(event and event <= origin)})
    return rows


def stage_counts(rows):
    units = {}
    for r in rows:
        k = r['capacity_mw']
        if not math.isfinite(k) or k <= 0:
            raise ValueError('Invalid capacity')
        if r['key'] in units and units[r['key']] != k:
            raise ValueError('Unit capacity differs across origins')
        units[r['key']] = k
    return {'rows': len(rows), 'units': len(units), 'plants': len({r['plant'] for r in rows}),
            'unique_capacity_mw': math.fsum(units.values()),
            'repeated_origin_capacity_mw': math.fsum(r['capacity_mw'] for r in rows)}


def project_margin_interval(lower_tonnes, upper_tonnes, carbon_value, period_cost):
    if not all(math.isfinite(x) for x in
               [lower_tonnes, upper_tonnes, carbon_value, period_cost]):
        raise ValueError('Nonfinite valuation input')
    if not 0 <= lower_tonnes <= upper_tonnes or carbon_value < 0 or period_cost < 0:
        raise ValueError('Invalid valuation boundary')
    lower = carbon_value * lower_tonnes - period_cost
    upper = carbon_value * upper_tonnes - period_cost
    status = ('nonpositive_under_fixed_inputs' if upper <= 0 else
              'positive_under_fixed_inputs' if lower > 0 else 'unresolved')
    return {'margin_lower_currency': lower, 'margin_upper_currency': upper,
            'carbon_margin_status': status, 'physical_feasibility_established': False,
            'boundary': 'same finite intervention period; not annualised or lifecycle welfare'}
