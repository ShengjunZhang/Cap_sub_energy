import copy
import json
from pathlib import Path
import unittest

import numpy as np
from scripts import run_phase73_decisions as m

ROOT = Path(__file__).resolve().parents[1]
FIX = json.loads((ROOT/'tests/fixtures/phase73_decisions.json').read_text())


def example():
    r = dict(key='x:1', year=2021, plant='x', capacity_mw=2.,
             actual=1000., rate0=1., rate1=2., initial_plan='2023-12-31',
             current_plan='2024-12-31', plan_sources=[], hours0=100,
             hours1=200, full_hours=8760, fuel='coal', outcome_year=2022,
             origin='2021-12-31', forecasts={b:1000. for b in m.RULES},
             strict_complete=False, historical_identity_validated=False,
             outcome_exit=False)
    return r


class Phase73Tests(unittest.TestCase):
    def test_threshold_units(self):
        f=FIX['threshold']
        s=m.score(f['e_t'], f['g_mwh'], f['capacity'], f['mu'])
        self.assertEqual(s, f['score'])
        self.assertEqual(s*f['capacity']*f['v'], f['critical_cost'])

    def test_loss_fixtures(self):
        for f in FIX['losses']:
            self.assertEqual(bool(m.action(f['predicted'],f['q'])), f['action'])
            self.assertEqual(m.loss(f['predicted'],f['observed'],f['q']), f['loss'])

    def test_negative_cost_outside_domain(self):
        with self.assertRaises(ValueError): m.loss(1,2,-1)

    def test_nonpositive_capacity(self):
        with self.assertRaises(ValueError): m.score(1,2,0,0)

    def test_pairing_not_position(self):
        a=example(); b=example(); b['key']='y:1'
        c=copy.deepcopy(a); c['actual']=2000.
        rows,ledger=m.pair_panels([a,b],[b,c])
        self.assertEqual(next(r for r in rows if r['key']=='x:1')['e_actual'],2000.)
        self.assertEqual(len(rows),2)

    def test_duplicate_rejected(self):
        a=example()
        with self.assertRaises(ValueError):m.pair_panels([a,a],[a])

    def test_negative_values_excluded_not_clipped(self):
        a=example(); a['rate0']=-1
        rows,ledger=m.pair_panels([a],[example()])
        self.assertEqual(rows,[])
        self.assertIn('negative_net',ledger[0]['reasons'])

    def test_zero_preserved(self):
        a=example(); a['actual']=0
        rows,_=m.pair_panels([a],[example()])
        self.assertEqual(rows[0]['g_actual'],0)

    def test_metadata_mismatch_excluded(self):
        a=example(); b=example(); b['hours0']=101
        rows,ledger=m.pair_panels([a],[b])
        self.assertEqual(rows,[])
        self.assertIn('metadata:hours0',ledger[0]['reasons'])

    def test_missing_match_not_zero(self):
        rows,ledger=m.pair_panels([],[example()])
        self.assertEqual(rows,[])
        self.assertIn('no_net_match',ledger[0]['reasons'])

    def test_net_not_gross_used(self):
        a=example(); b=example(); b['monitor_years']=[{'gross':999999}]
        rows,_=m.pair_panels([a],[b])
        self.assertEqual(rows[0]['g_actual'],1000)

    def test_weighted_loss(self):
        p=np.array([300.,100.]); o=np.array([200.,200.]); k=np.array([1.,3.])
        s=m.summarize(p,o,k,250)
        self.assertEqual(s['loss_per_mw'],12.5)
        self.assertEqual(s['false_positive_rows'],1)
        self.assertEqual(s['false_negative_rows'],0)

    def test_exact_frontier_linear(self):
        preds={b:np.array([300.,100.]) for b in m.RULES}
        obs=np.array([200.,400.]); k=np.array([1.,3.])
        f=m.frontier(preds,obs,k)
        for a,b,la,lb in zip(f['q'][:-1],f['q'][1:],f['left_limit']['persistence'],f['right_limit']['persistence']):
            mid=(a+b)/2
            self.assertAlmostEqual(m.summarize(preds['persistence'],obs,k,mid)['loss_per_mw'],(la+lb)/2)
        self.assertEqual(f['at_point']['persistence'][-1],0)

    def test_regions_internal_crossing(self):
        f=FIX['regions'];r=m.sign_regions(f['q'],f['difference'][:-1],f['difference'][1:])
        self.assertAlmostEqual(r[0]['hi'],f['crossing'])
        self.assertEqual(r[0]['label'],'persistence_lower')
        self.assertEqual(r[1]['label'],'updated_lower')

    def test_all_negative_frontier(self):
        p={b:np.array([-1.]) for b in m.RULES}
        f=m.frontier(p,np.array([-2.]),np.array([1.]))
        self.assertEqual(f['q'],[0.])
        self.assertEqual(f['at_point']['updated_recent'],[0.])

    def test_discontinuity_at_predicted_threshold(self):
        p={b:np.array([100.]) for b in m.RULES}
        f=m.frontier(p,np.array([200.]),np.array([1.]))
        self.assertEqual(f['right_limit']['persistence'][0],0)
        self.assertEqual(f['left_limit']['persistence'][1],100)
        self.assertEqual(f['at_point']['persistence'][1],100)

    def test_rank_error_need_not_order_decisions(self):
        # Prediction 9 is closer to observed10 than12, but cost10.5 gives
        # zero loss for9 and positive loss for12. A second cost9.5 reverses this.
        self.assertLess(abs(9-10),abs(12-10))
        self.assertGreater(m.loss(9,10,9.5),m.loss(12,10,9.5))
        self.assertLess(m.loss(9,10,10.5),m.loss(12,10,10.5))

    def test_contract_five_rules_and_all_scenarios(self):
        c=m.read(m.RAW/'contract.json')
        self.assertEqual(c['rules'],m.RULES)
        self.assertEqual(c['uncertainty_q'],[0,1000,4000])
        self.assertEqual(c['bootstrap']['draws'],2000)
        self.assertFalse(c['write_manuscript'])


if __name__=='__main__':
    unittest.main()
