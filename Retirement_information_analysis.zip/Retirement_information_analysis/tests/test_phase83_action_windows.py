"""Analytical tests for constraint type, date filtering and unknown release."""
import json
from pathlib import Path
import unittest

from transition_assets.phase83_action_windows import assess_window, compare_ceilings

FIXTURE = json.loads((Path(__file__).parent / 'fixtures/phase83_action_windows.json').read_text())


class ActionWindowTests(unittest.TestCase):
    def assess(self, kind, asof='2024-06-01', mu=0, **kwargs):
        return assess_window(FIXTURE[kind], asof, FIXTURE['annual_co2_tonnes'],
                             FIXTURE['annual_net_mwh'], FIXTURE['capacity_mw'], mu, **kwargs)

    def test_next_day_and_leap_year_rate(self):
        r = self.assess('contract')
        self.assertEqual(r['action_date'], '2024-06-02')
        self.assertEqual(r['remaining_days'], 213)
        self.assertEqual(r['annual_days'], 366)
        self.assertEqual(r['net_accounting_tonnes_per_day'], 10)

    def test_availability_exclusive_expiry(self):
        r = self.assess('availability')
        self.assertEqual(r['earliest_not_blocked'], '2024-06-04')
        self.assertEqual(r['ceiling_days'], 211)
        self.assertEqual(r['net_exposure_ceiling_tonnes'], 2110)

    def test_future_order_not_leaked(self):
        self.assertEqual(self.assess('availability')['known_clause_ids'], ['known'])
        self.assertEqual(self.assess('availability', '2024-06-04')['ceiling_days'], 0)

    def test_contract_unknown_is_not_fixed_release(self):
        r = self.assess('contract')
        self.assertIsNone(r['earliest_not_blocked'])
        self.assertEqual(r['net_exposure_ceiling_tonnes'], 2130)
        self.assertEqual(r['benefit_lower_bound_tonnes'], 0)
        self.assertEqual(r['release_status'], 'not_identified')

    def test_known_release_not_silently_ignored(self):
        case = {**FIXTURE['contract'], 'clauses': [
            {'id': 'known_release', 'published': '2024-06-01', 'release_date': '2024-06-03'}]}
        with self.assertRaises(ValueError):
            assess_window(case, '2024-06-01', 3660, 1830, 10, 0)

    def test_late_document_excluded(self):
        r = self.assess('court', '2024-05-31')
        self.assertEqual(r['known_clause_ids'], [])
        self.assertIsNone(r['latest_operation_date'])
        self.assertEqual(r['ceiling_days'], 214)

    def test_court_inclusive_deadline(self):
        r = self.assess('court')
        self.assertEqual(r['latest_operation_date'], '2024-06-04')
        self.assertEqual(r['ceiling_days'], 3)
        self.assertEqual(r['excluded_forecast_tonnes'], 2100)

    def test_all_operation_deadline_alternative(self):
        r = self.assess('court', deadline_key='all_operation_end_inclusive')
        self.assertEqual(r['ceiling_days'], 5)

    def test_action_after_deadline(self):
        self.assertEqual(self.assess('court', '2024-06-05')['ceiling_days'], 0)

    def test_replacement_intensity_and_break_even_scaling(self):
        r = self.assess('court', mu=.4)
        self.assertEqual(r['net_accounting_tonnes_per_day'], 8)
        self.assertEqual(r['net_exposure_ceiling_tonnes'], 24)
        self.assertEqual(r['break_even_ceiling_per_mw_at_v100'], 240)

    def test_negative_net_accounting_rate_not_positive(self):
        r = self.assess('court', mu=3)
        self.assertEqual(r['signed_net_tonnes_per_day'], -5)
        self.assertEqual(r['net_exposure_ceiling_tonnes'], 0)

    def test_last_day_has_no_future_window(self):
        self.assertEqual(self.assess('contract', '2024-12-31')['ceiling_days'], 0)

    def test_nonleap_year_rate(self):
        case = {**FIXTURE['contract'], 'year': 2025, 'clauses': []}
        r = assess_window(case, '2024-12-31', 3650, 0, 10, 0)
        self.assertEqual(r['annual_days'], 365)
        self.assertEqual(r['remaining_days'], 365)
        self.assertEqual(r['window_forecast_tonnes'], 3650)

    def test_forecast_or_rating_invalid(self):
        for e, g, k, mu in [(-1, 0, 1, 0), (1, -1, 1, 0), (1, 0, 0, 0),
                            (1, 0, 1, -1), (float('nan'), 0, 1, 0)]:
            with self.subTest(e=e, g=g, k=k, mu=mu), self.assertRaises(ValueError):
                assess_window(FIXTURE['court'], '2024-06-01', e, g, k, mu)

    def test_snapshot_outside_year(self):
        with self.assertRaises(ValueError):
            self.assess('court', '2023-12-30')

    def test_bad_constraint_type(self):
        case = {**FIXTURE['contract'], 'constraint_type': 'any_rmr_is_a_mandate'}
        with self.assertRaises(ValueError):
            assess_window(case, '2024-06-01', 3660, 1830, 10, 0)

    def test_upper_ceiling_order_is_not_identified_project_order(self):
        r = compare_ceilings(self.assess('court'), self.assess('contract'))
        self.assertEqual(r['larger_ceiling_case'], 'contract')
        self.assertEqual(r['project_order'], 'not_identified')

    def test_positive_ceiling_versus_zero_is_only_weak_order(self):
        r = compare_ceilings(self.assess('availability', '2024-06-04'),
                             self.assess('contract', '2024-06-04'))
        self.assertEqual(r['project_order'], 'not_identified')
        self.assertEqual(r['larger_ceiling_case'], 'contract')

    def test_different_years_not_ranked(self):
        a, b = self.assess('court'), self.assess('contract')
        b['year'] = 2025
        with self.assertRaises(ValueError):
            compare_ceilings(a, b)

    def test_different_dates_not_ranked(self):
        with self.assertRaises(ValueError):
            compare_ceilings(self.assess('court'), self.assess('contract', '2024-06-02'))


if __name__ == '__main__':
    unittest.main()
