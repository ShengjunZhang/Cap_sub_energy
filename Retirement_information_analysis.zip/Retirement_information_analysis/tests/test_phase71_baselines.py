import copy
import unittest
from scripts.run_phase71_baselines import (
    year_hours, generation_rate, exposure_hours, baseline_values, decompose,
    top_weights, rank_comparison, monitor_year, build_panel, summarize, comparisons,
)


def gen(year, value=10.):
    return dict(plant='1', unit='A', year=year, frequency='M', duplicate=False,
                values=[value]*12, source='fixture', member='fixture', row=1)


def fixture():
    c=[dict(eia_plant_id='1',eia_generator_id='A',plant_name='Example',
        plant_state='TX',fuel_group='coal',eligibility_nameplate_capacity_mw='50',
        first_plan_snapshot_date='2020-12-31',initial_planned_retirement_date='2021-06-30')]
    h=[dict(key='1:A',snapshot='2020-12-31',inventory='operating',retirement=None,
        raw={'Planned Retirement Year':2021,'Planned Retirement Month':12},
        source='fixture',sheet='Operating',row=1)]
    g=[gen(y) for y in (2019,2020,2021)]
    return c,h,g


class Phase71Tests(unittest.TestCase):
    def test_leap_year(self):
        self.assertEqual(year_hours(2020),8784)

    def test_generation_negative_retained(self):
        self.assertLess(generation_rate(gen(2020,-1))[0],0)

    def test_missing_not_zero(self):
        r=gen(2020);r['values'][3]=None
        self.assertEqual(generation_rate(r),(None,'incomplete_months'))

    def test_frequency_duplicate(self):
        r=gen(2020);r['frequency']='AM'
        self.assertEqual(generation_rate(r)[1],'not_monthly_frequency')
        r['duplicate']=True
        self.assertEqual(generation_rate(r)[1],'duplicate')

    def test_exposure_month_boundary(self):
        self.assertEqual(exposure_hours(2020,'2021-01-31'),31*24)
        self.assertEqual(exposure_hours(2020,'2021-01-31',False),0)

    def test_exposure_expired_far_future(self):
        self.assertEqual(exposure_hours(2020,'2020-06-30'),0)
        self.assertEqual(exposure_hours(2020,'2024-01-31'),8760)

    def test_blank_plan_not_full(self):
        with self.assertRaises(ValueError):exposure_hours(2020,None)

    def test_decomposition(self):
        b=baseline_values(10,6,1000,2000,8760)
        d=decompose(10,6,1000,2000)
        self.assertEqual(d,{'date':8000.,'operation':-6000.})
        self.assertEqual(sum(d.values()),b['updated_recent']-b['initial_older'])

    def test_tied_cutoff(self):
        self.assertEqual(top_weights([10,5,5,0],2),[1.,.5,.5,0.])
        self.assertEqual(top_weights([0,0,0,0],1),[.25]*4)

    def test_rank_order_invariant(self):
        r=rank_comparison([10,5,5,0],[4,9,3,0],2)
        s=rank_comparison([0,5,5,10],[0,3,9,4],2)
        self.assertEqual(r['captured'],10.)
        self.assertAlmostEqual(r['captured'],s['captured'])

    def test_future_revisions_do_not_change_inputs(self):
        c,h,g=fixture();p,_=build_panel(c,h,g,[2020])
        hh=copy.deepcopy(h);future=copy.deepcopy(h[0]);future['snapshot']='2021-12-31'
        future['raw']['Planned Retirement Year']=2025;hh.append(future)
        q,_=build_panel(c,hh,g,[2020])
        self.assertEqual(p[0]['forecasts'],q[0]['forecasts'])

    def test_future_generation_changes_only_outcome(self):
        c,h,g=fixture();p,_=build_panel(c,h,g,[2020]);g[-1]['values']=[99.]*12
        q,_=build_panel(c,h,g,[2020])
        self.assertEqual(p[0]['forecasts'],q[0]['forecasts'])
        self.assertNotEqual(p[0]['actual'],q[0]['actual'])

    def test_missing_outcome_kept_in_coverage(self):
        c,h,g=fixture();p,l=build_panel(c,h,g[:-1],[2020])
        self.assertEqual(len(p),0);self.assertEqual(len(l),1)
        self.assertEqual(l[0]['status'],'outcome:no_generator_year')

    def test_future_announcement_excluded(self):
        c,h,g=fixture();c[0]['first_plan_snapshot_date']='2021-12-31'
        p,l=build_panel(c,h,g,[2020]);self.assertEqual(p,[]);self.assertEqual(l,[])

    def test_duplicate_year_key_rejected(self):
        c,h,g=fixture()
        with self.assertRaises(ValueError):build_panel(c,h,g+[g[0]],[2020])

    def test_monitor_missing_not_zero(self):
        self.assertIsNone(monitor_year({},('1','A'),2020,'co2_tonnes')[0])

    def test_monitor_conflict_and_coverage(self):
        import calendar
        mm={}
        for m in range(1,13):
            n=calendar.monthrange(2020,m)[1]
            mm[('1','A',f'2020-{m:02}')]=dict(expected_days=n,conflicting_days=0,
                conditional={'co2_tonnes':dict(value=0.,valid_days=n)})
        self.assertEqual(monitor_year(mm,('1','A'),2020,'co2_tonnes')[0],0.)
        mm[('1','A','2020-01')]['conflicting_days']=1
        self.assertIsNone(monitor_year(mm,('1','A'),2020,'co2_tonnes')[0])

    def test_zero_outcome_denominator(self):
        c,h,g=fixture();g[-1]['values']=[0.]*12;p,_=build_panel(c,h,g,[2020])
        self.assertIsNone(summarize(p)['rules']['updated_recent']['wape'])

    def test_bootstrap_results_json_serializable(self):
        import json
        c,h,g=fixture();p,_=build_panel(c,h,g,[2020]);q=copy.deepcopy(p[0]);q['plant']='2'
        json.dumps(comparisons(p+[q],20,3),allow_nan=False)


if __name__=='__main__':unittest.main()
