import unittest
from scripts.run_phase70_exit import utilization, exit_outcome, plan_transition, clustered_lpm, region, build_panel, design
import numpy as np

class ExitTests(unittest.TestCase):
    def record(self, **kw):
        return dict({'values':[100.0]*12, 'frequency':'M', 'duplicate':False, 'year':2020}, **kw)
    def test_leap_hours(self):
        self.assertAlmostEqual(utilization(self.record(),10)[0],1200/(10*8784))
    def test_blank_not_zero(self):
        self.assertIsNone(utilization(self.record(values=[None]+[0]*11),10)[0])
    def test_negative_net_retained(self):
        self.assertLess(utilization(self.record(values=[-2]*12),10)[0],0)
    def test_duplicate(self):
        self.assertIsNone(utilization(self.record(duplicate=True),10)[0])
    def test_frequency(self):
        self.assertIsNone(utilization(self.record(frequency='AM'),10)[0])
    def test_missing(self):
        self.assertIsNone(utilization(None,10)[0])
    def test_exit_boundaries(self):
        self.assertEqual(exit_outcome('2021-12-31','2020-12-31','2021-12-31',None),1)
        self.assertIsNone(exit_outcome('2020-12-31','2020-12-31','2021-12-31',None))
        self.assertEqual(exit_outcome('2022-01-31','2020-12-31','2021-12-31',None),0)
    def test_unobserved_not_survivor(self):
        self.assertIsNone(exit_outcome(None,'2020-12-31','2021-12-31','2020-12-31'))
        self.assertEqual(exit_outcome(None,'2020-12-31','2021-12-31','2021-12-31'),0)
    def test_blank_not_postponed(self):
        self.assertEqual(plan_transition('2021-05-31',None,'plan_blank',0),'blank')
    def test_transition(self):
        self.assertEqual(plan_transition('2021-05-31','2022-05-31','plan_future',0),'later')
        self.assertEqual(plan_transition('2021-05-31','2020-05-31','plan_future',0),'earlier')
        self.assertEqual(plan_transition('2021-05-31','2021-05-31','plan_future',0),'unchanged')
        self.assertEqual(plan_transition('2021-05-31',None,'missing_row',0),'missing_or_unknown')
        self.assertEqual(plan_transition('2021-05-31',None,'missing_row',1),'retired')
    def test_regions(self):
        self.assertEqual(region('NY'),'Northeast')
        self.assertEqual(region('TX'),'South')
        with self.assertRaises(ValueError): region('XX')
    def test_cluster_manual_against_library(self):
        import statsmodels.api as sm
        rng=np.random.default_rng(17); x=np.column_stack([np.ones(80),rng.normal(size=80)])
        y=(rng.random(80)<.4).astype(float); groups=np.repeat(np.arange(20),4)
        a=clustered_lpm(x,y,groups)
        b=sm.OLS(y,x).fit(cov_type='cluster',cov_kwds={'groups':groups},use_t=True)
        np.testing.assert_allclose(a['coef'],b.params,rtol=1e-10,atol=1e-12)
        np.testing.assert_allclose(a['cov'],b.cov_params(),rtol=1e-10,atol=1e-12)

    def fixture(self):
        u={'eia_plant_id':'1','eia_generator_id':'A','plant_name':'Fixture','plant_state':'TX',
           'commercial_operation_date':'1980-01-31','eligibility_nameplate_capacity_mw':'100',
           'fuel_group':'coal','first_plan_snapshot_date':'2020-12-31','initial_planned_retirement_date':'2022-12-31'}
        h=[{'key':'1:A','snapshot':s,'inventory':'operating','retirement':None,'raw':{},'row':2,'sheet':'Operating','source':'fixture'}
           for s in ['2019-12-31','2020-12-31','2021-12-31','2026-06-30']]
        c={'origins':[2019,2020,2021],'census':'2026-06-30'}
        return u,h,c
    def test_no_preannouncement_risk(self):
        u,h,c=self.fixture(); p,_=build_panel([u],h,[],c)
        self.assertEqual([r['year'] for r in p],[2020,2021])
    def test_missing_exact_row_not_carried(self):
        u,h,c=self.fixture(); h=[r for r in h if r['snapshot']!='2021-12-31']
        p,_=build_panel([u],h,[],c); self.assertEqual(len(p),1)
    def test_future_generation_not_predictor(self):
        u,h,c=self.fixture()
        g=dict(self.record(year=2025),plant='1',unit='A',source='fixture',member='x',sheet='x',row=1)
        p,_=build_panel([u],h,[g],c)
        self.assertTrue(all(r['util'] is None for r in p))
    def test_exit_before_origin_excluded(self):
        u,h,c=self.fixture(); h[-1].update(inventory='retired',retirement='2020-05-31')
        p,_=build_panel([u],h,[],c); self.assertEqual(p,[])
    def test_logit_marginal_gradient(self):
        from scipy.special import expit
        rng=np.random.default_rng(6); x=rng.normal(size=(70,4)); b=np.array([.2,-.3,.1,.15]); j=1
        p=expit(x@b); w=p*(1-p)
        grad=b[j]*np.mean((w*(1-2*p))[:,None]*x,axis=0); grad[j]+=w.mean()
        def f(z):
            q=expit(x@z); return z[j]*np.mean(q*(1-q))
        numeric=[]
        for k in range(4):
            e=np.eye(4)[k]*1e-6; numeric.append((f(b+e)-f(b-e))/(2e-6))
        np.testing.assert_allclose(grad,numeric,rtol=1e-7,atol=1e-9)

if __name__=='__main__': unittest.main()
