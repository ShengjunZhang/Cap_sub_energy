"""Packaging checks do not replace the scientific tests."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

SOURCE = Path(__file__).resolve().parents[1] / 'scripts/phase92_public_entry.py'
if not SOURCE.exists():
    SOURCE = Path(__file__).resolve().parents[1] / 'reproduce.py'
spec = importlib.util.spec_from_file_location('public_entry', SOURCE)
entry = importlib.util.module_from_spec(spec)
spec.loader.exec_module(entry)


class ReleaseTests(unittest.TestCase):
    def test_ignored_metadata_does_not_hide_result_changes(self):
        a = {'protected_files': 200, 'result': {'value': 2., 'query_count': 4}}
        b = {'protected_files': 12, 'result': {'value': 2., 'query_count': 4}}
        self.assertEqual(entry.scientific_view(a), entry.scientific_view(b))
        b['result']['query_count'] = 3
        self.assertNotEqual(entry.scientific_view(a), entry.scientific_view(b))

    def test_archive_metadata_only(self):
        self.assertEqual(entry.scientific_view({'frozen_files': 2, 'protected_file_count': 3, 'solver_gap': 4}),
                         {'solver_gap': 4})

    def test_missing_and_changed_inputs_fail(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            path = root / 'input.txt'
            path.write_text('frozen', encoding='utf-8')
            h = hashlib.sha256(path.read_bytes()).hexdigest()
            (root / 'INPUTS.json').write_text(json.dumps({'files': {'input.txt': h}}))
            self.assertEqual(entry.validate_inputs(root), 1)
            path.write_text('modified', encoding='utf-8')
            with self.assertRaises(ValueError):
                entry.validate_inputs(root)
            path.unlink()
            with self.assertRaises(ValueError):
                entry.validate_inputs(root)

    def test_path_outside_release_fails(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / 'INPUTS.json').write_text(json.dumps({'files': {'../outside': 'x'}}))
            with self.assertRaises(ValueError):
                entry.validate_inputs(root)

    def test_archive_extracts_only_expected_members(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            archive = root / 'data.zip'
            with zipfile.ZipFile(archive, 'w') as stream:
                stream.writestr('data/input.json', '{"x":2}')
            (root / 'ARCHIVES.json').write_text(json.dumps({'archives': {'data.zip': entry.digest(archive)}}))
            self.assertEqual(entry.extract_archives(root), 1)
            self.assertEqual(entry.read(root / 'data/input.json'), {'x': 2})
            self.assertEqual(entry.extract_archives(root), 0)

    def test_archive_traversal_and_changed_archive_fail(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            archive = root / 'data.zip'
            with zipfile.ZipFile(archive, 'w') as stream:
                stream.writestr('../outside', 'bad')
            index = root / 'ARCHIVES.json'
            index.write_text(json.dumps({'archives': {'data.zip': entry.digest(archive)}}))
            with self.assertRaises(ValueError):
                entry.extract_archives(root)
            index.write_text(json.dumps({'archives': {'data.zip': 'invalid'}}))
            with self.assertRaises(ValueError):
                entry.extract_archives(root)


if __name__ == '__main__':
    unittest.main()
