import itertools
import json
from pathlib import Path
import unittest
import numpy as np

from transition_assets.phase86_margins import exchange_decomposition, stability_radius, worst_regret

FIX = json.loads((Path(__file__).parent/'fixtures/phase86_margins.json').read_text())


def feasible(k, budget):
    return [np.array(x) for x in itertools.product([0, 1], repeat=len(k)) if np.dot(k, x) <= budget+1e-10]


class MarginTests(unittest.TestCase):
    def test_fixture_radii(self):
        for name in ['simple', 'unequal', 'tie', 'empty', 'singleton']:
            f = FIX[name]
            out = stability_radius(f['values'], f['capacity'], f['budget'], f['x'])
            if f['radius'] is None:
                self.assertEqual(out['status'], 'single_feasible_action')
                self.assertIsNone(out['upper'])
            else:
                self.assertLessEqual(out['lower'], f['radius']+1e-7)
                self.assertGreaterEqual(out['upper'], f['radius']-1e-7)
                self.assertLess(out['upper']-out['lower'], 1e-6)

    def test_random_radii_against_enumeration(self):
        rng = np.random.default_rng(86)
        for _ in range(18):
            k = rng.integers(1, 5, 5).astype(float)
            w = rng.integers(-8, 17, 5).astype(float)
            actions = feasible(k, 6)
            x = max(actions, key=lambda z: w@z)
            ratios = [float(w@(x-z)/np.dot(k, abs(x-z))) for z in actions if np.any(z != x)]
            expected = min(ratios)
            ans = stability_radius(w, k, 6, x)
            self.assertLessEqual(ans['lower'], expected+1e-6)
            self.assertGreaterEqual(ans['upper'], expected-1e-6)

    def test_perturbation_witness(self):
        f = FIX['unequal']; w=np.array(f['values']); k=np.array(f['capacity']); x=np.array(f['x'])
        ans = stability_radius(w, k, f['budget'], x)
        z = np.array(ans['witness'])
        rho = ans['upper']+0.01
        perturbed = w+rho*k*np.sign(z-x)
        self.assertGreater(perturbed@(z-x), 0)

    def test_box_regret_by_corner_enumeration(self):
        w = np.array([10., 8., -1.]); k=np.array([1., 2., 1.]); x=np.array([1, 0, 0]); rho=2.
        expected = max(float((w+rho*k*np.array(sign))@(z-x))
                       for sign in itertools.product([-1, 1], repeat=3) for z in feasible(k, 2))
        self.assertAlmostEqual(worst_regret(w, k, 2, x, rho)['value'], expected)

    def test_exact_loss_and_localisation(self):
        w=np.array([10., 8., 4.]); actual=np.array([2., 11., 100.]); x=np.array([1, 0, 1]); z=np.array([0, 1, 1])
        ans = exchange_decomposition(w, actual, [1, 1, 1], x, z)
        self.assertAlmostEqual(ans['loss'], 9.)
        self.assertAlmostEqual(ans['error_contrast']-ans['forecast_margin'], ans['loss'])
        self.assertAlmostEqual(ans['forecast_margin'], 2.)
        changed = actual.copy(); changed[2] += 5000
        self.assertEqual(exchange_decomposition(w, changed, [1, 1, 1], x, z)['loss'], ans['loss'])

    def test_lower_prediction_error_can_give_higher_loss(self):
        f=FIX['prediction_reversal']; a=np.array(f['actual']); b=np.array(f['better_mae']); c=np.array(f['worse_mae'])
        self.assertLess(abs(a-b).sum(), abs(a-c).sum())
        self.assertLess(a[np.argmax(b)], a[np.argmax(c)])

    def test_positive_radius_covers_every_small_box_corner(self):
        f=FIX['unequal']; w=np.array(f['values']); k=np.array(f['capacity']); x=np.array(f['x'])
        for sign in itertools.product([-1, 1], repeat=2):
            perturbed=w+2*k*np.array(sign)
            self.assertTrue(all(perturbed@x >= perturbed@z-1e-9 for z in feasible(k, 2)))

    def test_nonoptimal_stored_selection_has_no_positive_radius(self):
        ans=stability_radius([8, 10], [1, 1], 1, [1, 0])
        self.assertEqual(ans['lower'], 0)
        self.assertEqual(ans['upper'], 0)
        self.assertEqual(ans['status'], 'not_nominal_optimum')

    def test_invalid_selection_is_rejected(self):
        with self.assertRaises(ValueError): stability_radius([8, 10], [1, 1], 1, [1, 1])
        with self.assertRaises(ValueError): worst_regret([8, 10], [1, 1], 1, [1, 0], -1)

    def test_shared_cost_cancels_from_error(self):
        a=np.array([8., 12.]); b=np.array([5., 7.]); k=np.array([1., 2.]); x=[0, 1]; z=[1, 0]
        first=exchange_decomposition(b, a, k, x, z)
        second=exchange_decomposition(b-3*k, a-3*k, k, x, z)
        self.assertAlmostEqual(first['error_contrast'], second['error_contrast'])

    def test_nonbinary_reference_is_rejected_before_conversion(self):
        with self.assertRaises(ValueError):
            exchange_decomposition([10, 8], [9, 7], [1, 1], [1, 0], [0.5, 0])


if __name__ == '__main__': unittest.main()
