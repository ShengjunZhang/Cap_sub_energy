import copy
import json
from pathlib import Path
import unittest

import numpy as np
from scripts import run_phase76_plan_weight as m

ROOT = Path(__file__).resolve().parents[1]
FIX = json.loads((ROOT/'tests/fixtures/phase76_plan_weight.json').read_text())


def row(year=2021, actual=75, plant='a'):
    return dict(key=plant+':1', plant=plant, outcome_year=year, year=year-1,
                origin=str(year-1)+'-12-31', actual=actual, capacity_mw=10,
                forecasts=dict(persistence=100., updated_recent=0.),
                full_hours=8760, hours1=0)


class Phase76Tests(unittest.TestCase):
    def test_exact_fixtures(self):
        for f in FIX['fits']:
            fit = m.fit_weight(f['p'], f['u'], f['y'])
            np.testing.assert_allclose(fit['interval'], f['interval'], atol=1e-12)
            self.assertAlmostEqual(fit['weight'], f['interval'][0])

    def test_unidentified(self):
        f = m.fit_weight([20], [20], [4])
        self.assertFalse(f['identified'])
        self.assertEqual(f['weight'], 0)

    def test_empty_rejected(self):
        with self.assertRaises(ValueError): m.fit_weight([], [], [])

    def test_nonfinite_rejected(self):
        with self.assertRaises(ValueError): m.fit_weight([1], [0], [float('nan')])

    def test_shape_rejected(self):
        with self.assertRaises(ValueError): m.fit_weight([1, 2], [0], [3, 4])

    def test_negative_multiplicity_rejected(self):
        with self.assertRaises(ValueError): m.fit_weight([1], [0], [0], [-1])

    def test_cluster_multiplicity(self):
        f = m.fit_weight([10, 10], [0, 0], [2, 8], [3, 1])
        self.assertAlmostEqual(f['weight'], .8)

    def test_zero_weight_rows_do_not_identify(self):
        f = m.fit_weight([10, 20], [0, 20], [2, 7], [0, 1])
        self.assertFalse(f['identified'])

    def test_inactive_rows_cannot_change_weight(self):
        a = m.fit_weight([100], [0], [75])
        b = m.fit_weight([100, 999], [0, 999], [75, -500])
        self.assertEqual(a['weight'], b['weight'])

    def test_blend_endpoints(self):
        self.assertEqual(m.blend(100, 20, 0), 100)
        self.assertEqual(m.blend(100, 20, 1), 20)

    def test_invalid_blend_weight(self):
        with self.assertRaises(ValueError): m.blend(100, 20, 1.01)

    def test_same_weight_emissions(self):
        f = m.fit_weight([100], [0], [75])
        self.assertAlmostEqual(m.blend(200, 40, f['weight']), 160)

    def test_split_counts_and_isolation(self):
        rows = [row(2021), row(2022), row(2023), row(2025)]
        a, b = m.split_rows(rows)
        self.assertEqual([x['outcome_year'] for x in a], [2021, 2022])
        self.assertEqual([x['outcome_year'] for x in b], [2023, 2025])
        self.assertEqual(m.fit_training(a)['weight'], .25)
        with self.assertRaises(ValueError): m.fit_training(b)

    def test_test_outcome_cannot_change_fit(self):
        rows = [row(2021), row(2022), row(2023)]
        a = m.fit_training(m.split_rows(rows)[0])
        rows[-1]['actual'] = 1e15
        b = m.fit_training(m.split_rows(rows)[0])
        self.assertEqual(a, b)

    def test_unapproved_year_rejected(self):
        with self.assertRaises(ValueError): m.split_rows([row(2026)])

    def test_duplicate_rejected(self):
        with self.assertRaises(ValueError): m.split_rows([row(), row()])

    def test_calendar_exposure(self):
        for f in FIX['date_hours']:
            self.assertEqual(m.exposure_hours(f['year'], f['plan']), f['hours'])

    def test_month_included(self):
        self.assertEqual(m.exposure_hours(2023, '2023-03-31'), 2160)

    def test_equal_forecasts_remain_equal(self):
        for a in [0, .25, 1]: self.assertEqual(m.blend(15, 15, a), 15)

    def test_signed_generation_not_clipped(self):
        self.assertEqual(m.blend(-10, -2, .5), -6)

    def test_bootstrap_same_plant_count(self):
        p, draws = m.cluster_draws([row(2021), row(2023), row(2022, plant='b')], 20, 76)
        self.assertEqual(p, ['a', 'b'])
        self.assertEqual(draws.shape, (20, 2))
        np.testing.assert_array_equal(draws.sum(axis=1), np.full(20, 2))
        np.testing.assert_array_equal(draws, m.cluster_draws([row(), row(plant='b')], 20, 76)[1])

    def test_metrics_zero_denominator(self):
        z = m.metrics(np.array([0.]), np.array([0.]), np.array([10.]))
        self.assertIsNone(z['wape'])
        self.assertEqual(z['mae'], 0)

    def test_contract(self):
        c = m.read(m.RAW/'contract.json')
        self.assertEqual(c['training_outcome_years'], [2021, 2022])
        self.assertEqual(c['test_outcome_years'], [2023, 2024, 2025])
        self.assertFalse(c['write_manuscript'])
        self.assertFalse(c['acquire_data'])
        self.assertEqual(c['bootstrap']['draws'], 2000)

    def test_strict_threshold_not_tolerance_based(self):
        q = 1000.
        self.assertFalse(bool(m.decision.action(q, q)))
        self.assertTrue(bool(m.decision.action(np.nextafter(q, np.inf), q)))

    def test_fitted_scores_use_declared_representation(self):
        r = dict(capacity_mw=7.3, g_actual=50., e_actual=80.,
                 g_forecasts={b:31.7 for b in m.decision.RULES},
                 e_forecasts={b:76.1 for b in m.decision.RULES})
        r['g_forecasts']['updated_recent'] = 13.9
        r['e_forecasts']['updated_recent'] = 24.6
        p, obs, k = m.decision_arrays([r], .819486461403628, .4)
        expected = p['persistence']+.819486461403628*(p['updated_recent']-p['persistence'])
        np.testing.assert_array_equal(p['blend'], expected)
        self.assertFalse(bool(m.decision.action(p['blend'][0], p['blend'][0])))

    def test_audit_json_round_trip(self):
        audit = m.audit(*m.load_inputs())
        self.assertEqual(audit, json.loads(json.dumps(audit, allow_nan=False)))
        self.assertEqual(audit['summary']['all']['date_active'], 30)
        self.assertEqual(audit['summary']['all']['different_predictions'], 29)


if __name__ == '__main__':
    unittest.main()
