import copy
import numpy as np
import unittest
from transition_assets.phase80_calibration import calibrated_values


def row(year, fuel, residual, capacity=10):
    return {'outcome_year': year, 'fuel': fuel, 'capacity_mw': capacity,
            'e_actual': 100 + residual * capacity, 'g_actual': 20,
            'e_forecasts': {'persistence': 100},
            'g_forecasts': {'persistence': 20}}


def test_only_past_years_and_known_quantiles():
    train = [row(2022, 'coal', v) for v in (0, 10, 20)]
    test = [row(2023, 'coal', 10000)]
    med, scenarios, meta = calibrated_values(train + test, test, 2023, 'persistence', 0, 0)
    assert meta['training_n'] == 3
    assert meta['training_years'] == [2022]
    np.testing.assert_allclose(med, [200 / 1e6])
    np.testing.assert_allclose(np.unique(scenarios[:, 0]), np.array([120, 200, 280]) / 1e6)


def test_test_outcomes_do_not_enter_selection():
    panel = [row(2022, 'coal', 1), row(2022, 'gas', 3), row(2023, 'coal', 10)]
    first = calibrated_values(panel, panel[2:], 2023, 'persistence', .4, 1000)
    changed = copy.deepcopy(panel)
    changed[-1]['e_actual'] = 1e15
    changed[-1]['g_actual'] = 1e14
    second = calibrated_values(changed, changed[2:], 2023, 'persistence', .4, 1000)
    np.testing.assert_array_equal(first[0], second[0])
    np.testing.assert_array_equal(first[1], second[1])
    assert first[2] == second[2]


def test_fuel_fallback_and_common_cost():
    train = [row(2022, 'coal', 2)]
    test = [row(2023, 'gas', 100)]
    a = calibrated_values(train + test, test, 2023, 'persistence', .4, 0)
    b = calibrated_values(train + test, test, 2023, 'persistence', .4, 1000)
    assert a[2]['fuel']['gas']['fallback'] is True
    np.testing.assert_allclose(a[0] - b[0], [0.01])
    assert a[2] == b[2]
    assert a[1].shape == (9, 1)


def test_no_training_and_invalid_fuel_rejected():
    test = [row(2023, 'coal', 0)]
    with unittest.TestCase().assertRaisesRegex(ValueError, 'preceding'):
        calibrated_values(test, test, 2023, 'persistence', 0, 0)
    with unittest.TestCase().assertRaisesRegex(ValueError, 'fuel'):
        calibrated_values([row(2022, 'coal', 1)], [row(2023, 'oil', 1)], 2023, 'persistence', 0, 0)


def load_tests(loader, tests, pattern):
    return unittest.TestSuite(unittest.FunctionTestCase(f) for f in (
        test_only_past_years_and_known_quantiles,
        test_test_outcomes_do_not_enter_selection,
        test_fuel_fallback_and_common_cost,
        test_no_training_and_invalid_fuel_rejected))
