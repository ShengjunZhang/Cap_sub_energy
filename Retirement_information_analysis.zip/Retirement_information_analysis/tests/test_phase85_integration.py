import json
from pathlib import Path
import unittest
import itertools
import numpy as np

from transition_assets.phase85_integration import compare_losses, evaluate_corrected, panel_counts
from scripts.run_phase79_portfolios import evaluate_case
from transition_assets.phase85_solver_v2 import solve_nominal, solve_regret


FIXTURE = json.loads((Path(__file__).parent/'fixtures/phase85_integration.json').read_text())


def row(key, year, e, forecast):
    return dict(key=key, year=year-1, outcome_year=year, plant=key.split(':')[0], fuel='coal',
                capacity_mw=1, origin=f'{year-1}-12-31', initial_plan=f'{year}-12-31',
                current_plan=f'{year}-12-31', strict_complete=False,
                historical_identity_validated=False, outcome_exit=False,
                g_actual=0, e_actual=e,
                g_forecasts={k: 0 for k in ['initial_older','updated_older','initial_recent','updated_recent','persistence']},
                e_forecasts={k: forecast for k in ['initial_older','updated_older','initial_recent','updated_recent','persistence']})


class IntegrationTests(unittest.TestCase):
    def test_new_solver_matches_exhaustive_nominal(self):
        capacity=np.array([1.,2.,3.,4.]); values=np.array([4.,-1.,9.,10.])
        feasible=[np.array(x) for x in itertools.product([0,1],repeat=4) if capacity@x<=5]
        best=max(values@x for x in feasible)
        answer=solve_nominal(values,capacity,5)
        self.assertAlmostEqual(answer['value'],best)
        self.assertAlmostEqual(answer['resource'],min(capacity@x for x in feasible if values@x==best))

    def test_new_solver_matches_exhaustive_regret(self):
        capacity=np.array([1.,2.,3.,4.])
        values=np.array([[4.,-1.,9.,10.],[8.,7.,2.,-3.],[0.,4.,6.,5.]])
        feasible=[np.array(x) for x in itertools.product([0,1],repeat=4) if capacity@x<=5]
        optima=np.array([max(v@x for x in feasible) for v in values])
        regrets=[max(optima-values@x) for x in feasible]
        answer=solve_regret(values,capacity,5)
        self.assertAlmostEqual(answer['max_regret'],min(regrets))
        best_mean=max((values@x).mean() for x,r in zip(feasible,regrets) if r==min(regrets))
        self.assertAlmostEqual(answer['mean_value'],best_mean)

    def test_zero_objective_selects_no_capacity(self):
        answer=solve_nominal([0.,0.,-1.],[1.,1.,1.],2)
        self.assertEqual(answer['x'],[0,0,0])

    def test_loss_counts_and_tolerance(self):
        cases = [dict(methods={'base': {'observed_regret_mt': 2},
                              'new': {'observed_regret_mt': 2-d}}) for d in FIXTURE['comparison_deltas']]
        out = compare_losses(cases, 'new', 'base')
        self.assertEqual([out[k] for k in ['lower','higher','ties']], [1,1,2])

    def test_panel_counts_do_not_require_original_140(self):
        rows = [row('1:A', 2022, 3, 2), row('1:A', 2023, 4, 3), row('2:B', 2023, 2, 2)]
        out = panel_counts(rows)
        self.assertEqual(out['rows'], 3); self.assertEqual(out['generators'], 2)
        self.assertEqual(out['plants'], 2); self.assertEqual(out['unique_capacity_mw'], 2)

    def test_duplicate_origin_rejected(self):
        r = row('1:A', 2022, 3, 2)
        with self.assertRaises(ValueError): panel_counts([r, r])

    def test_annual_selection_unchanged_by_current_outcome(self):
        r = [row('1:A', 2023, 30, 10), row('2:B', 2023, 1, 2)]
        before = evaluate_case(r, 2023, 0, 0, .5)
        r[0]['e_actual'] = 0
        after = evaluate_case(r, 2023, 0, 0, .5)
        for name in before['methods']:
            self.assertEqual(before['methods'][name]['x'], after['methods'][name]['x'])

    def test_corrected_stresses_use_earlier_years_only(self):
        panel = [row('1:A', 2022, 3, 2), row('1:A', 2023, 4, 3), row('2:B', 2023, 2, 2)]
        old = evaluate_case(panel[1:], 2023, 0, 0, .5)
        answer = evaluate_corrected(panel, old, ['updated_recent','persistence'])
        self.assertEqual(answer['calibration']['updated_recent']['training_years'], [2022])
        self.assertEqual(answer['calibration']['updated_recent']['training_n'], 1)
        panel[1]['e_actual'] = 999
        changed = evaluate_corrected(panel, old, ['updated_recent','persistence'])
        self.assertEqual(answer['calibration']['updated_recent']['fuel'], changed['calibration']['updated_recent']['fuel'])
        for name in answer['methods']:
            self.assertEqual(answer['methods'][name]['x'], changed['methods'][name]['x'])

    def test_obsolete_prediction_not_treated_as_new_observation(self):
        r = row('1:A', 2023, 30, 10)
        r['e_forecasts']['initial_older'] = 0
        answer = evaluate_case([r], 2023, 0, 0, 1)
        self.assertEqual(answer['methods']['initial_older']['x'], [0])
        self.assertEqual(answer['methods']['persistence']['x'], [1])


if __name__ == '__main__': unittest.main()
