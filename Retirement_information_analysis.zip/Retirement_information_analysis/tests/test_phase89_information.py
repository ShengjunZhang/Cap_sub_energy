import itertools
import json
from pathlib import Path
import unittest

import numpy as np

from transition_assets.phase89_information import (
    exchange_cover, minimum_records, revealed_intervals,
)

FIX = json.loads((Path(__file__).parent / 'fixtures/phase89_information.json').read_text())


def actions(k, budget):
    return [np.array(x) for x in itertools.product([0, 1], repeat=len(k))
            if np.dot(k, x) <= budget + 1e-10]


def exhaustive(f, epsilon=0, value_complete=False, costs=None):
    k = np.array(f['capacities']); x = np.array(f['x'])
    lo = np.array(f['lower']); hi = np.array(f['upper'])
    costs = np.ones(len(k)) if costs is None else np.array(costs)
    best = np.inf
    for bits in itertools.product([0, 1], repeat=len(k)):
        s = np.array(bits)
        if value_complete and np.any((x == 1) & (hi > lo) & (s == 0)):
            continue
        l, u = revealed_intervals(lo, hi, f['target'], s)
        regret = max(float(np.where(z-x > 0, u, l) @ (z-x))
                     for z in actions(k, f['budget']))
        if regret <= epsilon + 1e-9:
            best = min(best, float(costs @ s))
    return best


class InformationTests(unittest.TestCase):
    def solve(self, f, **kwargs):
        return minimum_records(f['lower'], f['upper'], f['target'],
                               f['capacities'], f['budget'], f['x'], **kwargs)

    def test_exchange_identity_for_every_query_subset(self):
        f = FIX['signed']; x = np.array(f['x'])
        for z in actions(f['capacities'], f['budget']):
            a, gamma = exchange_cover(f['lower'], f['upper'], f['target'], x, z)
            for bits in itertools.product([0, 1], repeat=3):
                s = np.array(bits)
                l, u = revealed_intervals(f['lower'], f['upper'], f['target'], s)
                direct = float(np.where(z-x > 0, u, l) @ (z-x))
                self.assertAlmostEqual(a-gamma@s, direct)
                self.assertTrue(np.all(gamma >= 0))

    def test_action_and_value_tasks_are_distinct(self):
        f = FIX['action_value_gap']
        a = self.solve(f); v = self.solve(f, value_complete=True)
        self.assertEqual(a['query_count'], 0)
        self.assertEqual(v['query_count'], 2)

    def test_complementarity_prevents_submodularity(self):
        f = FIX['complementary']; x = np.array(f['x'])
        def bound(bits):
            l, u = revealed_intervals(f['lower'], f['upper'], f['target'], bits)
            return max(float(np.where(z-x > 0, u, l) @ (z-x))
                       for z in actions(f['capacities'], f['budget']))
        r0 = bound([0, 0, 0])
        self.assertEqual(r0-bound([0, 1, 0]), 0)
        self.assertEqual(r0-bound([0, 0, 1]), 0)
        self.assertEqual(r0-bound([0, 1, 1]), 1)
        self.assertEqual(self.solve(f)['query_count'], 2)

    def test_signed_values_and_infeasible_units(self):
        f = FIX['signed']; ans = self.solve(f)
        self.assertEqual(ans['query_count'], exhaustive(f))
        self.assertNotIn(2, ans['queried_indices'])

    def test_point_intervals_do_not_require_queries(self):
        f = dict(lower=[1, -2], upper=[1, -2], target=[1, -2],
                 capacities=[1, 1], budget=1, x=[1, 0])
        self.assertEqual(self.solve(f, value_complete=True)['query_count'], 0)

    def test_empty_and_unique_action(self):
        f = dict(lower=[0, -1], upper=[100, 1], target=[80, 1],
                 capacities=[1, 1], budget=0, x=[0, 0])
        self.assertEqual(self.solve(f)['query_count'], 0)

    def test_ties_need_not_identify_a_unique_portfolio(self):
        f = FIX['zero_answer']; ans = self.solve(f)
        self.assertEqual(ans['query_count'], 2)
        self.assertLessEqual(ans['regret_upper'], 1e-8)

    def test_additive_tolerance_changes_information_requirement(self):
        f = FIX['complementary']
        self.assertEqual(self.solve(f, epsilon=1)['query_count'], 0)
        self.assertEqual(self.solve(f, epsilon=.5)['query_count'], 2)

    def test_positive_costs_are_supported(self):
        f = FIX['signed']; c = [2, 1, 7]
        ans = self.solve(f, costs=c)
        self.assertEqual(ans['objective'], exhaustive(f, costs=c))

    def test_known_feasible_query_set_is_retained_as_upper_bound(self):
        f = FIX['complementary']
        ans = self.solve(f, feasible_queries=[1, 2], max_iterations=1)
        self.assertEqual(ans['query_count'], 2)
        self.assertLessEqual(ans['regret_upper'], 1e-8)
        with self.assertRaises(ValueError):
            self.solve(f, feasible_queries=[1])

    def test_small_seeded_problems_match_full_enumeration(self):
        rng = np.random.default_rng(890)
        for _ in range(12):
            k = rng.integers(1, 4, 4)
            lo = rng.integers(-4, 2, 4).astype(float)
            hi = lo + rng.integers(0, 7, 4)
            w = np.array([rng.integers(int(l), int(u)+1) for l, u in zip(lo, hi)])
            feasible = actions(k, 4); x = max(feasible, key=lambda z: w@z)
            f = dict(lower=lo, upper=hi, target=w, capacities=k, budget=4, x=x)
            for full in [False, True]:
                ans = self.solve(f, value_complete=full)
                self.assertEqual(ans['objective'], exhaustive(f, value_complete=full))
                self.assertEqual(ans['status'], 'optimal')
                self.assertAlmostEqual(ans['objective'], ans['lower_bound'])

    def test_negative_selected_lower_bounds_force_queries(self):
        f = FIX['signed']; ans = self.solve(f)
        self.assertIn(0, ans['queried_indices'])

    def test_nonoptimal_target_portfolio_cannot_be_verified(self):
        f = dict(FIX['signed'], x=[0, 1, 0])
        with self.assertRaises(ValueError): self.solve(f)

    def test_invalid_inputs_are_rejected(self):
        f = FIX['signed']
        for change in [dict(upper=[-4, 3, 100]), dict(target=[5, -2, 80]),
                       dict(x=[.5, 0, 0]), dict(capacities=[0, 1, 100])]:
            with self.assertRaises(ValueError): self.solve(dict(f, **change))
        with self.assertRaises(ValueError): self.solve(f, epsilon=-1)
        with self.assertRaises(ValueError): self.solve(f, costs=[0, 1, 1])


if __name__ == '__main__': unittest.main()
