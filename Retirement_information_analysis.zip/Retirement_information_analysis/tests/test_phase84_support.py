import copy
import json
from pathlib import Path
import unittest

from transition_assets.phase84_support import (
    annual_support, reported_annual_support, origin_grid, stage_counts, project_margin_interval)
from scripts.run_phase84_support import annual_panel


FIXTURE = json.loads((Path(__file__).parent / 'fixtures/phase84_support.json').read_text())


class AnnualSupportTests(unittest.TestCase):
    def test_am_is_annual_sensitivity_only(self):
        r = FIXTURE['annual_record']
        out = annual_support(r, 78, True)
        self.assertEqual(out['status'], 'complete')
        self.assertEqual(out['annual_mwh'], 78)
        self.assertAlmostEqual(out['rate_mw'], 78 / 8784)

    def test_missing_not_zero(self):
        self.assertEqual(annual_support(None, None, False)['status'], 'no_generator_year')
        r = copy.deepcopy(FIXTURE['annual_record']); r['values'][0] = None
        self.assertEqual(annual_support(r, 77, True)['status'], 'incomplete_months')

    def test_zero_is_valid(self):
        r = copy.deepcopy(FIXTURE['annual_record']); r['values'] = [0] * 12
        self.assertEqual(annual_support(r, 0, True)['annual_mwh'], 0)

    def test_duplicate_excluded(self):
        r = copy.deepcopy(FIXTURE['annual_record']); r['duplicate'] = True
        self.assertEqual(annual_support(r, 78, True)['status'], 'duplicate')

    def test_unknown_frequency_excluded(self):
        r = copy.deepcopy(FIXTURE['annual_record']); r['frequency'] = 'A'
        self.assertEqual(annual_support(r, 78, True)['status'], 'unsupported_frequency')

    def test_raw_mismatch_excluded(self):
        self.assertEqual(annual_support(FIXTURE['annual_record'], 78, False)['status'], 'raw_row_mismatch')

    def test_total_mismatch_excluded(self):
        self.assertEqual(annual_support(FIXTURE['annual_record'], 79, True)['status'], 'annual_total_mismatch')

    def test_missing_annual_total_excluded(self):
        self.assertEqual(annual_support(FIXTURE['annual_record'], None, True)['status'], 'missing_annual_total')

    def test_negative_not_clipped(self):
        r = copy.deepcopy(FIXTURE['annual_record']); r['values'] = [-1] * 12
        self.assertEqual(annual_support(r, -12, True)['annual_mwh'], -12)

    def test_tolerance_boundary(self):
        r = FIXTURE['annual_record']
        self.assertEqual(annual_support(r, 78 + 0.0000009, True)['status'], 'complete')
        self.assertEqual(annual_support(r, 78 + 0.000002, True)['status'], 'annual_total_mismatch')


class ReportedAnnualTests(unittest.TestCase):
    def test_reported_total_not_imputed_months(self):
        r = copy.deepcopy(FIXTURE['annual_record']); r['values'][0] = None
        before = copy.deepcopy(r)
        out = reported_annual_support(r, 78, True)
        self.assertEqual(out['annual_mwh'], 78)
        self.assertEqual(r, before)
        self.assertEqual(annual_support(r, 78, True)['status'], 'incomplete_months')

    def test_negative_annual_preserved(self):
        self.assertEqual(reported_annual_support(FIXTURE['annual_record'], -1, True)['annual_mwh'], -1)

    def test_missing_total_not_zero(self):
        self.assertEqual(reported_annual_support(FIXTURE['annual_record'], None, True)['status'], 'missing_annual_total')

    def test_duplicate_and_raw_mismatch_excluded(self):
        r = copy.deepcopy(FIXTURE['annual_record']); r['duplicate'] = True
        self.assertEqual(reported_annual_support(r, 78, True)['status'], 'duplicate')
        self.assertEqual(reported_annual_support(FIXTURE['annual_record'], 78, False)['status'], 'raw_row_mismatch')


class SampleSupportTests(unittest.TestCase):
    def test_full_grid_and_exit_stratum(self):
        rows = origin_grid(FIXTURE['cohort'], FIXTURE['history'], [2020, 2021, 2022])
        self.assertEqual(len(rows), 3)
        self.assertEqual([r['risk_eligible'] for r in rows], [False, True, False])
        self.assertEqual(rows[0]['origin_status'], 'before_first_qualifying_snapshot')
        self.assertEqual(rows[1]['exit_stratum'], 'recorded_outcome_exit')
        self.assertEqual(rows[2]['origin_status'], 'inventory:registered_retired')

    def test_no_exit_does_not_imply_physical_continuation(self):
        h = copy.deepcopy(FIXTURE['history'])
        for r in h:
            r['inventory'] = 'operating'; r['retirement'] = ''
            r['raw'] = {'Planned Retirement Month': '12', 'Planned Retirement Year': '2028'}
        rows = origin_grid(FIXTURE['cohort'], h, [2021])
        self.assertEqual(rows[0]['exit_stratum'], 'no_recorded_outcome_exit')

    def test_unique_units_and_repeated_mw_separate(self):
        rows = [{'key': '1:A', 'plant': '1', 'capacity_mw': 10},
                {'key': '1:A', 'plant': '1', 'capacity_mw': 10},
                {'key': '2:B', 'plant': '2', 'capacity_mw': 20}]
        out = stage_counts(rows)
        self.assertEqual(out['rows'], 3); self.assertEqual(out['units'], 2)
        self.assertEqual(out['unique_capacity_mw'], 30)
        self.assertEqual(out['repeated_origin_capacity_mw'], 40)

    def test_inconsistent_capacity_rejected(self):
        with self.assertRaises(ValueError):
            stage_counts([{'key': '1:A', 'plant': '1', 'capacity_mw': 10},
                          {'key': '1:A', 'plant': '1', 'capacity_mw': 11}])


class ProjectWindowTests(unittest.TestCase):
    def test_ceiling_below_cost_rejects_positive_margin(self):
        out = project_margin_interval(0, 100, 50, 6000)
        self.assertEqual(out['carbon_margin_status'], 'nonpositive_under_fixed_inputs')
        self.assertEqual(out['margin_upper_currency'], -1000)

    def test_unknown_release_preserves_indeterminate_margin(self):
        self.assertEqual(project_margin_interval(0, 100, 50, 1000)['carbon_margin_status'], 'unresolved')

    def test_positive_lower_margin_not_feasibility(self):
        out = project_margin_interval(50, 100, 50, 1000)
        self.assertEqual(out['carbon_margin_status'], 'positive_under_fixed_inputs')
        self.assertFalse(out['physical_feasibility_established'])

    def test_cost_tie_not_positive(self):
        out = project_margin_interval(0, 100, 50, 5000)
        self.assertEqual(out['carbon_margin_status'], 'nonpositive_under_fixed_inputs')

    def test_bad_interval_rejected(self):
        for args in [(100, 50, 50, 0), (0, 100, -1, 0), (0, 100, 50, -1)]:
            with self.assertRaises(ValueError): project_margin_interval(*args)


class AnnualPanelTests(unittest.TestCase):
    def inputs(self):
        generation, validation = [], []
        for year in [2020, 2021, 2022]:
            r = dict(copy.deepcopy(FIXTURE['annual_record']), year=year)
            generation.append(r)
            validation.append(dict(key='1:A', year=year, **annual_support(r, 78, True)))
        coverage = [dict(key='1:A', year=2021, outcome_year=2022, operating_years=[2020, 2021],
                         current_plan='2022-06-30', initial_plan='2022-12-31')]
        return generation, validation, coverage

    def test_frequency_preserved_and_leap_rate(self):
        generation, validation, coverage = self.inputs()
        before = copy.deepcopy(generation)
        panel, ledger = annual_panel(coverage, generation, validation)
        self.assertEqual(generation, before)
        self.assertEqual(panel[0]['generation_sources'][0]['frequency'], 'AM')
        self.assertAlmostEqual(panel[0]['forecasts']['initial_older'], 78*365/366)
        self.assertAlmostEqual(panel[0]['forecasts']['updated_recent'], 78*181/365)
        self.assertEqual(ledger[0]['status'], 'complete')

    def test_no_outcome_report_not_zero(self):
        generation, validation, coverage = self.inputs()
        panel, ledger = annual_panel(coverage, generation[:-1], validation[:-1])
        self.assertEqual(panel, [])
        self.assertEqual(ledger[0]['status'], 'outcome:no_generator_year')

    def test_annual_total_does_not_fill_missing_month(self):
        generation, validation, coverage = self.inputs()
        generation[-1]['values'][5] = None
        validation[-1] = dict(key='1:A', year=2022, **annual_support(generation[-1], 78, True))
        panel, ledger = annual_panel(coverage, generation, validation)
        self.assertEqual(panel, [])
        self.assertEqual(ledger[0]['status'], 'outcome:incomplete_months')

    def test_blank_plan_stays_unavailable(self):
        generation, validation, coverage = self.inputs()
        coverage[0]['current_plan'] = None
        panel, ledger = annual_panel(coverage, generation, validation)
        self.assertEqual(panel, [])
        self.assertEqual(ledger[0]['status'], 'blank_current_plan')


if __name__ == '__main__':
    unittest.main()
