"""Analytical accounting checks; no historical outcome tuning."""
import json
from pathlib import Path
import unittest

import numpy as np

from transition_assets.phase81_diagnostic import attribution, diagnose, exchange, plan_state


FIXTURE = json.loads((Path(__file__).parent / 'fixtures/phase81_exchange.json').read_text())


class DiagnosticTests(unittest.TestCase):
    def test_signed_exchange_fixture(self):
        f = FIXTURE
        r = exchange(f['keys'], f['capacity'], f['observed'], f['before'], f['after'], f['limit'])
        self.assertAlmostEqual(r['enter_value_mt'], f['expected_entered'])
        self.assertAlmostEqual(r['drop_value_mt'], f['expected_dropped'])
        self.assertAlmostEqual(r['delta_mt'], f['expected_delta'])
        self.assertEqual([x['key'] for x in r['entries']], ['A', 'B', 'C', 'D'])
        self.assertAlmostEqual(sum(x['contribution_mt'] for x in r['entries']), 5.)

    def test_symmetric_attribution_fixture(self):
        r = attribution(FIXTURE['values'])
        self.assertAlmostEqual(r['date_mt'], 3.)
        self.assertAlmostEqual(r['rate_mt'], 2.)
        self.assertAlmostEqual(r['interaction_mt'], 2.)
        self.assertAlmostEqual(r['date_mt'] + r['rate_mt'], r['joint_mt'])

    def test_interaction_is_not_third_additive_term(self):
        r = attribution(FIXTURE['values'])
        self.assertNotAlmostEqual(r['date_mt'] + r['rate_mt'] + r['interaction_mt'], r['joint_mt'])

    def test_swap_factors_swaps_attributions(self):
        v = FIXTURE['values'].copy()
        v['updated_older'], v['initial_recent'] = v['initial_recent'], v['updated_older']
        r = attribution(v)
        self.assertAlmostEqual(r['date_mt'], 2.)
        self.assertAlmostEqual(r['rate_mt'], 3.)

    def test_constant_values_zero(self):
        r = attribution({k: 2. for k in FIXTURE['values']})
        for value in r.values():
            self.assertEqual(value, 0.)

    def test_permutation_preserves_totals(self):
        f = FIXTURE
        a = exchange(f['keys'], f['capacity'], f['observed'], f['before'], f['after'], f['limit'])
        p = [3, 1, 0, 2]
        b = exchange(*[[f[name][i] for i in p] for name in
                        ['keys', 'capacity', 'observed', 'before', 'after']], f['limit'])
        self.assertEqual(a['delta_mt'], b['delta_mt'])
        self.assertEqual(a['entries'], b['entries'])

    def test_same_portfolio_empty_exchange(self):
        r = exchange(['A'], [1.], [-2.], [1], [1], 1.)
        self.assertEqual(r['entries'], [])
        self.assertEqual(r['delta_mt'], 0.)

    def test_tied_value_does_not_imply_identical_membership(self):
        r = exchange(['A', 'B'], [1., 1.], [2., 2.], [1, 0], [0, 1], 1.)
        self.assertEqual(r['delta_mt'], 0.)
        self.assertEqual(r['changed_units'], 2)

    def test_negative_selected_value_kept(self):
        r = exchange(['A'], [1.], [-2.], [1], [0], 1.)
        self.assertEqual(r['drop_value_mt'], -2.)
        self.assertEqual(r['delta_mt'], 2.)

    def test_invalid_arrays_rejected(self):
        args = [['A'], [1.], [2.], [0], [1], 1.]
        for index, value in [(0, ['A', 'A']), (1, [0.]), (2, [float('nan')]),
                             (3, [.5]), (4, [2]), (5, -1.)]:
            changed = args.copy()
            changed[index] = value
            with self.subTest(index=index), self.assertRaises(ValueError):
                exchange(*changed)

    def test_infeasible_portfolio_rejected(self):
        with self.assertRaises(ValueError):
            exchange(['A'], [2.], [1.], [0], [1], 1.)

    def test_invalid_factorial_value_rejected(self):
        v = FIXTURE['values'].copy()
        v['initial_older'] = float('inf')
        with self.assertRaises(ValueError):
            attribution(v)

    def test_plan_date_boundaries(self):
        r = {'origin': '2021-12-31', 'outcome_year': 2022,
             'initial_plan': '2021-12-31', 'current_plan': '2022-12-31'}
        self.assertEqual(plan_state(r), {'initial_state': 'elapsed', 'current_state': 'horizon',
                                        'revision': 'later'})
        r['initial_plan'] = '2023-01-01'
        self.assertEqual(plan_state(r)['initial_state'], 'later')
        self.assertEqual(plan_state(r)['revision'], 'earlier')

    def test_random_exchange_and_attribution_identities(self):
        rng = np.random.default_rng(811009)
        for _ in range(30):
            w = rng.normal(size=8)
            a, b = rng.integers(0, 2, size=(2, 8))
            r = exchange([str(i) for i in range(8)], np.ones(8), w, a, b, 8.)
            self.assertAlmostEqual(r['delta_mt'], float(w @ (b-a)))
            v = dict(zip(FIXTURE['values'], rng.normal(size=4)))
            s = attribution(v)
            self.assertAlmostEqual(s['date_mt'] + s['rate_mt'], s['joint_mt'])

    def test_case_attribution_and_group_totals(self):
        names = ['initial_older', 'updated_older', 'initial_recent', 'updated_recent', 'persistence']
        selections = [[1, 0], [0, 1], [1, 0], [0, 1], [0, 1]]
        case = {'year': 2022, 'mu': .4, 'q': 0., 'fraction': .5, 'n': 2, 'limit_mw': 1.,
                'keys': ['A', 'B'], 'capacities': [1., 1.], 'observed_values_mt': [2., 3.],
                'forecast_values_mt': [[4., 0.], [4., 5.], [6., 0.], [6., 7.], [6., 7.]],
                'reference_x': [0, 1],
                'methods': {name: {'x': x} for name, x in zip(names, selections)}}
        rows = [{'key': name, 'plant': name, 'fuel': 'coal', 'capacity_mw': 1.,
                 'origin': '2021-12-31', 'outcome_year': 2022, 'initial_plan': initial,
                 'current_plan': '2023-12-31', 'outcome_exit': False,
                 'g_actual': 1., 'g_forecasts': {'persistence': 2.}}
                for name, initial in [('A', '2023-12-31'), ('B', '2021-12-31')]]
        r = diagnose(case, rows, [['initial_older', 'updated_recent']])
        self.assertEqual(r['attribution']['date_mt'], 1.)
        self.assertEqual(r['attribution']['rate_mt'], 0.)
        # The unchanged-score project is displaced by the date-active project.
        self.assertEqual(r['group_attribution']['date_score_changed']['False']['date_mt'], -2.)
        self.assertEqual(r['group_attribution']['date_score_changed']['True']['date_mt'], 3.)
        self.assertEqual(r['regret_sources']['initial_older']['regret_mt'], 1.)
        self.assertEqual(r['transitions']['initial_older->updated_recent']['delta_mt'], 1.)
        with self.assertRaises(ValueError):
            diagnose(case, rows[:1], [['initial_older', 'updated_recent']])
        rows[0]['outcome_year'] = 2023
        with self.assertRaises(ValueError):
            diagnose(case, rows, [['initial_older', 'updated_recent']])


if __name__ == '__main__':
    unittest.main()
