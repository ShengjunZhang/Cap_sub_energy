import itertools
import json
from pathlib import Path
import unittest
import numpy as np

from transition_assets.phase87_review import (
    interval_regret, next_record, review_path, exposure_bounds, nominal_selection,
)

FIX = json.loads((Path(__file__).parent/'fixtures/phase87_review.json').read_text())


def feasible(k, budget):
    return [np.array(x) for x in itertools.product([0, 1], repeat=len(k))
            if np.dot(k, x) <= budget+1e-10]


class ReviewTests(unittest.TestCase):
    def path(self, f, policy='exchange_width', seed=8700):
        queries = []
        def answer(i):
            queries.append(i)
            return f['updated'][i]
        out = review_path(f['initial'], f['lower'], f['upper'],
                          f['capacities'], f['budget'], answer, policy,
                          disagreement=np.ones(len(f['initial'])), seed=seed)
        self.assertEqual(queries, out['queried_indices'])
        return out

    def test_separation_matches_all_corners_and_actions(self):
        rng = np.random.default_rng(87)
        for _ in range(12):
            k = rng.integers(1, 4, 4).astype(float)
            lo = rng.integers(-6, 6, 4).astype(float)
            hi = lo + rng.integers(0, 9, 4)
            actions = feasible(k, 5)
            for x in actions:
                expected = max(float(np.where(s, hi, lo)@(z-x))
                    for s in itertools.product([0, 1], repeat=4) for z in actions)
                ans = interval_regret(lo, hi, k, 5, x)
                self.assertAlmostEqual(ans['value'], expected, places=7)
                self.assertGreaterEqual(ans['upper']+1e-7, expected)

    def test_zero_bound_works_for_empty_and_unique_action(self):
        f = FIX['signed']
        p = self.path(f)
        self.assertEqual(p['queries_to_stop'], 0)
        self.assertEqual(p['states'][0]['x'], [0, 0])
        ans = interval_regret([0, 0], [100, 100], [1, 1], 0, [0, 0])
        self.assertEqual(ans['value'], 0)

    def test_nominal_objective_and_capacity_tie_against_enumeration(self):
        rng=np.random.default_rng(870)
        for _ in range(15):
            k=rng.integers(1,5,5).astype(float); w=rng.integers(-5,12,5).astype(float)
            actions=feasible(k,7); optimum=max(float(w@z) for z in actions)
            resource=min(float(k@z) for z in actions if abs(w@z-optimum)<1e-9)
            ans=nominal_selection(w,k,7)
            self.assertAlmostEqual(ans['value'],optimum)
            self.assertAlmostEqual(float(k@ans['x']),resource)

    def test_stopping_implies_optimal_updated_forecast(self):
        for policy in ['exchange_width', 'interval_width', 'capacity',
                       'initial_disagreement', 'random']:
            f = FIX['two_items']; p = self.path(f, policy)
            x = np.array(p['states'][-1]['x']); a = np.array(f['updated'])
            best = max(float(a@z) for z in feasible(f['capacities'], f['budget']))
            self.assertAlmostEqual(float(a@x), best)
            self.assertLessEqual(p['states'][-1]['regret_upper'], 1e-7)

    def test_queries_never_repeat(self):
        p = self.path(FIX['two_items'])
        self.assertEqual(len(p['queried_indices']), len(set(p['queried_indices'])))

    def test_every_policy_skips_known_infeasible_single_units(self):
        f = dict(initial=[10,8,100], updated=[7,12,99], lower=[0,0,0],
                 upper=[10,12,100], capacities=[1,1,100], budget=1)
        for policy in ['exchange_width','interval_width','capacity',
                       'initial_disagreement','random']:
            self.assertNotIn(2, self.path(f,policy)['queried_indices'])

    def test_priority_has_no_unrevealed_values_argument(self):
        import inspect
        args = set(inspect.signature(next_record).parameters)
        self.assertFalse({'actual', 'updated', 'outcomes', 'exit'} & args)
        f = FIX['two_items']; other = dict(f, updated=[2, 11])
        self.assertEqual(self.path(f)['queried_indices'][0],
                         self.path(other)['queried_indices'][0])

    def test_revealing_a_forecast_does_not_reveal_outcome(self):
        f = FIX['forecast_not_outcome']; p = self.path(f)
        x = np.array(p['states'][-1]['x']); actual = np.array(f['actual'])
        self.assertEqual(p['states'][0]['x'], [1, 0])
        self.assertEqual(x.tolist(), [0, 1])
        self.assertGreater(max(actual)-actual@x, 0)
        self.assertLessEqual(p['states'][-1]['regret_upper'], 1e-7)

    def test_exposure_bounds_preserve_signed_rates_and_cost(self):
        lo, hi = exposure_bounds([3, -2, 0], [1, 2, 3], 1e6)
        np.testing.assert_allclose(lo, [-1, -4, -3])
        np.testing.assert_allclose(hi, [2, -2, -3])

    def test_fixed_action_bound_decreases_with_nested_intervals(self):
        a = interval_regret([0, 0], [10, 12], [1, 1], 1, [1, 0])
        b = interval_regret([7, 0], [7, 12], [1, 1], 1, [1, 0])
        self.assertLessEqual(b['value'], a['value'])

    def test_random_order_is_reproducible(self):
        self.assertEqual(self.path(FIX['two_items'], 'random'),
                         self.path(FIX['two_items'], 'random'))

    def test_invalid_bounds_selection_or_answer_are_rejected(self):
        with self.assertRaises(ValueError):
            interval_regret([2, 0], [1, 1], [1, 1], 1, [1, 0])
        with self.assertRaises(ValueError):
            interval_regret([0, 0], [1, 1], [1, 1], 1, [.5, 0])
        with self.assertRaises(ValueError):
            interval_regret([0, 0], [1, 1], [1, 1], 1, [1, 1])
        f = FIX['two_items']
        with self.assertRaises(ValueError):
            review_path(f['initial'], f['lower'], f['upper'], f['capacities'],
                        f['budget'], lambda i: 100, 'exchange_width')

    def test_gain_of_any_selection_is_bounded_by_interval_regret(self):
        f = FIX['two_items']; x=np.array([1, 0]); w=np.array(f['updated'])
        bound = interval_regret(f['lower'], f['upper'], f['capacities'], f['budget'], x)
        self.assertTrue(all(w@(z-x) <= bound['upper']+1e-7
                            for z in feasible(f['capacities'], f['budget'])))


if __name__ == '__main__': unittest.main()
