import json
from pathlib import Path
import unittest

from transition_assets.phase82_windows import (
    clean_daily_record, index_daily, known_orders, closure_lower_bound,
    forecast_window, full_day_membership, validate_orders,
    sum_records,
)

ROOT = Path(__file__).resolve().parents[1]


class WindowTests(unittest.TestCase):
    def setUp(self):
        self.orders = json.loads((ROOT / 'data/raw/phase82/orders.json').read_text())
        self.fixture = json.loads((ROOT / 'tests/fixtures/phase82_windows.json').read_text())

    def test_all_frozen_snapshots(self):
        for expected in self.fixture['snapshots']:
            with self.subTest(expected['asof']):
                result = forecast_window(self.orders, expected['asof'],
                                         self.fixture['annual_tonnes'], 2025,
                                         self.fixture['plan_end_inclusive'])
                self.assertEqual(result['known_orders'], expected['known'])
                self.assertEqual(result['closure_lower_bound'], expected['lower_bound'])
                self.assertEqual(result['remaining_days'], expected['remaining_days'])
                self.assertEqual(result['outside_blocking_days'], expected['outside_days'])
                self.assertEqual(result['outside_blocking_forecast_tonnes'],
                                 expected['outside_days'] * 1000)

    def test_future_orders_do_not_change_earlier_forecast(self):
        a = forecast_window(self.orders[:1], '2025-05-23', 365000, 2025, '2025-05-31')
        b = forecast_window(self.orders, '2025-05-23', 365000, 2025, '2025-05-31')
        self.assertEqual(a, b)

    def test_effective_and_expiry_boundaries(self):
        inside, partial = full_day_membership(self.orders, '2025-05-23')
        self.assertEqual(inside, [])
        self.assertEqual(partial, ['202-25-3'])
        self.assertEqual(full_day_membership(self.orders, '2025-05-24')[0], ['202-25-3'])
        self.assertEqual(full_day_membership(self.orders, '2025-08-21')[0], ['202-25-7'])
        self.assertEqual(full_day_membership(self.orders, '2025-11-18'), ([], ['202-25-7']))
        self.assertEqual(full_day_membership(self.orders, '2025-11-19')[0], ['202-25-9'])
        self.assertEqual(full_day_membership(self.orders, '2026-02-17')[0], [])

    def test_known_future_obligation_blocks_irreversible_exit(self):
        order = dict(self.orders[1], issued='2025-04-01T00:00:00-04:00')
        self.assertEqual(closure_lower_bound([order], '2025-05-01'), '2025-11-19')

    def test_expired_obligation_does_not_block(self):
        self.assertEqual(closure_lower_bound(self.orders[:1], '2025-08-21'), '2025-08-21')

    def test_order_validation(self):
        self.assertEqual(len(validate_orders(self.orders)), 3)
        for bad in [self.orders + [self.orders[0]],
                    [dict(self.orders[0], expires='2025-05-23T14:00:00-04:00')],
                    [dict(self.orders[0], issued='2025-05-24T00:00:00-04:00')]]:
            with self.assertRaises(ValueError):
                validate_orders(bad)

    def test_known_order_date_is_inclusive_at_end_of_day(self):
        self.assertEqual(known_orders(self.orders, '2025-05-22'), [])
        self.assertEqual([r['id'] for r in known_orders(self.orders, '2025-05-23')], ['202-25-3'])

    def test_overlaps_return_membership_without_double_count_instruction(self):
        extra = dict(self.orders[0], id='overlap')
        inside, partial = full_day_membership(self.orders + [extra], '2025-06-01')
        self.assertEqual(set(inside), {'202-25-3', 'overlap'})
        self.assertFalse(partial)

    def test_invalid_forecast_input(self):
        for value in [-1, float('nan')]:
            with self.assertRaises(ValueError):
                forecast_window(self.orders, '2025-05-23', value, 2025, '2025-05-31')
        with self.assertRaises(ValueError):
            forecast_window(self.orders, '2026-01-01', 1, 2025, '2025-05-31')

    def test_fixed_action_date_extension_comparison(self):
        before = forecast_window(self.orders[:1], '2025-08-20', 365000, 2025, '2025-05-31')
        after = forecast_window(self.orders, '2025-08-20', 365000, 2025, '2025-05-31')
        self.assertEqual(before['remaining_forecast_tonnes'], after['remaining_forecast_tonnes'])
        self.assertEqual(before['outside_blocking_forecast_tonnes']
                         - after['outside_blocking_forecast_tonnes'], 90000)

    def test_zero_exposure_after_expiry_does_not_zero_forecast(self):
        result = forecast_window(self.orders, '2025-11-18', 365000, 2025, '2025-05-31')
        self.assertEqual(result['outside_blocking_forecast_tonnes'], 0)
        self.assertEqual(result['remaining_forecast_tonnes'], 43000)


class DailyTests(unittest.TestCase):
    def row(self, **updates):
        r = {'Facility ID': '1710', 'Unit ID': '1', 'Date': '2025-01-01',
             'Sum of the Operating Time': '24', 'CO2 Mass (short tons)': '100',
             'Gross Load (MWh)': '500'}
        r.update(updates)
        return r

    def test_unit_conversion(self):
        r = clean_daily_record(self.row())
        self.assertAlmostEqual(r['co2_tonnes'], 90.718474)
        self.assertEqual(r['gross_mwh'], 500)
        self.assertFalse(r['structural_co2_zero'])

    def test_zero_operating_blank_is_explicit_zero(self):
        r = clean_daily_record(self.row(**{'Sum of the Operating Time': '0',
                                         'CO2 Mass (short tons)': '', 'Gross Load (MWh)': ''}))
        self.assertEqual(r['co2_tonnes'], 0)
        self.assertTrue(r['structural_co2_zero'])

    def test_positive_or_missing_operation_does_not_zero_missing_co2(self):
        for hours in ['24', '']:
            r = clean_daily_record(self.row(**{'Sum of the Operating Time': hours,
                                             'CO2 Mass (short tons)': ''}))
            self.assertIsNone(r['co2_tonnes'])
            self.assertFalse(r['structural_co2_zero'])

    def test_invalid_numeric_or_date(self):
        for update in [{'CO2 Mass (short tons)': '-1'},
                       {'CO2 Mass (short tons)': 'nan'}, {'Date': 'nonsense'},
                       {'Sum of the Operating Time': '25'}]:
            with self.assertRaises(ValueError):
                clean_daily_record(self.row(**update))

    def test_duplicate_identity_days_rejected(self):
        r = clean_daily_record(self.row())
        with self.assertRaises(ValueError):
            index_daily([r, r])

    def test_order_independent_daily_index(self):
        a = clean_daily_record(self.row())
        b = clean_daily_record(self.row(**{'Unit ID': '2'}))
        self.assertEqual(index_daily([a, b]), index_daily([b, a]))

    def test_missing_co2_prevents_complete_total(self):
        a = clean_daily_record(self.row())
        b = clean_daily_record(self.row(**{'Unit ID': '2', 'CO2 Mass (short tons)': ''}))
        result = sum_records([a, b])
        self.assertIsNone(result['co2_tonnes'])
        self.assertEqual(result['missing_co2_unit_days'], 1)

    def test_empty_window_is_not_missing_measurement(self):
        result = sum_records([])
        self.assertEqual(result['unit_days'], 0)
        self.assertEqual(result['co2_tonnes'], 0)

    def test_positive_co2_with_zero_hours_is_flagged(self):
        result = clean_daily_record(self.row(**{'Sum of the Operating Time': '0'}))
        self.assertTrue(result['positive_co2_zero_hours'])
        self.assertGreater(result['co2_tonnes'], 0)


if __name__ == '__main__':
    unittest.main()
