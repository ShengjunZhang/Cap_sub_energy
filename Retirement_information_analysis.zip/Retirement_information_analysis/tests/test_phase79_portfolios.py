"""Independent small-instance checks for baseline-regret selection."""
import itertools
from copy import deepcopy
import unittest

import numpy as np

from transition_assets.phase79_portfolios import solve_nominal, solve_regret


def enumerate_portfolios(values, capacities, budget):
    values = np.atleast_2d(values)
    feasible = []
    for bits in itertools.product((0, 1), repeat=len(capacities)):
        x = np.asarray(bits)
        if np.dot(capacities, x) <= budget + 1e-10:
            feasible.append(x)
    X = np.asarray(feasible)
    payoffs = X @ values.T
    optima = payoffs.max(axis=0)
    regrets = (optima - payoffs).max(axis=1)
    minimum = regrets.min()
    best_mean = payoffs.mean(axis=1)[np.isclose(regrets, minimum, atol=1e-7)].max()
    return minimum, best_mean, optima


class PortfolioTests(unittest.TestCase):
    def test_hedging_fixture(self):
        values = np.array([[10., 0., 6.], [0., 10., 6.]])
        result = solve_regret(values, np.ones(3), 1.)
        np.testing.assert_array_equal(result['x'], [0, 0, 1])
        self.assertAlmostEqual(result['max_regret'], 4.)

    def test_nominal_is_knapsack_not_rank_truncation(self):
        result = solve_nominal(np.array([9., 6., 5.]), np.array([2., 1., 1.]), 2.)
        np.testing.assert_array_equal(result['x'], [0, 1, 1])
        self.assertAlmostEqual(result['value'], 11.)

    def test_zero_budget(self):
        result = solve_regret(np.array([[3., 8.], [6., 2.]]), np.ones(2), 0.)
        self.assertEqual(sum(result['x']), 0)
        self.assertAlmostEqual(result['max_regret'], 0.)

    def test_negative_payoffs_allow_no_intervention(self):
        result = solve_regret(np.array([[-3., -2.], [-5., -1.]]), np.ones(2), 2.)
        self.assertEqual(sum(result['x']), 0)
        self.assertAlmostEqual(result['max_regret'], 0.)

    def test_duplicate_scenario_does_not_change_primary_regret(self):
        values = np.array([[10., 0., 6.], [0., 10., 6.]])
        a = solve_regret(values, np.ones(3), 1.)
        b = solve_regret(np.vstack([values, values[0]]), np.ones(3), 1.)
        self.assertAlmostEqual(a['max_regret'], b['max_regret'])

    def test_small_random_instances_against_enumeration(self):
        rng = np.random.default_rng(791008)
        for _ in range(18):
            values = rng.integers(-4, 12, size=(3, 5)).astype(float)
            capacities = rng.integers(1, 4, size=5).astype(float)
            budget = float(rng.integers(0, int(capacities.sum()) + 1))
            minimum, best_mean, optima = enumerate_portfolios(values, capacities, budget)
            result = solve_regret(values, capacities, budget)
            self.assertAlmostEqual(result['max_regret'], minimum, places=6)
            self.assertAlmostEqual(result['mean_value'], best_mean, places=6)
            np.testing.assert_allclose(result['optima'], optima, atol=1e-7)
            self.assertLessEqual(np.dot(capacities, result['x']), budget + 1e-7)

    def test_permuted_candidates_have_same_objective(self):
        values = np.array([[7., 1., 5.], [0., 8., 6.]])
        capacities = np.array([1., 2., 1.])
        a = solve_regret(values, capacities, 2.)
        permutation = [2, 0, 1]
        b = solve_regret(values[:, permutation], capacities[permutation], 2.)
        self.assertAlmostEqual(a['max_regret'], b['max_regret'])
        self.assertAlmostEqual(a['mean_value'], b['mean_value'])

    def test_invalid_capacities_rejected(self):
        with self.assertRaises(ValueError):
            solve_regret(np.array([[1., 2.]]), np.array([0., 1.]), 1.)

    def test_outcomes_cannot_change_selection_features(self):
        from scripts.run_phase79_portfolios import features, RULES
        row = {'capacity_mw': 100., 'e_actual': 1000., 'g_actual': 2000.,
               'e_forecasts': {b: 500. for b in RULES},
               'g_forecasts': {b: 300. for b in RULES}}
        changed = deepcopy(row)
        changed['e_actual'] = 1e12
        changed['g_actual'] = 0.
        a = features([row], 0.4, 1000.)
        b = features([changed], 0.4, 1000.)
        np.testing.assert_array_equal(a[0], b[0])
        np.testing.assert_array_equal(a[1], b[1])


if __name__ == '__main__':
    unittest.main()
