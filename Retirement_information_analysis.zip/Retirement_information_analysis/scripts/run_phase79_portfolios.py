"""Run the fixed Omega application using existing paired operating records."""
import argparse
import csv
from collections import Counter
import hashlib
import json
from pathlib import Path
import platform
import sys

import numpy as np
import scipy
from scipy.optimize._highspy._core import HIGHS_VERSION_MAJOR, HIGHS_VERSION_MINOR, HIGHS_VERSION_PATCH

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from transition_assets.phase79_portfolios import OPTIONS, solve_nominal, solve_regret

RAW = ROOT / 'data/raw/phase79'
OUT = ROOT / 'data/processed/phase79'
RULES = ['initial_older', 'updated_older', 'initial_recent', 'updated_recent', 'persistence']


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n',
                    encoding='utf-8')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def freeze():
    target = RAW / 'inputs.json'
    if target.exists():
        raise ValueError('The Phase79 input freeze already exists')
    files = {ROOT / 'data/processed/phase73/panel.json', RAW / 'contract.json'}
    for folder in [ROOT / 'manuscript', ROOT / 'submission_ere_v5_3_2026-09-30',
                   ROOT / 'author_review_ere_v5_3_2026-09-30']:
        if folder == ROOT / 'manuscript':
            candidates = [p for p in folder.glob('ere*') if p.is_dir()]
        else:
            candidates = [folder]
        for candidate in candidates:
            files.update(p for p in candidate.rglob('*') if p.is_file())
    for phase in (68, 70, 71, 73, 76):
        folder = ROOT / f'data/processed/phase{phase}'
        if folder.exists():
            files.update(p for p in folder.rglob('*') if p.is_file())
    frozen = {p.relative_to(ROOT).as_posix(): digest(p) for p in sorted(files)}
    write(target, {'date': '2026-10-08', 'files': frozen})
    print('Frozen', len(frozen), 'inherited files and the experiment contract', flush=True)


def check_preservation():
    frozen = read(RAW / 'inputs.json')['files']
    bad = [p for p, h in frozen.items() if not (ROOT / p).is_file() or digest(ROOT / p) != h]
    if bad:
        raise ValueError('Inherited input changed: ' + ', '.join(bad[:5]))
    return len(frozen)


def features(rows, mu, q):
    capacities = np.array([r['capacity_mw'] for r in rows])
    forecasts = np.array([[r['e_forecasts'][b] - mu * r['g_forecasts'][b] - q * r['capacity_mw']
                           for r in rows] for b in RULES]) / 1e6
    return capacities, forecasts


def evaluate_case(rows, year, mu, q, fraction):
    capacities, forecasts = features(rows, mu, q)
    limit = float(capacities.sum() * fraction)
    nominal = [solve_nominal(v, capacities, limit) for v in forecasts]
    optima = np.array([s['value'] for s in nominal])
    robust = solve_regret(forecasts, capacities, limit, optima)
    observed = np.array([r['e_actual'] - mu * r['g_actual'] - q * r['capacity_mw']
                         for r in rows]) / 1e6
    reference = solve_nominal(observed, capacities, limit)
    methods = {}
    for name, solution in [*zip(RULES, nominal), ('minimax_regret', robust)]:
        x = np.array(solution['x'])
        scenario_values = forecasts @ x
        actual_value = float(observed @ x)
        certificate_gap = (solution['max_regret'] - solution['dual_regret']
                           if name == 'minimax_regret' else solution['dual_value'] - solution['value'])
        methods[name] = {
            'keys': [r['key'] for r, selected in zip(rows, x) if selected],
            'x': x.tolist(), 'selected_units': int(x.sum()),
            'capacity_mw': float(capacities @ x),
            'scenario_values_mt': scenario_values.tolist(),
            'max_baseline_regret_mt': float(np.maximum(0, optima - scenario_values).max()),
            'observed_value_mt': actual_value,
            'observed_regret_mt': max(0., float(reference['value'] - actual_value)),
            'solver_gap': solution['gap'],
            'solver_absolute_gap_mt': max(0., float(certificate_gap))}
    # Outcome coverage is evaluated after selections have been computed.
    low, high = forecasts.min(axis=0), forecasts.max(axis=0)
    in_range = (observed >= low - 1e-9) & (observed <= high + 1e-9)
    return {'year': year, 'mu': mu, 'q': q, 'fraction': fraction, 'n': len(rows),
            'capacity_mw': float(capacities.sum()), 'limit_mw': limit,
            'keys': [r['key'] for r in rows], 'capacities': capacities.tolist(),
            'forecast_values_mt': forecasts.tolist(), 'observed_values_mt': observed.tolist(),
            'scenario_optima_mt': optima.tolist(),
            'reference_value_mt': reference['value'], 'reference_x': reference['x'],
            'reference_solver_gap': reference['gap'],
            'reference_absolute_gap_mt': max(0., reference['dual_value'] - reference['value']),
            'methods': methods, 'in_baseline_range_rows': int(in_range.sum()),
            'in_baseline_range_capacity_share': float(capacities[in_range].sum() / capacities.sum())}


def comparison(cases, comparator):
    delta = np.array([c['methods'][comparator]['observed_regret_mt'] -
                      c['methods']['minimax_regret']['observed_regret_mt'] for c in cases])
    tolerance = 1e-7
    base = sum(c['methods'][comparator]['observed_regret_mt'] for c in cases)
    return {'cases': len(cases), 'lower_loss': int((delta > tolerance).sum()),
            'higher_loss': int((delta < -tolerance).sum()),
            'ties': int((np.abs(delta) <= tolerance).sum()),
            'mean_improvement_mt': float(delta.mean()),
            'median_improvement_mt': float(np.median(delta)),
            'minimum_improvement_mt': float(delta.min()),
            'maximum_improvement_mt': float(delta.max()),
            'sum_improvement_fraction': float(delta.sum() / base) if base > 0 else None}


def run():
    count = check_preservation()
    c = read(RAW / 'contract.json')
    rows = read(ROOT / c['panel'])
    if len(rows) != 140 or len({(r['key'], r['year']) for r in rows}) != 140:
        raise ValueError('The inherited paired sample has changed')
    cases = []
    for year in c['years']:
        group = sorted([r for r in rows if r['outcome_year'] == year], key=lambda r: r['key'])
        for mu in c['replacement_intensities']:
            for q in c['carbon_equivalent_costs']:
                for fraction in c['capacity_fractions']:
                    cases.append(evaluate_case(group, year, mu, q, fraction))
        print('Finished primary year', year, 'cases', len(cases), flush=True)
    central = [x for x in cases if all(x[k] == v for k, v in c['central'].items())]
    sensitivities = {'omitted_baselines': [], 'prospective_initial': [], 'leave_plant_out': []}
    for case in central:
        year = case['year']
        group = sorted([r for r in rows if r['outcome_year'] == year], key=lambda r: r['key'])
        k = np.array(case['capacities'])
        values = np.array(case['forecast_values_mt'])
        actual = np.array(case['observed_values_mt'])
        for excluded, name in enumerate(RULES):
            keep = [i for i in range(len(RULES)) if i != excluded]
            answer = solve_regret(values[keep], k, case['limit_mw'],
                                  np.array(case['scenario_optima_mt'])[keep])
            x = np.array(answer['x'])
            sensitivities['omitted_baselines'].append({
                'year': year, 'omitted': name, 'selected_keys': [r['key'] for r, z in zip(group, x) if z],
                'observed_regret_mt': max(0., float(case['reference_value_mt'] - actual @ x)),
                'full_set_max_regret_mt': float((np.array(case['scenario_optima_mt']) - values @ x).max()),
                'reduced_set_max_regret_mt': answer['max_regret']})
        prospective = [r for r in group if r['initial_plan'] > r['origin']]
        if prospective:
            sensitivities['prospective_initial'].append(evaluate_case(prospective, year, **c['central']))
        for plant in sorted({r['plant'] for r in group}):
            subset = [r for r in group if r['plant'] != plant]
            if subset:
                result = evaluate_case(subset, year, **c['central'])
                result['omitted_plant'] = plant
                sensitivities['leave_plant_out'].append(result)
        print('Finished sensitivity year', year, flush=True)
    summary = {
        'primary_cases': len(cases), 'comparisons': {b: comparison(cases, b) for b in RULES},
        'central_comparisons': {b: comparison(central, b) for b in RULES},
        'annual_comparisons': {str(y): {b: comparison([c for c in cases if c['year'] == y], b)
                                      for b in RULES} for y in c['years']},
        'prospective_comparisons': {b: comparison(sensitivities['prospective_initial'], b) for b in RULES},
        'leave_plant_out_comparisons': {b: comparison(sensitivities['leave_plant_out'], b) for b in RULES},
        'central': [{k: v for k, v in x.items() if k not in
                     ('forecast_values_mt', 'observed_values_mt', 'reference_x')} for x in central],
        'empirical_range_coverage': float(np.mean([x['in_baseline_range_rows'] / x['n']
                                                  for x in cases])),
        'aggregation': 'Descriptive sensitivity grid, not independent samples or a statistical effect estimate',
        'algorithm_claim': 'Established minimax regret; application to inherited baseline disagreement'}
    coverage = {'observations': len(rows), 'generators': len({r['key'] for r in rows}),
                'plants': len({r['plant'] for r in rows}),
                'years': dict(Counter(r['outcome_year'] for r in rows)),
                'strict_complete': sum(r['strict_complete'] for r in rows),
                'historically_validated_links': sum(r['historical_identity_validated'] for r in rows),
                'outcome_exits': sum(r['outcome_exit'] for r in rows),
                'future_initial': sum(r['initial_plan'] > r['origin'] for r in rows),
                'selection': 'The existing complete paired sample underrepresents recorded exits'}
    products = {'results': cases, 'summary': summary, 'sensitivities': sensitivities,
                'coverage': coverage}
    for name, value in products.items():
        write(OUT / (name + '.json'), value)
    with (OUT / 'selections.csv').open('w', encoding='utf-8', newline='') as stream:
        fields = ['year', 'mu', 'q', 'fraction', 'method', 'key', 'selected']
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for case in cases:
            for method, result in case['methods'].items():
                for key, selected in zip(case['keys'], result['x']):
                    writer.writerow({**{k: case[k] for k in fields[:4]},
                                     'method': method, 'key': key, 'selected': selected})
    write(OUT / 'environment.json', {'python': platform.python_version(), 'scipy': scipy.__version__,
                                     'numpy': np.__version__, 'solver': 'bundled SciPy HiGHS',
                                     'highs_version': '.'.join(map(str, (HIGHS_VERSION_MAJOR,
                                                    HIGHS_VERSION_MINOR, HIGHS_VERSION_PATCH))),
                                     'solver_options': OPTIONS,
                                     'protected_files': count, 'protocol_sha256': digest(RAW / 'contract.json')})
    print(json.dumps({b: summary['comparisons'][b] for b in ('updated_recent', 'persistence')}, indent=2), flush=True)


def verify():
    count = check_preservation()
    cases = read(OUT / 'results.json')
    maximum_gap = 0.
    maximum_absolute_gap = 0.
    for case in cases:
        v = np.array(case['forecast_values_mt'])
        o = np.array(case['observed_values_mt'])
        k = np.array(case['capacities'])
        optimum = np.array(case['scenario_optima_mt'])
        for method, answer in case['methods'].items():
            x = np.array(answer['x'])
            if not np.all((x == 0) | (x == 1)) or k @ x > case['limit_mw'] + 1e-6:
                raise ValueError('Invalid portfolio')
            regret = float(np.maximum(0, optimum - v @ x).max())
            historical = max(0., float(case['reference_value_mt'] - o @ x))
            np.testing.assert_allclose(regret, answer['max_baseline_regret_mt'], atol=1e-7)
            np.testing.assert_allclose(historical, answer['observed_regret_mt'], atol=1e-7)
            maximum_gap = max(maximum_gap, answer['solver_gap'])
            maximum_absolute_gap = max(maximum_absolute_gap, answer['solver_absolute_gap_mt'])
        maximum_gap = max(maximum_gap, case['reference_solver_gap'])
        maximum_absolute_gap = max(maximum_absolute_gap, case['reference_absolute_gap_mt'])
        robust = case['methods']['minimax_regret']['max_baseline_regret_mt']
        if any(robust > case['methods'][b]['max_baseline_regret_mt'] + 1e-6 for b in RULES):
            raise ValueError('The minimum-regret guarantee failed')
    if maximum_gap > 1e-8 or maximum_absolute_gap > 1e-6:
        raise ValueError('The portfolio optimality bounds exceed the numerical tolerance')
    result = {'primary_cases': len(cases), 'portfolios': len(cases) * 6,
              'protected_files': count, 'maximum_solver_relative_gap': maximum_gap,
              'maximum_solver_absolute_gap_mt': maximum_absolute_gap,
              'primal_objective_checks': 'pass', 'baseline_regret_guarantee': 'pass'}
    write(OUT / 'verification.json', result)
    print(json.dumps(result, indent=2))


def reproduce():
    names = ['results.json', 'summary.json', 'sensitivities.json', 'coverage.json', 'selections.csv']
    before = {name: digest(OUT / name) for name in names}
    run()
    after = {name: digest(OUT / name) for name in names}
    if before != after:
        raise ValueError('Scientific outputs changed on the independent repeat')
    verify()
    write(OUT / 'reproduction.json', {'status': 'pass', 'scientific_sha256': after,
                                     'protected_files': check_preservation()})
    print('Repeated run reproduced all five scientific outputs byte-for-byte', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('freeze', 'run', 'verify', 'reproduce'), required=True)
    mode = parser.parse_args().mode
    {'freeze': freeze, 'run': run, 'verify': verify, 'reproduce': reproduce}[mode]()
