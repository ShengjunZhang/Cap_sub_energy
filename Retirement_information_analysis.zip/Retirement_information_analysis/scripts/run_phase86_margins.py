"""Add decision diagnostics without changing frozen annual forecasts or selections."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from scripts.run_phase84_support import read,write,digest,write_csv
from scripts.run_phase85_integration import preserved as prior_preserved
from transition_assets.phase86_margins import exchange_decomposition,stability_radius,worst_regret

RAW=ROOT/'data/raw/phase86'; OUT=ROOT/'data/processed/phase86'
PRODUCTS=['diagnostics.json','summary.json','source.csv']


def freeze():
    if (RAW/'inputs.json').exists(): raise ValueError('Phase86 inputs already frozen')
    prior_preserved()
    names=set(read(ROOT/'data/raw/phase85/inputs.json')['files'])
    for folder in ['data/raw/phase85','data/processed/phase85','outputs/phase85','manuscript/omega_v3',
                   'delivery/omega_v3_author_review_20261010','data/processed/phase83']:
        names.update(p.relative_to(ROOT).as_posix() for p in (ROOT/folder).rglob('*') if p.is_file())
    names.update(['data/raw/phase86/contract.json','tests/fixtures/phase86_margins.json',
                  'transition_assets/phase85_solver_v2.py','transition_assets/phase85_integration.py'])
    write(RAW/'inputs.json',dict(files={n:digest(ROOT/n) for n in sorted(names)}))
    print('Frozen',len(names),'inherited files',flush=True)


def preserved():
    names=read(RAW/'inputs.json')['files']
    for name,h in names.items():
        if digest(ROOT/name)!=h: raise ValueError('Changed inherited file: '+name)
    return len(names)


def run():
    preserved(); c=read(RAW/'contract.json'); annual=read(ROOT/c['annual_input'])
    if len(annual)!=c['expected_annual_settings']: raise ValueError('Annual settings changed')
    diagnostics=[]
    for case in annual:
        k=np.array(case['capacities']); actual=np.array(case['observed_values_mt']); ref=case['reference_x']
        for method,idx in [('updated_recent',3),('persistence',4)]:
            w=np.array(case['forecast_values_mt'][idx]); x=case['methods'][method]['x']
            parts=exchange_decomposition(w,actual,k,x,ref)
            radius=stability_radius(w*1e6,k,case['limit_mw'],x,
                                   c['radius_resolution_t_per_mw'],c['maximum_ratio_iterations'])
            if radius['maximum_absolute_gap']/1e6>c['solver_absolute_acceptance_mt']:
                raise ValueError('Absolute solver gap exceeds fixed acceptance')
            diagnostics.append({**{s:case[s] for s in ['year','mu','q','fraction']},'method':method,
                'decomposition_mt':parts,'radius_t_per_mw':radius,
                'observed_max_error_t_per_mw':float((abs(actual-w)*1e6/k).max()),
                'exchange_keys':[case['keys'][i] for i in parts['changed_indices']],
                'witness_keys':[case['keys'][i] for i,z in enumerate(radius['witness'] or []) if z]})
        if len(diagnostics)%54==0: print('Diagnostics:',len(diagnostics),flush=True)
    summary={m:dict(n=len(ds),zero_observed_loss=sum(d['decomposition_mt']['loss']<=1e-7 for d in ds),
        zero_radius=sum(d['radius_t_per_mw']['upper']==0 for d in ds),
        positive_radius=sum((d['radius_t_per_mw']['lower'] or 0)>0 for d in ds),
        radius_median_t_per_mw=float(np.median([d['radius_t_per_mw']['upper'] for d in ds if d['radius_t_per_mw']['upper'] is not None])),
        realised_error_within_radius=sum(d['radius_t_per_mw']['lower'] is not None and
            d['observed_max_error_t_per_mw']<=d['radius_t_per_mw']['lower'] for d in ds),
        unexchanged_error_share=float(sum(d['decomposition_mt']['total_absolute_error']-d['decomposition_mt']['exchange_absolute_error'] for d in ds)/sum(d['decomposition_mt']['total_absolute_error'] for d in ds)))
        for m in c['methods'] for ds in [[d for d in diagnostics if d['method']==m]]}
    summary['central']=[d for d in diagnostics if all(d[k]==v for k,v in c['central'].items())]
    summary['diagnostics']=len(diagnostics)
    write(OUT/'diagnostics.json',diagnostics); write(OUT/'summary.json',summary)
    write_csv(OUT/'source.csv',[dict(year=d['year'],mu=d['mu'],q=d['q'],fraction=d['fraction'],method=d['method'],
        loss_mt=d['decomposition_mt']['loss'],margin_mt=d['decomposition_mt']['forecast_margin'],
        error_contrast_mt=d['decomposition_mt']['error_contrast'],
        changed_units=d['decomposition_mt']['changed_generators'],
        exchanged_capacity_mw=d['decomposition_mt']['exchanged_capacity_mw'],
        radius_lower_t_per_mw=d['radius_t_per_mw']['lower'],radius_upper_t_per_mw=d['radius_t_per_mw']['upper']) for d in diagnostics])
    verify(); print(json.dumps({m:summary[m] for m in c['methods']},indent=2),flush=True)


def verify():
    frozen=preserved(); c=read(RAW/'contract.json'); annual=read(ROOT/c['annual_input']); rows=read(OUT/'diagnostics.json')
    if len(rows)!=c['expected_diagnostics']: raise ValueError('Diagnostic count differs')
    byid={(v['year'],v['mu'],v['q'],v['fraction']):v for v in annual}; checks=0; max_identity=0.
    for d in rows:
        case=byid[tuple(d[k] for k in ['year','mu','q','fraction'])]; idx=3 if d['method']=='updated_recent' else 4
        w=np.array(case['forecast_values_mt'][idx]); a=np.array(case['observed_values_mt']); k=np.array(case['capacities'])
        x=np.array(case['methods'][d['method']]['x']); z=np.array(case['reference_x']); change=z-x; error=a-w
        p=d['decomposition_mt']; identity=abs(p['loss']-(p['error_contrast']-p['forecast_margin']))
        np.testing.assert_allclose([p['loss'],p['error_contrast'],p['forecast_margin']],
                                   [a@change,error@change,-w@change],atol=1e-10)
        np.testing.assert_allclose(p['loss'],case['methods'][d['method']]['observed_regret_mt'],atol=1e-7)
        if identity>c['identity_tolerance_mt'] or p['exchange_absolute_error']+1e-9<p['error_contrast']:
            raise ValueError('Exchange identity or bound failed')
        rad=d['radius_t_per_mw']; upper=rad['upper']; lower=rad['lower']
        if upper is not None and rad['status']=='bounded':
            if lower<0 or upper-lower>c['radius_resolution_t_per_mw']+1e-8: raise ValueError('Unresolved radius')
            witness=np.array(rad['witness']); distance=k@abs(witness-x)
            np.testing.assert_allclose(w@((x-witness))*1e6/distance,upper,atol=1e-6)
            sep=worst_regret(w*1e6,k,case['limit_mw'],x,lower)
            if sep['upper']>0.011: raise ValueError('Lower stability bound failed independent separation')
            perturbed=w*1e6+(upper+0.001)*k*np.sign(witness-x)
            if perturbed@(witness-x)<=0: raise ValueError('Upper radius witness failed')
            checks+=3
        checks+=5; max_identity=max(max_identity,identity)
    write(OUT/'verification.json',dict(status='pass',checks=checks,frozen_files=frozen,max_identity_error_mt=max_identity))
    print('Verified:',checks,'checks;',frozen,'unchanged files',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--mode',choices=['freeze','run','verify','reproduce'],default='run'); mode=parser.parse_args().mode
    if mode=='freeze': freeze()
    elif mode=='verify': verify()
    elif mode=='reproduce':
        before={p:digest(OUT/p) for p in PRODUCTS}; run(); after={p:digest(OUT/p) for p in PRODUCTS}
        if before!=after: raise ValueError('Scientific diagnostics changed on repeat')
        write(OUT/'reproduction.json',dict(status='pass',sha256=after))
    else: run()
