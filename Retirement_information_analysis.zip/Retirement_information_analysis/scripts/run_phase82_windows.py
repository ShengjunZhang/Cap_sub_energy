"""Reconstruct one facility's order-constrained retirement windows."""
import argparse
import csv
from datetime import date, datetime, timedelta, timezone
import hashlib
from importlib.metadata import version, PackageNotFoundError
import json
import math
from pathlib import Path
import platform
import subprocess
import sys
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
RAW = ROOT / 'data/raw/phase82'
OUT = ROOT / 'data/processed/phase82'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n',
                    encoding='utf-8')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_check():
    checked = []
    for order in read(RAW / 'orders.json'):
        path = ROOT / order['path']
        extracted = subprocess.run(['pdftotext', '-enc', 'UTF-8', str(path), '-'],
                                   capture_output=True, check=True).stdout.decode('utf-8')
        normalized = ' '.join(extracted.split()).casefold()
        missing = [f for f in order['required_fragments']
                   if ' '.join(f.split()).casefold() not in normalized]
        if missing:
            raise ValueError(f"Missing source fragments in {order['id']}: {missing}")
        checked.append({'id': order['id'], 'sha256': digest(path),
                        'fragment_count': len(order['required_fragments']),
                        'clause_pages_one_based': order['clause_pages_one_based']})
    return checked


def fetch_sources():
    manifest = RAW / 'source_manifest.json'
    if manifest.exists():
        for r in read(manifest)['files']:
            if digest(ROOT / r['path']) != r['sha256']:
                raise ValueError('A saved official source changed')
        print('Reused saved official sources:', len(source_check()), flush=True)
        return
    rows = []
    for order in read(RAW / 'orders.json'):
        target = ROOT / order['path']
        if target.exists():
            body = target.read_bytes()
            url = None
            origin = 'recovered saved PDF after interrupted source validation'
        else:
            request = Request(order['url'], headers={'User-Agent': 'Retirement-window research/1.0'})
            with urlopen(request, timeout=60) as response:
                body = response.read()
                url = response.url
            origin = 'official URL download'
        if not body.startswith(b'%PDF-'):
            raise ValueError('Expected a PDF from the official source')
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            target.write_bytes(body)
        rows.append({'id': order['id'], 'url': order['url'], 'resolved_url': url,
                     'path': order['path'], 'bytes': len(body), 'sha256': digest(target),
                     'origin': origin})
        print('Saved official order', order['id'], len(body), 'bytes', flush=True)
    source_check()
    write(manifest, {'manifest_recorded_utc': datetime.now(timezone.utc).isoformat(), 'files': rows})


def freeze():
    target = RAW / 'inputs.json'
    if target.exists():
        raise ValueError('The Phase82 freeze already exists')
    c = read(RAW / 'contract.json')
    inherited = read(ROOT / 'data/raw/phase81/inputs.json')['files']
    bad = [name for name, h in inherited.items() if digest(ROOT / name) != h]
    if bad:
        raise ValueError('An inherited file changed: ' + str(bad[:5]))
    files = {ROOT / name for name in inherited}
    for folder in [ROOT / 'data/processed/phase81', ROOT / 'outputs/phase81']:
        files.update(p for p in folder.rglob('*') if p.is_file())
    files.update(ROOT / name for name in [
        c['panel'], c['daily'], c['crosswalk'], 'outputs/phase81_report.md',
        'transition_assets/phase81_diagnostic.py', 'scripts/run_phase81_diagnostic.py',
        'tests/test_phase81_diagnostic.py', 'data/raw/phase81/inputs.json',
        'data/raw/phase81/contract.json', 'tests/fixtures/phase82_windows.json'])
    files.update(p for p in RAW.rglob('*') if p.is_file())
    source_check()
    write(target, {'date': c['date'], 'files': {
        p.relative_to(ROOT).as_posix(): digest(p) for p in sorted(files)}})
    print('Frozen', len(files), 'inputs and protected earlier files', flush=True)


def preserved():
    files = read(RAW / 'inputs.json')['files']
    bad = [name for name, h in files.items()
           if not (ROOT / name).is_file() or digest(ROOT / name) != h]
    if bad:
        raise ValueError('Protected file changed: ' + str(bad[:5]))
    return len(files)


def case_inputs():
    c = read(RAW / 'contract.json')
    panel = [r for r in read(ROOT / c['panel'])
             if str(r['plant']) == c['facility_id'] and r['outcome_year'] == c['year']]
    panel.sort(key=lambda r: r['key'])
    if [r['key'].split(':')[1] for r in panel] != c['units']:
        raise ValueError('Panel unit set does not match the contract')
    if any(r['origin'] != '2024-12-31' or r['current_plan'] != c['plan_end_inclusive']
           or r['initial_plan'] != c['plan_end_inclusive'] for r in panel):
        raise ValueError('Unexpected plan or origin in the frozen panel')
    target_pairs = {(c['facility_id'], u) for u in c['units']}
    links = {p: set() for p in target_pairs}
    with (ROOT / c['crosswalk']).open(encoding='utf-8-sig', newline='') as stream:
        for r in csv.DictReader(stream):
            pair = (r['CAMD_PLANT_ID'], r['CAMD_UNIT_ID'])
            if pair in links:
                links[pair].add((r['EIA_PLANT_ID'], r['EIA_GENERATOR_ID']))
    if any(values != {pair} for pair, values in links.items()):
        raise ValueError('The exact individual crosswalk is not exclusive')
    records = []
    from transition_assets.phase82_windows import clean_daily_record, index_daily
    with (ROOT / c['daily']).open(encoding='utf-8-sig', newline='') as stream:
        for r in csv.DictReader(stream):
            if (r['Facility ID'], r['Unit ID']) in target_pairs:
                records.append(clean_daily_record(r))
    indexed = index_daily(records)
    records = list(indexed.values())
    first, end = date(c['year'], 1, 1), date(c['year'] + 1, 1, 1)
    expected = {(first + timedelta(days=i)).isoformat() for i in range((end-first).days)}
    for u in c['units']:
        actual = {r['date'] for r in records if r['unit'] == u}
        if actual != expected:
            raise ValueError('Incomplete or excess daily coverage: ' + u)
    if any(r['co2_tonnes'] is None or r['operating_hours'] is None
           or r['gross_mwh'] is None for r in records):
        raise ValueError('A required daily measurement is missing; no zero imputation')
    if any(r['positive_co2_zero_hours'] for r in records):
        raise ValueError('Positive CO2 with zero operating hours requires review')
    return c, panel, records, read(ROOT / c['sources'])


def compute():
    from transition_assets.phase82_windows import (
        forecast_window, full_day_membership, known_orders, sum_records)
    preserved()
    c, panel, records, orders = case_inputs()
    post_start = (date.fromisoformat(c['plan_end_inclusive']) + timedelta(days=1)).isoformat()
    annual = sum_records(records)
    unit_totals = []
    for p in panel:
        u = p['key'].split(':')[1]
        totals = sum_records(r for r in records if r['unit'] == u)
        if abs(totals['co2_tonnes'] - p['e_actual']) > c['tolerance_tonnes']:
            raise ValueError('Daily-to-panel annual CO2 mismatch: ' + u)
        unit_totals.append({'unit': u, 'nameplate_mw': p['capacity_mw'], **totals,
                            'annual_forecast_tonnes': p['e_forecasts'][c['annual_forecast_rule']],
                            'plan_cutoff_forecast_tonnes': p['e_forecasts']['updated_recent'],
                            'post_plan_co2_tonnes': sum_records(
                                r for r in records if r['unit'] == u and r['date'] >= post_start)['co2_tonnes']})
    annual_forecast = math.fsum(r['annual_forecast_tonnes'] for r in unit_totals)
    post_records = [r for r in records if r['date'] >= post_start]
    order_totals = []
    boundary, outside, covered = [], [], []
    for order in orders:
        order_totals.append({'id': order['id'], 'issued': order['issued'],
                             'effective': order['effective'], 'expires_literal': order['expires'],
                             **sum_records(r for r in post_records
                                           if order['id'] in full_day_membership(orders, r['date'])[0])})
    for r in post_records:
        inside, partial = full_day_membership(orders, r['date'])
        (covered if inside else boundary if partial else outside).append(r)
    snapshots = []
    for asof in c['snapshots_end_of_day']:
        row = forecast_window(orders, asof, annual_forecast, c['year'], c['plan_end_inclusive'])
        prior = known_orders(orders, (date.fromisoformat(asof) - timedelta(days=1)).isoformat())
        before = forecast_window(prior, asof, annual_forecast, c['year'], c['plan_end_inclusive'])
        row['same_action_date_before_new_orders'] = before
        row['same_action_date_order_update_tonnes'] = (before['outside_blocking_forecast_tonnes']
                                                       - row['outside_blocking_forecast_tonnes'])
        known_ids = {r['id'] for r in known_orders(orders, asof)}
        buckets = {'known_order': [], 'later_issued_order': [], 'partial_boundary': [], 'outside_all_orders': []}
        for r in records:
            if r['date'] < row['action_date']:
                continue
            inside, partial = full_day_membership(orders, r['date'])
            if set(inside) & known_ids:
                category = 'known_order'
            elif inside:
                category = 'later_issued_order'
            elif partial:
                category = 'partial_boundary'
            else:
                category = 'outside_all_orders'
            buckets[category].append(r)
        row['observed_remaining'] = sum_records(r for r in records if r['date'] >= row['action_date'])
        row['observed_retroactive_buckets'] = {k: sum_records(v) for k, v in buckets.items()}
        row['observed_after_lower_bound'] = sum_records(
            r for r in records if r['date'] >= row['closure_lower_bound'])
        snapshots.append(row)
    daily = []
    for r in records:
        inside, partial = full_day_membership(orders, r['date'])
        daily.append({**r, 'full_day_orders': '|'.join(inside), 'partial_day_orders': '|'.join(partial)})
    calendar_orders = [dict(o, expires='2025-11-19T00:00:00-05:00')
                       if o['id'] == '202-25-7' else dict(o) for o in orders]
    calendar_covered = [r for r in post_records if full_day_membership(calendar_orders, r['date'])[0]]
    calendar_dates = [forecast_window(calendar_orders, asof, annual_forecast, c['year'],
                                      c['plan_end_inclusive'])['closure_lower_bound']
                      for asof in c['snapshots_end_of_day']]
    return {'facility_id': c['facility_id'], 'facility': 'J.H. Campbell',
            'units': c['units'], 'year': c['year'], 'nameplate_mw': sum(p['capacity_mw'] for p in panel),
            'annual': annual, 'unit_totals': unit_totals, 'snapshots': snapshots,
            'post_plan_start': post_start, 'post_plan': sum_records(post_records),
            'post_plan_full_order_days': sum_records(covered),
            'post_plan_partial_boundary_days': sum_records(boundary),
            'post_plan_outside_all_orders': sum_records(outside), 'order_totals': order_totals,
            'calendar_date_sensitivity': {
                'scope': 'Interpret Order202-25-7 expiry as local midnight November19 instead of literal EDT',
                'post_plan_unit_days': len(calendar_covered),
                'post_plan_co2_tonnes': sum_records(calendar_covered)['co2_tonnes'],
                'difference_from_full_day_literal_tonnes': sum_records(calendar_covered)['co2_tonnes'] - sum_records(covered)['co2_tonnes'],
                'daily_closure_lower_bounds_unchanged': calendar_dates == [r['closure_lower_bound'] for r in snapshots]},
            'interpretation': 'CO2 exposure and timing lower bounds; not causal emissions or achievable avoided CO2',
            'historical_identity': 'exclusive static crosswalk, not independently validated historical links'}, daily


def export_csv(result, daily):
    snapshots = []
    for r in result['snapshots']:
        snapshots.append({k: ('|'.join(v) if k == 'known_orders' else v)
                          for k, v in r.items() if not isinstance(v, dict)})
    for name, rows in [('daily_accounting.csv', daily), ('snapshots.csv', snapshots),
                       ('unit_totals.csv', result['unit_totals']), ('order_totals.csv', result['order_totals'])]:
        with (OUT / name).open('w', encoding='utf-8', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)


def verify(result):
    """Independent raw-row sums and enumerated dates, without window helpers."""
    from zoneinfo import ZoneInfo
    c = read(RAW / 'contract.json')
    local = ZoneInfo('America/Detroit')
    raw = []
    with (ROOT / c['daily']).open(encoding='utf-8-sig', newline='') as stream:
        for r in csv.DictReader(stream):
            if r['Facility ID'] == c['facility_id'] and r['Unit ID'] in c['units']:
                raw.append(r)
    totals = {}
    structural = 0
    for r in raw:
        key = (r['Unit ID'], r['Date'])
        if key in totals:
            raise ValueError('Independent duplicate check failed')
        value = r['CO2 Mass (short tons)'].strip()
        if not value:
            if float(r['Sum of the Operating Time']) != 0:
                raise ValueError('Independent missingness check failed')
            value = '0'
            structural += 1
        totals[key] = float(value) * 0.90718474
    if len(totals) != 1095:
        raise ValueError('Independent daily count failed')
    def check(a, b, label):
        if abs(a-b) > c['tolerance_tonnes']:
            raise ValueError('Independent reconciliation failed: ' + label)
    check(math.fsum(totals.values()), result['annual']['co2_tonnes'], 'annual')
    if structural != result['annual']['structural_co2_zero_unit_days']:
        raise ValueError('Structural zero accounting mismatch')
    orders = read(ROOT / c['sources'])
    annual_rate = math.fsum(p['e_forecasts']['persistence'] for p in read(ROOT / c['panel'])
                           if str(p['plant']) == c['facility_id'] and p['outcome_year'] == 2025) / 365
    labels = {}
    for key in totals:
        start = datetime.fromisoformat(key[1] + 'T00:00:00').replace(tzinfo=local)
        end = start + timedelta(days=1)
        full, partial = set(), set()
        for order in orders:
            a, b = datetime.fromisoformat(order['effective']), datetime.fromisoformat(order['expires'])
            if a <= start and b >= end:
                full.add(order['id'])
            elif a < end and b > start:
                partial.add(order['id'])
        labels[key] = (full, partial)
    for row in result['snapshots']:
        action = date.fromisoformat(row['asof']) + timedelta(days=1)
        dates = [date(2025, 1, 1) + timedelta(days=i) for i in range(365)
                 if date(2025, 1, 1) + timedelta(days=i) >= action]
        known = {o['id'] for o in orders
                 if datetime.fromisoformat(o['issued']).astimezone(local).date().isoformat() <= row['asof']}
        if known != set(row['known_orders']):
            raise ValueError('Independent future-order exclusion failed')
        lower = action
        for d in dates:
            instant = datetime.combine(d, datetime.min.time(), local)
            if all(instant >= datetime.fromisoformat(o['expires']) for o in orders if o['id'] in known):
                lower = d
                break
        else:
            if known:
                latest = max(datetime.fromisoformat(o['expires']) for o in orders if o['id'] in known).astimezone(local)
                lower = latest.date() + timedelta(days=bool(latest.hour or latest.minute or latest.second))
        if lower.isoformat() != row['closure_lower_bound']:
            raise ValueError('Independent lower-bound date mismatch')
        days = sum(d >= lower for d in dates)
        check(annual_rate * len(dates), row['remaining_forecast_tonnes'], 'remaining forecast')
        check(annual_rate * days, row['outside_blocking_forecast_tonnes'], 'outside forecast')
        cutoff_days = sum(d <= date.fromisoformat(c['plan_end_inclusive']) for d in dates)
        check(annual_rate * cutoff_days, row['date_cutoff_forecast_tonnes'], 'date cutoff')
        prior_ids = {o['id'] for o in orders
                     if datetime.fromisoformat(o['issued']).astimezone(local).date().isoformat() < row['asof']}
        prior_dates = [d for d in dates if all(
            datetime.combine(d, datetime.min.time(), local) >= datetime.fromisoformat(o['expires'])
            for o in orders if o['id'] in prior_ids)]
        prior_exposure = annual_rate * len(prior_dates)
        check(prior_exposure, row['same_action_date_before_new_orders']['outside_blocking_forecast_tonnes'],
              'fixed-date prior exposure')
        check(prior_exposure - annual_rate * days, row['same_action_date_order_update_tonnes'],
              'fixed-date order update')
        check(row['remaining_forecast_tonnes'], row['outside_blocking_forecast_tonnes']
              + row['known_blocking_forecast_tonnes'], 'forecast partition')
        remaining = {k: v for k, v in totals.items() if k[1] >= action.isoformat()}
        bucket_values = {k: [] for k in row['observed_retroactive_buckets']}
        for key, value in remaining.items():
            full, partial = labels[key]
            cat = 'known_order' if full & known else 'later_issued_order' if full else 'partial_boundary' if partial else 'outside_all_orders'
            bucket_values[cat].append(value)
        for cat, values in bucket_values.items():
            check(math.fsum(values), row['observed_retroactive_buckets'][cat]['co2_tonnes'], cat)
        check(math.fsum(remaining.values()), row['observed_remaining']['co2_tonnes'], 'observed remaining')
        check(math.fsum(v for k, v in totals.items() if k[1] >= row['closure_lower_bound']),
              row['observed_after_lower_bound']['co2_tonnes'], 'observed after lower bound')
    post = {k: v for k, v in totals.items() if k[1] >= result['post_plan_start']}
    check(math.fsum(post.values()), result['post_plan']['co2_tonnes'], 'post-plan')
    for field, predicate in [
        ('post_plan_full_order_days', lambda k: bool(labels[k][0])),
        ('post_plan_partial_boundary_days', lambda k: not labels[k][0] and bool(labels[k][1])),
        ('post_plan_outside_all_orders', lambda k: not any(labels[k]))]:
        values = [v for k, v in post.items() if predicate(k)]
        check(math.fsum(values), result[field]['co2_tonnes'], field)
        if len(values) != result[field]['unit_days']:
            raise ValueError('Independent partition day count mismatch')
    for order in result['order_totals']:
        values = [v for k, v in post.items() if order['id'] in labels[k][0]]
        check(math.fsum(values), order['co2_tonnes'], order['id'])
    if result['calendar_date_sensitivity']['post_plan_unit_days'] != len(post):
        raise ValueError('Calendar-date sensitivity coverage mismatch')
    check(result['calendar_date_sensitivity']['post_plan_co2_tonnes'], math.fsum(post.values()),
          'calendar-date sensitivity')
    if not result['calendar_date_sensitivity']['daily_closure_lower_bounds_unchanged']:
        raise ValueError('Unexpected calendar-date sensitivity closure change')
    for unit in result['unit_totals']:
        check(math.fsum(v for k, v in totals.items() if k[0] == unit['unit']),
              unit['co2_tonnes'], 'unit' + unit['unit'])
        check(unit['plan_cutoff_forecast_tonnes'], unit['annual_forecast_tonnes'] * 151 / 365,
              'inherited plan cutoff')
    with (OUT / 'daily_accounting.csv').open(encoding='utf-8', newline='') as stream:
        exported = list(csv.DictReader(stream))
    if len(exported) != len(totals):
        raise ValueError('Daily export count mismatch')
    for r in exported:
        check(float(r['co2_tonnes']), totals[(r['unit'], r['date'])], 'daily CSV')
    return {'status': 'passed', 'raw_unit_days': len(totals), 'snapshots': len(result['snapshots']),
            'official_sources': source_check(), 'protected_files': preserved(),
            'annual_co2_reconciled_to_phase73': True, 'future_order_exclusion': True,
            'timezone_wording_preserved': True, 'independent_raw_row_accounting': True}


def plot(result, daily):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                         'axes.spines.top': False, 'axes.spines.right': False})
    folder = ROOT / 'outputs/phase82'
    folder.mkdir(parents=True, exist_ok=True)
    dates = sorted({r['date'] for r in daily})
    cumulative, total = [], 0.
    for d in dates:
        total += math.fsum(r['co2_tonnes'] for r in daily if r['date'] == d)
        cumulative.append(total / 1e6)
    fig, axes = plt.subplots(2, 1, figsize=(9.1, 6.4), sharex=True,
                             gridspec_kw={'height_ratios': [1, 2.2]})
    colors = ['#147F88', '#4366A7', '#9D476F']
    for i, order in enumerate(read(RAW / 'orders.json')):
        a = datetime.fromisoformat(order['effective']).astimezone(__import__('zoneinfo').ZoneInfo('America/Detroit')).replace(tzinfo=None)
        b = min(datetime.fromisoformat(order['expires']).astimezone(__import__('zoneinfo').ZoneInfo('America/Detroit')).replace(tzinfo=None), datetime(2026, 1, 1))
        axes[0].plot([a, b], [2-i, 2-i], color=colors[i], lw=9, solid_capstyle='butt')
    axes[0].set_yticks([2, 1, 0], ['May order', 'August extension', 'November extension'])
    axes[0].set_ylim(-.6, 2.8)
    axes[0].set_title('(a) Signed availability orders', loc='left', fontsize=11)
    axes[1].plot([date.fromisoformat(d) for d in dates], cumulative, color='#282828', lw=1.8)
    post_base = next(v for d, v in zip(dates, cumulative) if d == '2025-05-31')
    axes[1].fill_between([date.fromisoformat(d) for d in dates if d >= '2025-06-01'],
                         [v for d, v in zip(dates, cumulative) if d >= '2025-06-01'],
                         post_base, color='#147F88', alpha=.13)
    axes[1].set_ylabel('Cumulative observed CO2 (Mt)')
    axes[1].set_title('(b) Emissions continue after the planned closure', loc='left', fontsize=11)
    for ax in axes:
        ax.axvline(date(2025, 6, 1), color='#B35B30', lw=1.1, ls='--')
        ax.grid(axis='x', color='#E6E6E6', lw=.5)
        ax.set_axisbelow(True)
    axes[1].text(.97, .57, f"Post-plan CO2: {result['post_plan']['co2_tonnes']/1e6:.3f} Mt",
                 transform=axes[1].transAxes, ha='right', color='#147F88', fontsize=10)
    axes[1].xaxis.set_major_locator(mdates.MonthLocator(interval=2))
    axes[1].xaxis.set_major_formatter(mdates.DateFormatter('%b'))
    axes[1].set_xlim(date(2025, 1, 1), date(2026, 1, 1))
    fig.subplots_adjust(left=.21, right=.97, top=.94, bottom=.15, hspace=.33)
    fig.text(.21, .04, 'Dashed line: June 1. Shading is observed exposure, not emissions caused by an order.', fontsize=8.5)
    fig.savefig(folder / 'campbell_timeline.png', dpi=200)
    plt.close(fig)

    rows = result['snapshots']
    fig, ax = plt.subplots(figsize=(9.1, 4.9))
    positions = range(len(rows))
    blocked = [r['known_blocking_forecast_tonnes']/1e6 for r in rows]
    outside = [r['outside_blocking_forecast_tonnes']/1e6 for r in rows]
    ax.bar(positions, blocked, width=.58, color='#9D476F', label='Before known expiry')
    ax.bar(positions, outside, bottom=blocked, width=.58, color='#147F88', label='After known expiry / no order')
    for i, r in enumerate(rows):
        ax.text(i, (blocked[i]+outside[i])+.16, f"{blocked[i]+outside[i]:.2f}", ha='center', fontsize=9)
        if outside[i] > .3:
            ax.text(i, blocked[i]+outside[i]/2, f'{outside[i]:.2f}', ha='center', va='center', color='white', fontsize=10)
    ax.set_xticks(list(positions), ['Dec 31, 2024', 'May 22, 2025', 'May 23, 2025', 'Aug 20, 2025', 'Nov 18, 2025'])
    ax.set_ylabel('Forecast remaining CO2 exposure (Mt)')
    ax.set_title('Availability orders change the window for permanent closure', loc='left', fontsize=11)
    ax.set_ylim(0, 9.6)
    ax.legend(frameon=False, fontsize=9, loc='upper right')
    ax.grid(axis='y', color='#E6E6E6', lw=.5)
    ax.set_axisbelow(True)
    fig.subplots_adjust(left=.09, right=.98, top=.89, bottom=.28)
    fig.text(.09, .12, 'Frozen 2024 rate; action starts the next day. Only orders signed by each snapshot are used.', fontsize=8.5)
    fig.text(.09, .065, 'After-expiry exposure is not approval to close, feasible avoided CO2 or a causal policy effect.', fontsize=8.5)
    fig.savefig(folder / 'rolling_exposure.png', dpi=200)
    plt.close(fig)


def execute(mode):
    if mode == 'reproduce':
        names = ['results.json', 'daily_accounting.csv', 'snapshots.csv', 'unit_totals.csv', 'order_totals.csv']
        before = {n: digest(OUT / n) for n in names}
    result, daily = compute()
    OUT.mkdir(parents=True, exist_ok=True)
    write(OUT / 'results.json', result)
    export_csv(result, daily)
    verification = verify(result)
    write(OUT / 'verification.json', verification)
    try:
        tzdata = version('tzdata')
    except PackageNotFoundError:
        tzdata = 'system timezone database'
    write(OUT / 'environment.json', {'python': sys.version, 'platform': platform.platform(),
                                    'tzdata': tzdata,
                                    'matplotlib': version('matplotlib'),
                                    'module_sha256': digest(ROOT / 'transition_assets/phase82_windows.py'),
                                    'runner_sha256': digest(Path(__file__))})
    if mode == 'reproduce':
        after = {n: digest(OUT / n) for n in names}
        if before != after:
            raise ValueError('Scientific products did not reproduce byte-for-byte')
        write(OUT / 'reproduction.json', {'status': 'passed', 'hashes': after,
                                        'protected_files': verification['protected_files']})
    else:
        plot(result, daily)
    print(json.dumps({'verification': verification['status'],
                      'protected_files': verification['protected_files'],
                      'annual_co2_mt': result['annual']['co2_tonnes']/1e6,
                      'post_plan_co2_mt': result['post_plan']['co2_tonnes']/1e6,
                      'full_order_days_co2_mt': result['post_plan_full_order_days']['co2_tonnes']/1e6,
                      'boundary_co2_mt': result['post_plan_partial_boundary_days']['co2_tonnes']/1e6,
                      'snapshots': [{k: r[k] for k in ['asof', 'closure_lower_bound', 'remaining_days',
                                    'outside_blocking_days', 'remaining_forecast_tonnes',
                                    'outside_blocking_forecast_tonnes']} for r in result['snapshots']]}, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['sources', 'freeze', 'run', 'reproduce'], required=True)
    args = parser.parse_args()
    if args.mode == 'sources':
        fetch_sources()
    elif args.mode == 'freeze':
        freeze()
    else:
        execute(args.mode)


if __name__ == '__main__':
    main()
