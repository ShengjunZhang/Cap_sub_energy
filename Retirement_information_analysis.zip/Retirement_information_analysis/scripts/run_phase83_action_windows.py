"""Existing-source case extension; no download or manuscript-writing route."""
import argparse
import csv
from datetime import date, timedelta
import hashlib
import json
import math
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
RAW = ROOT / 'data/raw/phase83'
OUT = ROOT / 'data/processed/phase83'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n',
                    encoding='utf-8')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_check():
    from scripts.run_phase82_windows import source_check as check_campbell
    checked = check_campbell()
    for case in read(RAW / 'cases.json'):
        for clause in case['clauses']:
            for page, fragments in clause['required_fragments'].items():
                output = subprocess.run([
                    'pdftotext', '-f', page, '-l', page, '-enc', 'UTF-8',
                    str(ROOT / clause['path']), '-'], capture_output=True, check=True)
                normalized = ' '.join(output.stdout.decode('utf-8').split()).casefold()
                missing = [f for f in fragments if ' '.join(f.split()).casefold() not in normalized]
                if missing:
                    raise ValueError(f"Missing clauses in {clause['id']} page{page}: {missing}")
            checked.append({'id': clause['id'], 'path': clause['path'],
                            'published': clause['published'], 'pages': clause['pages'],
                            'sha256': digest(ROOT / clause['path'])})
    return checked


def freeze():
    if (RAW / 'inputs.json').exists():
        raise ValueError('Phase83 inputs already frozen')
    inherited = read(ROOT / 'data/raw/phase82/inputs.json')['files']
    if any(digest(ROOT / p) != h for p, h in inherited.items()):
        raise ValueError('An inherited input changed')
    files = {ROOT / p for p in inherited}
    for folder in ['data/raw/phase82', 'data/processed/phase82', 'outputs/phase82']:
        files.update(p for p in (ROOT / folder).rglob('*') if p.is_file())
    files.update(ROOT / p for p in [
        'transition_assets/phase82_windows.py', 'scripts/run_phase82_windows.py',
        'tests/test_phase82_windows.py', 'outputs/phase82_report.md',
        'tests/fixtures/phase83_action_windows.json'])
    contract = read(RAW / 'contract.json')
    files.update(ROOT / contract[k] for k in ['panel', 'crosswalk', 'cases'])
    files.add(RAW / 'contract.json')
    for case in read(RAW / 'cases.json'):
        files.add(ROOT / case['daily'])
        files.update(ROOT / clause['path'] for clause in case['clauses'])
    checks = source_check()
    write(RAW / 'inputs.json', {'date': contract['date'], 'source_checks': checks,
                              'files': {p.relative_to(ROOT).as_posix(): digest(p)
                                        for p in sorted(files)}})
    print('Frozen', len(files), 'input and predecessor files', flush=True)


def preserved():
    files = read(RAW / 'inputs.json')['files']
    bad = [p for p, h in files.items() if not (ROOT / p).is_file() or digest(ROOT / p) != h]
    if bad:
        raise ValueError('Protected files changed: ' + str(bad[:5]))
    return len(files)


def load_case(case, contract):
    from transition_assets.phase82_windows import clean_daily_record, index_daily, sum_records
    panel = sorted([r for r in read(ROOT / contract['panel'])
                    if r['plant'] == case['facility_id'] and r['outcome_year'] == case['year']],
                   key=lambda r: r['key'])
    if [r['key'].split(':')[1] for r in panel] != case['units']:
        raise ValueError('Unexpected panel units: ' + case['id'])
    target = {(case['facility_id'], u) for u in case['units']}
    links = {pair: set() for pair in target}
    with (ROOT / contract['crosswalk']).open(encoding='utf-8-sig', newline='') as stream:
        for r in csv.DictReader(stream):
            pair = r['CAMD_PLANT_ID'], r['CAMD_UNIT_ID']
            if pair in links:
                links[pair].add((r['EIA_PLANT_ID'], r['EIA_GENERATOR_ID']))
    if any(values != {pair} for pair, values in links.items()):
        raise ValueError('Non-exclusive crosswalk: ' + case['id'])
    with (ROOT / case['daily']).open(encoding='utf-8-sig', newline='') as stream:
        rows = list(index_daily(clean_daily_record(r) for r in csv.DictReader(stream)
                              if (r['Facility ID'], r['Unit ID']) in target).values())
    start, end = date(case['year'], 1, 1), date(case['year'] + 1, 1, 1)
    expected = {(start + timedelta(days=i)).isoformat() for i in range((end-start).days)}
    units = []
    for p in panel:
        unit = p['key'].split(':')[1]
        daily = [r for r in rows if r['unit'] == unit]
        if {r['date'] for r in daily} != expected:
            raise ValueError('Incomplete unit/day coverage: ' + case['id'] + ':' + unit)
        totals = sum_records(daily)
        if any(totals[k] for k in ['missing_co2_unit_days', 'missing_gross_unit_days',
                                  'missing_hours_unit_days']):
            raise ValueError('Required measurements missing: ' + case['id'] + ':' + unit)
        if any(r['positive_co2_zero_hours'] for r in daily):
            raise ValueError('Positive CO2 with zero hours needs review')
        if abs(totals['co2_tonnes'] - p['e_actual']) > contract['tolerance_tonnes']:
            raise ValueError('Daily annual CO2 mismatch: ' + case['id'] + ':' + unit)
        positive = [r for r in daily if r['operating_hours'] > 0]
        units.append({'case_id': case['id'], 'unit': unit, **totals,
                      'last_positive_operating_date': max(r['date'] for r in positive) if positive else None,
                      'last_positive_co2_date': max((r['date'] for r in daily if r['co2_tonnes'] > 0), default=None),
                      'nameplate_mw': p['capacity_mw'],
                      'initial_plan': p['initial_plan'], 'current_plan': p['current_plan'],
                      'annual_forecast_tonnes': p['e_forecasts'][contract['annual_forecast_rule']],
                      'annual_forecast_net_mwh': p['g_forecasts'][contract['annual_forecast_rule']]})
    c = dict(case)
    if c['constraint_type'] == 'availability_mandate':
        c['orders'] = read(ROOT / c['orders'])
    return c, rows, units


def compute():
    from transition_assets.phase82_windows import sum_records
    from transition_assets.phase83_action_windows import assess_window, compare_ceilings
    protected = preserved()
    source_check()
    contract = read(RAW / 'contract.json')
    summaries, snapshots, daily_records, unit_totals, comparisons = [], [], [], [], []
    for raw_case in read(RAW / 'cases.json'):
        case, daily, units = load_case(raw_case, contract)
        e = math.fsum(r['annual_forecast_tonnes'] for r in units)
        g = math.fsum(r['annual_forecast_net_mwh'] for r in units)
        k = math.fsum(r['nameplate_mw'] for r in units)
        annual = sum_records(daily)
        summary = {'case_id': case['id'], 'name': case['name'], 'year': case['year'],
                   'units': case['units'], 'nameplate_mw': k, **annual,
                   'annual_persistence_tonnes': e, 'annual_persistence_net_mwh': g,
                   'annual_actual_net_mwh': math.fsum(r['g_actual'] for r in read(ROOT / contract['panel'])
                       if r['plant'] == case['facility_id'] and r['outcome_year'] == case['year']),
                   'annual_persistence_error_tonnes': e - annual['co2_tonnes'],
                   'last_positive_operating_date': max((r['last_positive_operating_date'] for r in units
                                                       if r['last_positive_operating_date']), default=None),
                   'plans': sorted({r['current_plan'] for r in units})}
        if case['id'] == 'rush':
            summary['after_boiler_deadline'] = sum_records(r for r in daily if r['date'] > '2024-10-15')
            summary['after_all_operation_deadline'] = sum_records(r for r in daily if r['date'] > '2024-10-25')
            summary['on_boiler_boundary'] = sum_records(r for r in daily if r['date'] == '2024-10-15')
        summaries.append(summary)
        daily_records.extend({'case_id': case['id'], **r} for r in daily)
        unit_totals.extend(units)
        for asof in case['snapshots']:
            for mu in contract['replacement_intensities']:
                keys = ['boiler_end_inclusive', 'all_operation_end_inclusive'] if case['id'] == 'rush' else ['boiler_end_inclusive']
                for deadline_key in keys:
                    r = assess_window(case, asof, e, g, k, mu, deadline_key)
                    remaining = sum_records(d for d in daily if d['date'] >= r['action_date'])
                    window = sum_records(d for d in daily if r['ceiling_start_inclusive'] <= d['date'] < r['ceiling_end_exclusive'])
                    r['observed_remaining'] = remaining
                    r['observed_window'] = window
                    r['observed_outside_window_tonnes'] = remaining['co2_tonnes'] - window['co2_tonnes']
                    r['break_even_cost_ceilings'] = {str(v): v * r['net_exposure_ceiling_tonnes']
                                                   for v in contract['illustrative_carbon_values']}
                    if case['id'] == 'rush':
                        r['unconstrained_remaining_prediction_error_tonnes'] = r['remaining_forecast_tonnes'] - remaining['co2_tonnes']
                        r['deadline_remaining_prediction_error_tonnes'] = r['window_forecast_tonnes'] - remaining['co2_tonnes']
                    snapshots.append(r)
    for asof in contract['common_2025_snapshots']:
        for mu in contract['replacement_intensities']:
            a = next(r for r in snapshots if r['case_id'] == 'campbell' and r['asof'] == asof and r['mu'] == mu)
            b = next(r for r in snapshots if r['case_id'] == 'brandon' and r['asof'] == asof and r['mu'] == mu)
            r = compare_ceilings(a, b)
            ungated = [(x['remaining_net_exposure_ceiling_tonnes'] /
                        next(s['nameplate_mw'] for s in summaries if s['case_id'] == x['case_id']), x['case_id']) for x in [a, b]]
            r['larger_unconstrained_ceiling_case'] = max(ungated)[1] if ungated[0][0] != ungated[1][0] else 'tie'
            comparisons.append(r)
    return {'phase': 83, 'protected_file_count': protected, 'cases': summaries,
            'snapshots': snapshots, 'comparisons': comparisons,
            'unit_totals': unit_totals, 'daily_records': daily_records,
            'identified_achievable_benefit_or_project_ranking': False,
            'research_status': 'retrospective purposive case diagnostic; not a national sample or new predictor'}


def export_csv(path, rows):
    rows = [{k: json.dumps(v, sort_keys=True) if isinstance(v, (list, dict)) else v
             for k, v in r.items()} for r in rows]
    names = sorted({k for r in rows for k in r})
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=names, lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)


def emit(result, destination):
    write(destination / 'results.json', {k: v for k, v in result.items() if k != 'daily_records'})
    for key in ['snapshots', 'comparisons', 'unit_totals', 'daily_records']:
        export_csv(destination / (key + '.csv'), result[key])


def verify(result):
    """Independent raw-unit totals and direct calendar arithmetic, no assess_window call."""
    contract = read(RAW / 'contract.json')
    panel = read(ROOT / contract['panel'])
    raw_daily = {}
    for c in read(RAW / 'cases.json'):
        target = {(c['facility_id'], u) for u in c['units']}
        with (ROOT / c['daily']).open(encoding='utf-8-sig', newline='') as stream:
            for row in csv.DictReader(stream):
                pair = row['Facility ID'], row['Unit ID']
                if pair not in target:
                    continue
                key = (c['id'], row['Unit ID'], row['Date'])
                if key in raw_daily:
                    raise ValueError('Independent duplicate raw record')
                hours = float(row['Sum of the Operating Time'])
                if row['CO2 Mass (short tons)'].strip():
                    carbon = float(row['CO2 Mass (short tons)']) * .90718474
                elif hours == 0:
                    carbon = 0.
                else:
                    raise ValueError('Independent missing carbon')
                gross = float(row['Gross Load (MWh)']) if row['Gross Load (MWh)'].strip() else (0. if hours == 0 else None)
                if gross is None:
                    raise ValueError('Independent missing gross generation')
                raw_daily[key] = (carbon, gross, hours)
    checks = 0

    def close(a, b):
        nonlocal checks
        if not math.isclose(a, b, abs_tol=1e-6, rel_tol=1e-12):
            raise ValueError(f'Independent mismatch: {a} != {b}')
        checks += 1

    for row in result['daily_records']:
        raw = raw_daily[(row['case_id'], row['unit'], row['date'])]
        for key, value in zip(['co2_tonnes', 'gross_mwh', 'operating_hours'], raw):
            close(row[key], value)
    for case in result['cases']:
        raw = [r for (cid, _, _), r in raw_daily.items() if cid == case['case_id']]
        for key, index in [('co2_tonnes', 0), ('gross_mwh', 1), ('operating_hours', 2)]:
            close(case[key], math.fsum(r[index] for r in raw))
        c = next(c for c in read(RAW / 'cases.json') if c['id'] == case['case_id'])
        p = [r for r in panel if r['plant'] == c['facility_id'] and r['outcome_year'] == c['year']]
        close(case['co2_tonnes'], math.fsum(r['e_actual'] for r in p))
    for unit in result['unit_totals']:
        values = [(d, v) for (cid, u, d), v in raw_daily.items()
                  if cid == unit['case_id'] and u == unit['unit']]
        for field, index in [('co2_tonnes', 0), ('gross_mwh', 1), ('operating_hours', 2)]:
            close(unit[field], math.fsum(v[index] for _, v in values))
        last = max((d for d, v in values if v[2] > 0), default=None)
        if last != unit['last_positive_operating_date']:
            raise ValueError('Last operating day mismatch')
        checks += 1
    raw_cases = {c['id']: c for c in read(RAW / 'cases.json')}
    for row in result['snapshots']:
        c = raw_cases[row['case_id']]
        s = next(s for s in result['cases'] if s['case_id'] == row['case_id'])
        action = date.fromisoformat(row['asof']) + timedelta(days=1)
        end = date(row['year'] + 1, 1, 1)
        count = (end - date(row['year'], 1, 1)).days
        remaining = (end - action).days
        if row['case_id'] == 'campbell':
            # The independent source-date schedule is explicit, not derived by the model.
            bound = {'2025-08-08': '2025-08-21', '2025-08-20': '2025-11-19',
                     '2025-11-18': '2026-02-17'}[row['asof']]
            days = max(0, (end - date.fromisoformat(bound)).days)
            if row['earliest_not_blocked'] != bound:
                raise ValueError('Campbell bound mismatch')
        elif row['case_id'] == 'rush':
            bound = '2024-10-15' if row['deadline_key'] == 'boiler_end_inclusive' else '2024-10-25'
            days = max(0, (min(end, date.fromisoformat(bound) + timedelta(days=1)) - action).days)
            if row['latest_operation_date'] != bound:
                raise ValueError('Rush deadline mismatch')
        else:
            days = remaining
            if row['earliest_not_blocked'] is not None or row['release_status'] != 'not_identified':
                raise ValueError('Unknown contractual release improperly classified')
        close(row['ceiling_days'], days)
        close(row['remaining_days'], remaining)
        close(row['remaining_forecast_tonnes'], s['annual_persistence_tonnes'] * remaining / count)
        signed_rate = (s['annual_persistence_tonnes'] - row['mu'] * s['annual_persistence_net_mwh']) / count
        close(row['net_exposure_ceiling_tonnes'], max(0, signed_rate) * days)
        close(row['window_forecast_tonnes'], s['annual_persistence_tonnes'] * days / count)
        close(row['excluded_forecast_tonnes'] + row['window_forecast_tonnes'], row['remaining_forecast_tonnes'])
        close(row['net_exposure_ceiling_tonnes_per_mw'], row['net_exposure_ceiling_tonnes'] / s['nameplate_mw'])
        for v, value in row['break_even_cost_ceilings'].items():
            close(value, float(v) * max(0, signed_rate) * days)
        for bucket, predicate in [('observed_remaining', lambda d: d >= row['action_date']),
                                  ('observed_window', lambda d: row['ceiling_start_inclusive'] <= d < row['ceiling_end_exclusive'])]:
            values = [v for (cid, _, d), v in raw_daily.items() if cid == c['id'] and predicate(d)]
            for field, index in [('co2_tonnes', 0), ('gross_mwh', 1), ('operating_hours', 2)]:
                close(row[bucket][field], math.fsum(v[index] for v in values))
        if any(r['published'] > row['asof'] for r in c['clauses'] if r['id'] in row['known_clause_ids']):
            raise ValueError('Later document leaked')
    for row in result['comparisons']:
        a, b = [next(r for r in result['snapshots'] if r['case_id'] == cid and
                     r['asof'] == row['asof'] and r['mu'] == row['mu']) for cid in ['campbell', 'brandon']]
        av, bv = a['net_exposure_ceiling_tonnes_per_mw'], b['net_exposure_ceiling_tonnes_per_mw']
        larger = 'tie' if math.isclose(av, bv, abs_tol=1e-12, rel_tol=1e-12) else ('campbell' if av > bv else 'brandon')
        if row['larger_ceiling_case'] != larger or row['project_order'] != 'not_identified':
            raise ValueError('Ceiling order improperly interpreted')
        checks += 1
    return {'status': 'passed', 'independent_checks': checks, 'daily_records': len(raw_daily),
            'snapshots': len(result['snapshots']), 'comparison_rows': len(result['comparisons']),
            'protected_files_unchanged': preserved(), 'source_checks': source_check()}


def create_figures(result):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.dates import DateFormatter, MonthLocator
    import numpy as np
    folder = ROOT / 'outputs/phase83'
    folder.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 10, 'axes.spines.top': False,
                         'axes.spines.right': False, 'axes.linewidth': .7,
                         'savefig.dpi': 180, 'axes.labelsize': 10})
    blue, teal, red, gray = '#28699C', '#248579', '#AF5454', '#71777D'
    dates = read(RAW / 'contract.json')['common_2025_snapshots']
    summaries = {r['case_id']: r for r in result['cases']}
    rows = {(r['case_id'], r['asof']): r for r in result['snapshots'] if r['mu'] == 0 and r['case_id'] != 'rush'}
    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.5))
    xs = np.arange(len(dates))
    for cid, colour, name in [('campbell', blue, 'Campbell'), ('brandon', teal, 'Brandon Shores')]:
        unconstrained = [rows[cid, d]['remaining_forecast_tonnes'] / summaries[cid]['nameplate_mw'] for d in dates]
        constrained = [rows[cid, d]['net_exposure_ceiling_tonnes_per_mw'] for d in dates]
        axes[0].plot(xs, unconstrained, 'o-', color=colour, linewidth=1.8, markersize=5, label=name)
        axes[1].plot(xs, constrained, 'o-', color=colour, linewidth=1.8, markersize=5, label=name)
        axes[1].vlines(xs + (-.045 if cid == 'campbell' else .045), 0, constrained,
                       color=colour, alpha=.28, linewidth=5)
    for i, (ax, title) in enumerate(zip(axes, ['Remaining emissions projection', 'Action-window ceiling'])):
        ax.set_title(f'({chr(97+i)}) {title}', loc='left', fontsize=11, fontweight='bold', pad=13)
        ax.set_xticks(xs, ['8 Aug', '20 Aug', '18 Nov'])
        ax.set_xlim(-.22, 2.22)
        ax.set_ylim(-55, 2250)
        ax.set_ylabel('Conditional exposure (tCO2 / MW)')
        ax.set_xlabel('End-of-day information cutoff, 2025')
        ax.grid(axis='y', color='#EBEEF0', linewidth=.7)
        ax.set_axisbelow(True)
    axes[0].legend(frameon=False, loc='upper right', fontsize=9)
    axes[1].annotate('649', (1, 649), xytext=(9, 10), textcoords='offset points', color=teal, fontsize=9)
    axes[1].annotate('610', (1, 610), xytext=(9, -16), textcoords='offset points', color=blue, fontsize=9)
    fig.subplots_adjust(left=.075, right=.98, top=.88, bottom=.24, wspace=.27)
    fig.text(.075, .065, 'mu = 0. Shaded stems span zero to each optimistic ceiling; actual achievable benefits are not identified.', fontsize=9, color=gray)
    fig.savefig(folder / 'common_date_ceilings.png', facecolor='white')
    plt.close(fig)

    rush = [r for r in result['daily_records'] if r['case_id'] == 'rush']
    days = sorted({r['date'] for r in rush})
    amounts = {d: math.fsum(r['co2_tonnes'] for r in rush if r['date'] == d) / 1000 for d in days}
    fig, axes = plt.subplots(1, 2, figsize=(11.1, 4.5), gridspec_kw={'width_ratios': [1.25, 1]})
    ax = axes[0]
    ax.plot([date.fromisoformat(d) for d in days], [amounts[d] for d in days], color=blue, linewidth=1.2)
    ax.axvspan(date(2024, 10, 16), date(2025, 1, 1), color='#F0F3F5', zorder=0)
    ax.axvline(date(2024, 10, 15), color=red, linewidth=1.3)
    ax.set_title('(a) Observed daily operation', loc='left', fontsize=11, fontweight='bold', pad=13)
    ax.set_ylabel('Daily CO2 (kt)')
    ax.set_xlabel('Rush Island, 2024')
    ax.set_xlim(date(2024, 1, 1), date(2024, 12, 31))
    ax.set_ylim(-.3, max(amounts.values()) * 1.2)
    ax.text(date(2024, 10, 18), ax.get_ylim()[1]*.88, '15 Oct\nboiler deadline', color=red, fontsize=9)
    ax.text(date(2024, 10, 18), ax.get_ylim()[1]*.58, 'No operation\nafter deadline', color=gray, fontsize=9)
    ax.xaxis.set_major_locator(MonthLocator(interval=2))
    ax.xaxis.set_major_formatter(DateFormatter('%b'))
    ax.grid(axis='y', color='#EBEEF0', linewidth=.7)
    ax.set_axisbelow(True)
    ax = axes[1]
    titles = ['31 May', '5 Sep']
    rows = [next(r for r in result['snapshots'] if r['case_id'] == 'rush' and r['mu'] == 0
                 and r['asof'] == d and r['deadline_key'] == 'boiler_end_inclusive') for d in ['2024-05-31', '2024-09-05']]
    x = np.arange(2)
    for offset, field, colour, label in [(-.24, 'remaining_forecast_tonnes', gray, 'No deadline'),
                                        (0, 'window_forecast_tonnes', teal, 'Court deadline'),
                                        (.24, 'actual', blue, 'Observed remaining')]:
        values = [(r['observed_remaining']['co2_tonnes'] if field == 'actual' else r[field]) / 1000 for r in rows]
        ax.bar(x + offset, values, width=.22, color=colour, label=label)
        for xpos, value in zip(x + offset, values):
            ax.text(xpos, value + 7, f'{value:.1f}', ha='center', va='bottom', fontsize=8.5)
    ax.set_title('(b) Same-rate remaining projections', loc='left', fontsize=11, fontweight='bold', pad=13)
    ax.set_ylabel('Remaining CO2 (kt)')
    ax.set_xlabel('End-of-day information cutoff, 2024')
    ax.set_xticks(x, titles)
    ax.set_ylim(0, 585)
    ax.grid(axis='y', color='#EBEEF0', linewidth=.7)
    ax.set_axisbelow(True)
    ax.legend(frameon=False, loc='upper right', fontsize=8.5)
    fig.subplots_adjust(left=.067, right=.98, top=.88, bottom=.24, wspace=.28)
    fig.text(.067, .065, 'Court date is inclusive in daily accounting. Last positive operation: 21 Sep. This comparison is not a causal effect.', fontsize=9, color=gray)
    fig.savefig(folder / 'rush_deadline_operation.png', facecolor='white')
    plt.close(fig)


def render_sources():
    folder = ROOT / 'outputs/phase83/source_pages'
    folder.mkdir(parents=True, exist_ok=True)
    for case in read(RAW / 'cases.json'):
        for clause in case['clauses']:
            for page in clause['pages']:
                target = folder / f"{clause['id']}_p{page:02d}"
                subprocess.run(['pdftoppm', '-f', str(page), '-l', str(page),
                                '-singlefile', '-scale-to', '1400', '-png',
                                str(ROOT / clause['path']), str(target)],
                               check=True, capture_output=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['freeze', 'run', 'verify', 'reproduce'], required=True)
    args = parser.parse_args()
    if args.mode == 'freeze':
        freeze()
    else:
        result = compute()
        if args.mode == 'run':
            emit(result, OUT)
            create_figures(result)
            render_sources()
        verification = verify(result)
        if args.mode in ['verify', 'reproduce']:
            for key, value in {k: v for k, v in result.items() if k != 'daily_records'}.items():
                if read(OUT / 'results.json')[key] != value:
                    raise ValueError('Stored result differs: ' + key)
        if args.mode == 'reproduce':
            repeat = ROOT / 'tmp/phase83_repeat'
            emit(result, repeat)
            names = ['results.json', 'snapshots.csv', 'comparisons.csv', 'unit_totals.csv', 'daily_records.csv']
            for name in names:
                if (OUT / name).read_bytes() != (repeat / name).read_bytes():
                    raise ValueError('Non-reproducible product: ' + name)
            write(OUT / 'reproduction.json', {'status': 'passed', 'identical_products': names})
        write(OUT / 'verification.json', verification)
        write(OUT / 'environment.json', {'python': platform.python_version(), 'platform': platform.platform()})
        print(json.dumps({k: v for k, v in verification.items() if k != 'source_checks'}, indent=2), flush=True)


if __name__ == '__main__':
    main()
