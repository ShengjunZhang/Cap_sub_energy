"""Recompute fixed appraisal experiments on reported annual support."""
import argparse
import itertools
import json
import platform
from pathlib import Path
import sys
import numpy as np
import scipy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.run_phase84_support import read, write, digest, write_csv
from scripts.run_phase79_portfolios import evaluate_case, RULES
from transition_assets.phase85_integration import panel_counts, compare_losses, evaluate_corrected
from transition_assets.phase85_solver_v2 import solve_nominal, ABSOLUTE_TIE_ACCEPTANCES, PRECISION_RETRIES

RAW = ROOT / 'data/raw/phase85'
OUT = ROOT / 'data/processed/phase85'
PRODUCTS = ['annual.json', 'calibrated.json', 'sensitivities.json', 'summary.json',
            'allocation_source.csv', 'calibration_source.csv']


def freeze():
    if (RAW/'inputs.json').exists():
        raise ValueError('Inputs already frozen')
    prior = read(ROOT/'data/raw/phase84/inputs.json')['files']
    prior.update(read(ROOT/'data/raw/phase84/reported_annual_inputs.json')['files'])
    for p, h in prior.items():
        if digest(ROOT/p) != h:
            raise ValueError('Changed predecessor: ' + p)
    names = set(prior)
    for folder in ['data/raw/phase84', 'data/processed/phase84', 'outputs/phase84',
                   'manuscript/omega_v2_cas']:
        names.update(p.relative_to(ROOT).as_posix() for p in (ROOT/folder).rglob('*') if p.is_file())
    names.update(['outputs/phase84_report.md', 'scripts/run_phase84_support.py',
                  'transition_assets/phase84_support.py', 'tests/test_phase84_support.py',
                  'data/raw/phase85/contract.json', 'tests/fixtures/phase85_integration.json',
                  'scripts/run_phase79_portfolios.py', 'transition_assets/phase79_portfolios.py',
                  'transition_assets/phase80_calibration.py', 'data/raw/phase79/contract.json',
                  'data/raw/phase80/contract.json'])
    write(RAW/'inputs.json', {'files': {p: digest(ROOT/p) for p in sorted(names)}})
    print('Frozen files:', len(names), flush=True)


def preserved():
    names = read(RAW/'inputs.json')['files']
    for p, h in names.items():
        if digest(ROOT/p) != h:
            raise ValueError('Changed frozen file: ' + p)
    if (RAW/'numerical_inputs.json').exists():
        for p,h in read(RAW/'numerical_inputs.json')['files'].items():
            if digest(ROOT/p)!=h: raise ValueError('Numerical amendment changed: '+p)
    if (RAW/'precision_inputs.json').exists():
        for p,h in read(RAW/'precision_inputs.json')['files'].items():
            if digest(ROOT/p)!=h: raise ValueError('Precision retry changed: '+p)
    return len(names)


def central(c, contract):
    return all(c[k] == v for k, v in contract['central'].items())


def summary_comparisons(cases, methods, comparators):
    return {m: {b: compare_losses(cases, m, b) for b in comparators} for m in methods}


def run():
    preserved()
    contract = read(RAW/'contract.json')
    a = read(ROOT/contract['annual_contract'])
    b = read(ROOT/contract['calibration_contract'])
    panel = read(ROOT/contract['panel'])
    counts = panel_counts(panel)
    for k, expected in [('rows', 'expected_rows'), ('generators', 'expected_generators'),
                        ('plants', 'expected_plants'), ('exit_rows', 'expected_exit_rows')]:
        if counts[k] != contract[expected]:
            raise ValueError('Unexpected annual support: ' + k)
    annual = []
    for year, mu, q, f in itertools.product(a['years'], a['replacement_intensities'], a['carbon_equivalent_costs'], a['capacity_fractions']):
        rows = sorted([r for r in panel if r['outcome_year'] == year], key=lambda r:r['key'])
        annual.append(evaluate_case(rows, year, mu, q, f))
        if len(annual) % 27 == 0: print('Annual cases:', len(annual), flush=True)
    calibrated = [evaluate_corrected(panel, c, b['centers']) for c in annual
                  if c['year'] in b['evaluation_years']]
    sensitivities = []
    for year in a['years']:
        base = sorted([r for r in panel if r['outcome_year'] == year], key=lambda r:r['key'])
        groups = [('initial_plan_after_origin', None,
                   [r for r in base if r['initial_plan'] > r['origin']])]
        groups += [('central_leave_one_plant_out', plant,
                    [r for r in base if r['plant'] != plant]) for plant in sorted({r['plant'] for r in base})]
        for name, plant, rows in groups:
            if not rows: continue
            case = evaluate_case(rows, year, **a['central'])
            case.update(sensitivity=name, omitted_plant=plant)
            sensitivities.append(case)
        print('Sensitivity year:', year, flush=True)
    new_methods = [c+'_'+s for c in b['centers'] for s in ['median','calibrated_regret']]
    summary = dict(panel=counts, annual_cases=len(annual), calibration_cases=len(calibrated),
        sensitivity_cases=len(sensitivities),
        annual_comparisons=summary_comparisons(annual, ['updated_recent','minimax_regret'], ['persistence','initial_older','updated_recent']),
        calibrated_comparisons=summary_comparisons(calibrated, new_methods, ['updated_recent','persistence','minimax_regret']),
        central=[c for c in annual if central(c,a)],
        central_calibrated=[c for c in calibrated if central(c,a)],
        sensitivity_comparisons={name:summary_comparisons([c for c in sensitivities if c['sensitivity']==name],
            ['updated_recent','minimax_regret'], ['persistence','updated_recent'])
            for name in contract['retained_sensitivities']})
    write(OUT/'annual.json', annual)
    write(OUT/'calibrated.json', calibrated)
    write(OUT/'sensitivities.json', sensitivities)
    write(OUT/'summary.json', summary)
    for fname, cases in [('allocation_source.csv', annual), ('calibration_source.csv', calibrated)]:
        write_csv(OUT/fname, [dict(year=c['year'],mu=c['mu'],q=c['q'],fraction=c['fraction'],method=m,
                       regret_mt=r['observed_regret_mt'],value_mt=r['observed_value_mt'],capacity_mw=r['capacity_mw'])
                       for c in cases for m,r in c['methods'].items()])
    write(OUT/'environment.json', dict(python=sys.version, numpy=np.__version__, scipy=scipy.__version__, platform=platform.platform()))
    write(OUT/'solver_tie_diagnostics.json', ABSOLUTE_TIE_ACCEPTANCES)
    write(OUT/'solver_precision_retries.json', PRECISION_RETRIES)
    verify()
    print(json.dumps(summary['annual_comparisons'],indent=2), flush=True)


def verify():
    frozen = preserved()
    contract = read(RAW/'contract.json')
    panel = read(ROOT/contract['panel'])
    cases = read(OUT/'annual.json') + read(OUT/'sensitivities.json')
    max_relative = max_absolute = 0.
    checks = 0
    for c in cases:
        by_key = {r['key']:r for r in panel if r['outcome_year']==c['year']}
        rows = [by_key[k] for k in c['keys']]
        capacity = np.array([r['capacity_mw'] for r in rows])
        actual = np.array([r['e_actual']-c['mu']*r['g_actual']-c['q']*r['capacity_mw'] for r in rows])/1e6
        forecasts = np.array([[r['e_forecasts'][m]-c['mu']*r['g_forecasts'][m]-c['q']*r['capacity_mw'] for r in rows] for m in RULES])/1e6
        np.testing.assert_allclose(actual, c['observed_values_mt'], atol=1e-10)
        np.testing.assert_allclose(forecasts, c['forecast_values_mt'], atol=1e-10)
        reference = solve_nominal(actual, capacity, c['limit_mw'])
        np.testing.assert_allclose(reference['value'], c['reference_value_mt'], atol=1e-7)
        for name, ans in c['methods'].items():
            x = np.array(ans['x'])
            if not np.all((x==0)|(x==1)) or capacity@x > c['limit_mw']+1e-6:
                raise ValueError('Invalid annual portfolio')
            np.testing.assert_allclose(actual@x, ans['observed_value_mt'], atol=1e-8)
            np.testing.assert_allclose(max(0.,reference['value']-actual@x), ans['observed_regret_mt'],atol=1e-7)
            np.testing.assert_allclose(forecasts@x, ans['scenario_values_mt'],atol=1e-8)
            np.testing.assert_allclose(max(np.array(c['scenario_optima_mt'])-forecasts@x), ans['max_baseline_regret_mt'],atol=1e-7)
            max_relative=max(max_relative,ans['solver_gap'])
            max_absolute=max(max_absolute,ans['solver_absolute_gap_mt'])
            checks+=5
        if c['methods']['minimax_regret']['max_baseline_regret_mt'] > min(v['max_baseline_regret_mt'] for v in c['methods'].values())+1e-6:
            raise ValueError('Baseline stress bound failed')
        checks+=3
    calibrated=read(OUT/'calibrated.json')
    for c in calibrated:
        capacity=np.array(c['capacities'])
        for center, meta in c['calibration'].items():
            if not meta['training_years'] or max(meta['training_years'])>=c['year']:
                raise ValueError('Chronological calibration failed')
            values=np.array(meta['scenario_values_mt'])
            optima=np.array([solve_nominal(v,capacity,c['limit_mw'])['value'] for v in values])
            raw=next(a for a in cases if all(a[k]==c[k] for k in ['year','mu','q','fraction']) and 'sensitivity' not in a)
            actual=np.array(raw['observed_values_mt'])
            for suffix in ['median','calibrated_regret']:
                ans=c['methods'][center+'_'+suffix]; x=np.array(ans['x'])
                if not np.all((x==0)|(x==1)) or capacity@x>c['limit_mw']+1e-6: raise ValueError('Invalid calibrated portfolio')
                np.testing.assert_allclose(actual@x,ans['observed_value_mt'],atol=1e-8)
                np.testing.assert_allclose(max(0.,c['reference_value_mt']-actual@x),ans['observed_regret_mt'],atol=1e-7)
                np.testing.assert_allclose(max(optima-values@x),ans['training_stress_max_regret_mt'],atol=1e-7)
                max_relative=max(max_relative,ans['solver_gap']); max_absolute=max(max_absolute,ans['absolute_solver_gap_mt'])
                checks+=5
            if c['methods'][center+'_calibrated_regret']['training_stress_max_regret_mt']>c['methods'][center+'_median']['training_stress_max_regret_mt']+1e-6:
                raise ValueError('Calibrated stress bound failed')
    if len(read(OUT/'annual.json'))!=108 or len(calibrated)!=81 or max_relative>contract['solver_relative_acceptance'] or max_absolute>contract['solver_absolute_acceptance_mt']:
        raise ValueError('Count or solver precision failed')
    write(OUT/'verification.json',dict(status='pass',checks=checks,frozen_files=frozen,max_relative_gap=max_relative,max_absolute_gap_mt=max_absolute))
    print('Verified checks:',checks,flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=['freeze','freeze-numerical','freeze-precision','run','verify','reproduce'],default='run')
    mode=parser.parse_args().mode
    if mode=='freeze': freeze()
    elif mode=='freeze-numerical':
        if (RAW/'numerical_inputs.json').exists(): raise ValueError('Numerical amendment already frozen')
        names=['data/raw/phase85/numerical_amendment.json','transition_assets/phase85_solver.py']
        write(RAW/'numerical_inputs.json',{'files':{p:digest(ROOT/p) for p in names}})
    elif mode=='freeze-precision':
        if (RAW/'precision_inputs.json').exists(): raise ValueError('Precision retry already frozen')
        names=['data/raw/phase85/precision_amendment.json','transition_assets/phase85_solver_v2.py']
        write(RAW/'precision_inputs.json',{'files':{p:digest(ROOT/p) for p in names}})
    elif mode=='verify': verify()
    elif mode=='reproduce':
        before={p:digest(OUT/p) for p in PRODUCTS}
        run()
        after={p:digest(OUT/p) for p in PRODUCTS}
        if before!=after: raise ValueError('Scientific products changed on repeat')
        write(OUT/'reproduction.json',dict(status='pass',sha256=after))
    else: run()
