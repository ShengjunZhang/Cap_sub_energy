"""Read-only operating-record coverage, not an energy-effect estimator."""

import argparse
import calendar
import csv
from collections import Counter, defaultdict
from datetime import date
import hashlib
import io
import json
import math
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parents[1]
RAW = Path("data/raw/phase43")
OUT = Path("data/processed/phase43")
MONTHS = list(calendar.month_name)[1:]


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def numeric(value):
    if isinstance(value, bool):
        return None
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (ValueError, TypeError):
        return None


def identifier(value):
    if value is None:
        return ""
    if isinstance(value, (float, int)) and not isinstance(value, bool):
        return str(int(value)) if float(value).is_integer() else str(value)
    return str(value).strip()


def cohort_index(records):
    indexed = {}
    for row in records:
        key = (row["eia_plant_id"], row["eia_generator_id"])
        if not all(key) or key in indexed:
            raise ValueError(f"Missing or duplicate cohort key: {key}")
        indexed[key] = row
    return indexed


def shifted_month(anchor, offset):
    index = anchor.year * 12 + anchor.month - 1 + offset
    return f"{index // 12:04}-{index % 12 + 1:02}"


def month_window(anchor):
    if not anchor:
        return [], []
    d = date.fromisoformat(anchor)
    return ([shifted_month(d, i) for i in range(-12, 0)],
            [shifted_month(d, i) for i in range(1, 13)])


def paired_month_counts(anchor, available):
    before, after = month_window(anchor)
    return {"before": len(set(before) & available),
            "after": len(set(after) & available),
            "two_sided_24_months": bool(before) and set(before + after) <= available}


def parse_monitor_pairs(value):
    result = set()
    for token in str(value or "").split(";"):
        if token:
            plant, unit = token.split(":", 1)
            if not plant or not unit:
                raise ValueError("Empty monitor identifier")
            result.add((plant, unit))
    return result


def update_day(days, day, value):
    if day not in days:
        days[day] = value
    elif days[day] != value:
        days[day] = None


def target_day_months(pairs, coverage):
    if not pairs:
        return set()
    return set.intersection(*(coverage.get(pair, set()) for pair in pairs))


def complete_daily_months(days):
    month_days = defaultdict(set)
    for day, values in days.items():
        if values is not None and all(v is not None for v in values) and 0 <= values[0] <= 24 and values[1] >= 0 and values[2] >= 0:
            month_days[day[:7]].add(day)
    return {m for m, ds in month_days.items()
            if len(ds) == calendar.monthrange(int(m[:4]), int(m[5:7]))[1]}


def effect_interpretation(identified, interval, margin):
    # Used only by logical fixtures; no interval is estimated in this phase.
    if not identified or interval is None or margin is None:
        return "unresolved"
    lo, hi = interval
    if not all(numeric(x) is not None for x in (lo, hi, margin)) or lo > hi or margin < 0:
        raise ValueError("Invalid interval or margin")
    if lo >= -margin and hi <= margin:
        return "bounded_negligible"
    if lo > margin:
        return "material_positive"
    if hi < -margin:
        return "material_negative"
    return "unresolved"


def xlsx_records(iterator):
    for line, values in enumerate(iterator, 1):
        labels = [" ".join(str(x).split()) if x is not None else "" for x in values]
        if "Plant Id" in labels:
            def remaining():
                for row_line, row in enumerate(iterator, line + 1):
                    yield row_line, dict(zip(labels, row))
            return line, remaining()
        if line > 15:
            break
    raise ValueError("EIA-923 Plant Id header not found")


def record_months(row, year, prefix):
    return {f"{year}-{month:02}" for month, name in enumerate(MONTHS, 1)
            if numeric(row.get(prefix + " " + name)) is not None}


def prepare():
    contract = read_json(ROOT / RAW / "contract.json")
    sources = rows(ROOT / contract["source_manifest"])
    paths = {r["local_path"] for r in sources}
    paths.update(contract[k] for k in ("pool", "identity", "completion", "source_manifest"))
    paths.update([
        "data/processed/phase14_1/asof_plan_episode_panel.csv",
        "data/processed/phase20/primary_episode_ledger.csv",
        "data/processed/phase26_1/retired_registry.csv",
        "data/raw/phase40/artifact_manifest.json",
        "data/raw/phase41/artifact_manifest.json",
        "data/raw/phase42/artifact_manifest.json",
        "docs/phase33_research_design.md",
        "outputs/phase31_decision_window_report.md",
        "outputs/phase32_case_screen_report.md",
        "outputs/phase40_regional_report.md",
        "outputs/phase41_joint_plans_report.md",
        "outputs/phase42_information_report.md",
    ])
    paths.update(p.relative_to(ROOT).as_posix() for p in (ROOT / "data/raw/eia_grid_monitor").glob("*.json"))
    paths.update(p.relative_to(ROOT).as_posix() for p in (ROOT / "manuscript").glob("*.tex"))
    expected = {r["local_path"]: r["sha256"].lower() for r in sources}
    lock = []
    for name in sorted(paths):
        path = ROOT / name
        digest = sha(path)
        if name in expected and expected[name] != digest:
            raise ValueError(f"Original source hash changed: {name}")
        lock.append({"path": name, "bytes": path.stat().st_size, "sha256": digest})
    target = ROOT / RAW / "input_lock.json"
    if target.exists() and read_json(target) != lock:
        raise ValueError("Refusing to replace the frozen input lock")
    write_json(target, lock)
    print(json.dumps({"inputs_locked": len(lock)}), flush=True)


def check_inputs():
    records = read_json(ROOT / RAW / "input_lock.json")
    for record in records:
        path = ROOT / record["path"]
        if path.stat().st_size != record["bytes"] or sha(path) != record["sha256"]:
            raise ValueError(f"Protected input changed: {record['path']}")
    return len(records)


def scan_epa(sources, linked):
    wanted = set().union(*(parse_monitor_pairs(r["camd_monitor_pairs"]) for r in linked.values()))
    by_pair = defaultdict(dict)
    pair_files = defaultdict(set)
    file_records = []
    for i, source in enumerate([r for r in sources if r["kind"] == "epa_daily_part75"], 1):
        path = ROOT / source["local_path"]
        plants, pairs, dates = set(), set(), set()
        target_rows = total = 0
        with path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            required = {"Facility ID", "Unit ID", "Date", "Sum of the Operating Time", "Gross Load (MWh)", "CO2 Mass (short tons)"}
            if not required <= set(reader.fieldnames):
                raise ValueError(f"Unexpected EPA schema: {path.name}")
            for row in reader:
                total += 1
                pair = (identifier(row["Facility ID"]), identifier(row["Unit ID"]))
                plants.add(pair[0])
                pairs.add(pair)
                day = row["Date"]
                dates.add(day)
                if pair not in wanted:
                    continue
                date.fromisoformat(day)
                target_rows += 1
                value = tuple(numeric(row[name]) for name in ("Sum of the Operating Time", "Gross Load (MWh)", "CO2 Mass (short tons)"))
                update_day(by_pair[pair], day, value)
                pair_files[pair].add(source["local_path"])
        file_records.append({"path": source["local_path"], "rows": total, "target_rows": target_rows,
                             "reported_facilities": len(plants), "reported_monitor_pairs": len(pairs),
                             "non_target_monitor_pairs": len(pairs - wanted),
                             "first_day": min(dates) if dates else None, "last_day": max(dates) if dates else None,
                             "distinct_dates": len(dates)})
        if i % 20 == 0:
            print(f"EPA source coverage {i}", flush=True)
    complete, present = {}, {}
    pair_summary = []
    for pair, days in sorted(by_pair.items()):
        complete[pair] = complete_daily_months(days)
        present[pair] = {d[:7] for d in days}
        pair_summary.append({"pair": list(pair), "months_with_any_records": sorted(present[pair]),
                             "months_with_every_day_numeric": sorted(complete[pair]),
                             "conflicting_days": sum(v is None for v in days.values()),
                             "files": sorted(pair_files[pair])})
    return complete, present, {"files": file_records, "target_monitors": pair_summary}


def scan_eia923(sources, cohort):
    import openpyxl
    unit_years, plant_years, audits = {}, {}, []
    target_plants = {key[0] for key in cohort}
    for source in [r for r in sources if r["kind"] == "eia923_archive"]:
        path = ROOT / source["local_path"]
        with zipfile.ZipFile(path) as archive:
            members = [n for n in archive.namelist() if "Schedules_2_3_4_5" in n and n.endswith(".xlsx")]
            if len(members) != 1:
                raise ValueError("Ambiguous EIA-923 member")
            member = members[0]
            book = openpyxl.load_workbook(io.BytesIO(archive.read(member)), read_only=True, data_only=True)
        year = int(path.name.split("_")[1][:4])
        for sheet, unit_level, prefix in [("Page 1 Generation and Fuel Data", False, "Netgen"),
                                           ("Page 4 Generator Data", True, "Net Generation")]:
            header, iterator = xlsx_records(book[sheet].iter_rows(values_only=True))
            count = 0
            plants, frequencies = set(), Counter()
            for line, row in iterator:
                plant = identifier(row.get("Plant Id"))
                if not plant or numeric(plant) is None:
                    continue
                count += 1
                plants.add(plant)
                freq = identifier(row.get("Respondent Frequency"))
                frequencies[freq] += 1
                available = record_months(row, year, prefix)
                ba = identifier(row.get("Balancing Authority Code"))
                state = identifier(row.get("Plant State"))
                if unit_level:
                    key = (plant, identifier(row.get("Generator Id")))
                    if key not in cohort:
                        continue
                    token = (year, *key)
                    if token in unit_years:
                        unit_years[token]["duplicate"] = True
                        unit_years[token]["available"] = set()
                        continue
                    unit_years[token] = {"available": available, "frequency": freq,
                                         "ba": ba, "state": state, "duplicate": False,
                                         "source": source["local_path"], "member": member, "sheet": sheet, "row": line,
                                         "release_status": source["release_status"]}
                else:
                    token = (year, plant)
                    if token not in plant_years:
                        plant_years[token] = {"available": available, "frequencies": {freq},
                                             "bas": {ba}, "states": {state}, "rows": 1,
                                             "source": source["local_path"], "member": member,
                                             "first_row": line, "release_status": source["release_status"]}
                    else:
                        item = plant_years[token]
                        item["available"] &= available
                        item["frequencies"].add(freq)
                        item["bas"].add(ba)
                        item["states"].add(state)
                        item["rows"] += 1
            audits.append({"path": source["local_path"], "member": member, "sheet": sheet,
                           "header_row": header, "year": year, "rows": count, "plants": len(plants),
                           "non_cohort_plants": len(plants - target_plants),
                           "respondent_frequencies": dict(frequencies), "release_status": source["release_status"]})
            print(f"EIA-923 {year} {sheet}: {count} rows checked", flush=True)
        book.close()
    return unit_years, plant_years, audits


def scan_grid():
    result = []
    for path in sorted((ROOT / "data/raw/eia_grid_monitor").glob("*.json")):
        data = read_json(path).get("response", {}).get("data", [])
        months = sorted({str(r.get("period", ""))[:7] for r in data if r.get("period")})
        result.append({"path": path.relative_to(ROOT).as_posix(), "rows": len(data), "months": months,
                       "respondents": sorted({str(r.get("respondent", "")) for r in data}),
                       "types": sorted({str(r.get("type", "")) for r in data}),
                       "fueltypes": sorted({str(r.get("fueltype", "")) for r in data}),
                       "fields": sorted(set().union(*(set(r) for r in data))) if data else []})
    return result


def build():
    protected = check_inputs()
    contract = read_json(ROOT / RAW / "contract.json")
    cohort = cohort_index(rows(ROOT / contract["pool"]))
    linked = cohort_index(rows(ROOT / contract["identity"]))
    completion = cohort_index(rows(ROOT / contract["completion"]))
    if len(cohort) != contract["expected_pool_size"] or set(cohort) != set(linked) or set(cohort) != set(completion):
        raise ValueError("Canonical pool or joins changed")
    sources = rows(ROOT / contract["source_manifest"])
    daily_complete, daily_present, epa_audit = scan_epa(sources, linked)
    unit_years, plant_years, eia_audit = scan_eia923(sources, cohort)
    by_unit = defaultdict(list)
    for (year, plant, unit), record in unit_years.items():
        by_unit[(plant, unit)].append((year, record))
    donor_months = defaultdict(set)
    target_plants = {key[0] for key in cohort}
    for (year, plant), record in plant_years.items():
        if plant in target_plants or record["frequencies"] != {"M"} or len(record["bas"]) != 1 or not next(iter(record["bas"])):
            continue
        ba = next(iter(record["bas"]))
        for month in record["available"]:
            donor_months[(ba, month)].add(plant)
    events = []
    for key, row in sorted(cohort.items()):
        pairs = parse_monitor_pairs(linked[key]["camd_monitor_pairs"])
        exclusive = linked[key]["epa_attribution_status"] == "exclusive_monitor"
        epa_any = target_day_months(pairs, daily_present) if exclusive else set()
        epa_full = target_day_months(pairs, daily_complete) if exclusive else set()
        eia_any, eia_monthly, eia_final = set(), set(), set()
        unit_sources = []
        for year, record in by_unit[key]:
            eia_any |= record["available"]
            if record["frequency"] == "M":
                eia_monthly |= record["available"]
                if record["release_status"] == "final":
                    eia_final |= record["available"]
            unit_sources.append({k: v for k, v in record.items() if k != "available"} | {"year": year, "numeric_months": sorted(record["available"])})
        anchors = {}
        for field in contract["anchors"]:
            anchor = row[field]
            before, after = month_window(anchor)
            ba = ""
            if anchor:
                record = unit_years.get((int(anchor[:4]), *key))
                plant_record = plant_years.get((int(anchor[:4]), key[0]))
                if record and not record["duplicate"]:
                    ba = record["ba"]
                elif plant_record and len(plant_record["bas"]) == 1:
                    ba = next(iter(plant_record["bas"]))
            donors = set.intersection(*(donor_months.get((ba, m), set()) for m in before + after)) if ba and before else set()
            anchors[field] = {
                "date": anchor or None, "precision": "month" if anchor else None,
                "epa_any_records": paired_month_counts(anchor, epa_any),
                "epa_every_day_numeric": paired_month_counts(anchor, epa_full),
                "eia923_unit_numeric": paired_month_counts(anchor, eia_any),
                "eia923_unit_monthly_M": paired_month_counts(anchor, eia_monthly),
                "eia923_unit_monthly_M_final": paired_month_counts(anchor, eia_final),
                "annual_reported_ba_at_anchor": ba or None,
                "noncohort_same_ba_24_month_record_candidates": len(donors),
                "comparison_status": "not_validated_as_untreated_or_unexposed",
                "effect_status": effect_interpretation(False, None, None),
            }
        events.append({"eia_plant_id": key[0], "eia_generator_id": key[1], "plant_name": row["plant_name"],
                       "state": row["plant_state"], "cohort_reported_ba": row["balancing_authority_code"],
                       "timing_status": row["timing_status"], "epa_link_status": linked[key]["epa_link_status"],
                       "epa_attribution_status": linked[key]["epa_attribution_status"],
                       "completion_date_basis": completion[key]["completion_date_basis"],
                       "system_completion_state": completion[key]["system_completion_state"],
                       "physical_event_verification_status": "not_established_by_this_coverage_scan",
                       "eia923_unit_sources": unit_sources, "anchors": anchors})
    summary = {"cohort_generators": len(events), "plants": len(target_plants), "anchors": {},
               "epa_source_files": len(epa_audit["files"]), "epa_rows_scanned": sum(r["rows"] for r in epa_audit["files"]),
               "eia923_archives": len(eia_audit) // 2, "protected_inputs": protected,
               "epa_link_status": dict(Counter(e["epa_link_status"] for e in events)),
               "completion_date_basis": dict(Counter(e["completion_date_basis"] for e in events)),
               "effect_status": "not_estimated", "identification_status": "requires_design_evidence_not_measured_by_coverage",
               "generators_with_any_eia923_unit_record": sum(bool(e["eia923_unit_sources"]) for e in events),
               "duplicate_eia923_target_generator_years": sum(s["duplicate"] for e in events for s in e["eia923_unit_sources"])}
    metrics = ["epa_any_records", "epa_every_day_numeric", "eia923_unit_numeric", "eia923_unit_monthly_M", "eia923_unit_monthly_M_final"]
    for field in contract["anchors"]:
        subset = [e for e in events if e["anchors"][field]["date"]]
        summary["anchors"][field] = {"dated_generators": len(subset), "dated_plant_months": len({(e["eia_plant_id"], e["anchors"][field]["date"][:7]) for e in subset}),
            **{name + "_two_sided": sum(e["anchors"][field][name]["two_sided_24_months"] for e in subset) for name in metrics},
            **{name + "_before12": sum(e["anchors"][field][name]["before"] == 12 for e in subset) for name in metrics},
            **{name + "_after12": sum(e["anchors"][field][name]["after"] == 12 for e in subset) for name in metrics},
            "with_at_least_one_record_candidate": sum(e["anchors"][field]["noncohort_same_ba_24_month_record_candidates"] > 0 for e in subset),
            "ba_at_anchor_recovered": sum(bool(e["anchors"][field]["annual_reported_ba_at_anchor"]) for e in subset),
            "comparisons_validated_by_this_scan": 0}
    write_json(ROOT / OUT / "candidate_coverage.json", events)
    write_json(ROOT / OUT / "epa_coverage.json", epa_audit)
    write_json(ROOT / OUT / "eia923_coverage.json", eia_audit)
    write_json(ROOT / OUT / "grid_archive_coverage.json", scan_grid())
    write_json(ROOT / OUT / "coverage_summary.json", summary)
    assert check_inputs() == protected
    print(json.dumps(summary, sort_keys=True), flush=True)


def validate_outputs():
    c = read_json(ROOT / RAW / "contract.json")
    events = read_json(ROOT / OUT / "candidate_coverage.json")
    if set(cohort_index(events)) != set(cohort_index(rows(ROOT / c["pool"]))):
        raise ValueError("Candidate denominator mismatch")
    summary = read_json(ROOT / OUT / "coverage_summary.json")
    for field in c["anchors"]:
        selected = [e for e in events if e["anchors"][field]["date"]]
        if len(selected) != summary["anchors"][field]["dated_generators"]:
            raise ValueError("Independent anchor count mismatch")
        for name in ["epa_any_records", "epa_every_day_numeric", "eia923_unit_numeric", "eia923_unit_monthly_M", "eia923_unit_monthly_M_final"]:
            count = sum(e["anchors"][field][name]["before"] == 12 and e["anchors"][field][name]["after"] == 12 for e in selected)
            if count != summary["anchors"][field][name + "_two_sided"]:
                raise ValueError("Independent month-count reconciliation failed")
    for e in events:
        if e["physical_event_verification_status"] != "not_established_by_this_coverage_scan" or any(a["effect_status"] != "unresolved" for a in e["anchors"].values()):
            raise ValueError("Coverage promoted to physical or effect identification")
    return {"candidate_count": len(events), "coverage_counts_reconciled": True, "effects_estimated": 0}


def spotcheck_sources():
    import openpyxl
    events = read_json(ROOT / OUT / "candidate_coverage.json")
    checks = []
    for year in (2019, 2022, 2025):
        candidates = [(e, s) for e in events for s in e["eia923_unit_sources"] if s["year"] == year]
        selected = [candidates[i] for i in sorted({0, len(candidates) // 2, len(candidates) - 1})]
        with zipfile.ZipFile(ROOT / selected[0][1]["source"]) as archive:
            book = openpyxl.load_workbook(io.BytesIO(archive.read(selected[0][1]["member"])), read_only=True, data_only=True)
        sheet = book["Page 4 Generator Data"]
        header = next(v for v in sheet.iter_rows(min_row=1, max_row=15, values_only=True) if "Plant Id" in v)
        names = [" ".join(str(v).split()) if v is not None else "" for v in header]
        for event, stored in selected:
            values = next(sheet.iter_rows(min_row=stored["row"], max_row=stored["row"], values_only=True))
            source = dict(zip(names, values))
            if str(int(source["Plant Id"])) != event["eia_plant_id"] or str(source["Generator Id"]).strip() != event["eia_generator_id"]:
                raise ValueError("Raw-source row identity mismatch")
            months = []
            for month in range(1, 13):
                cell = source.get("Net Generation " + calendar.month_name[month])
                try:
                    valid = not isinstance(cell, bool) and math.isfinite(float(cell))
                except (TypeError, ValueError):
                    valid = False
                if valid:
                    months.append(f"{year}-{month:02}")
            if not stored["duplicate"] and months != stored["numeric_months"]:
                raise ValueError("Raw-source monthly presence mismatch")
            if str(source["Respondent Frequency"]).strip() != stored["frequency"]:
                raise ValueError("Raw-source frequency mismatch")
            checks.append({"path": stored["source"], "member": stored["member"], "sheet": stored["sheet"],
                           "row": stored["row"], "plant_id": event["eia_plant_id"], "generator_id": event["eia_generator_id"],
                           "identity_frequency_and_month_presence_match": True})
        book.close()
    write_json(ROOT / OUT / "raw_source_spotchecks.json", {"selection": "first, middle and last existing target-unit record in fixed years 2019, 2022, 2025", "checks": checks})
    print(json.dumps({"raw_source_spotchecks": len(checks)}), flush=True)


def report():
    validate_outputs()
    summary = read_json(ROOT / OUT / "coverage_summary.json")
    review = read_json(ROOT / RAW / "literature_and_identification.json")
    grid = read_json(ROOT / OUT / "grid_archive_coverage.json")
    actual = summary["anchors"]["actual_retirement_date"]
    planned = summary["anchors"]["initial_planned_retirement_date"]
    assessment = {"scientific_decision": review["identification_review"]["decision"],
                  "decision_basis": "qualitative identification and nearest-work review; not a threshold on record completeness",
                  "scope": review["identification_review"]["decision_scope"],
                  "observation": summary, "identification_review": review["identification_review"],
                  "no_effects_estimated": True, "no_automatic_next_phase": True}
    write_json(ROOT / OUT / "assessment.json", assessment)
    text = f"""# Can the existing archive identify the consequences of retirement delays?

## Conclusion

The archive can support further reconstruction of operation around retirement.
It does not yet establish the causal operational consequences of deviation from
an announced date. Do not start a whole-cohort effect model or revise the paper
on this basis. This is not a finding that effects are small or data unavailable.

The central distinction is between the effect of actual shutdown and the effect
of deviating from an announced date. The latter needs a feasible on-time alternative
and evidence separating delay from changes in demand, prices, policy and supply.
This requirement follows from the proposed causal claim, not from a rule that
every Analysis or useful descriptive study must estimate a causal effect.

## What was checked

All {summary['cohort_generators']} existing generators at {summary['plants']} plants
were retained. The checker read {summary['epa_source_files']} frozen EPA daily files
({summary['epa_rows_scanned']:,} rows) and plant- and generator-level sheets from
{summary['eia923_archives']} EIA-923 archives covering 2019-2025. It inspected identifiers,
dates, report frequency and numeric-cell availability, not outcome differences.

- {actual['dated_generators']} generators have reported retirement dates, representing
  {actual['dated_plant_months']} distinct plant-months. Those are inventory months,
  not independently verified physical shutdown days or independent experiments.
- {summary['generators_with_any_eia923_unit_record']} generators have at least one
  exact generator-level EIA-923 match. {summary['duplicate_eia923_target_generator_years']}
  duplicate generator-years are retained as ambiguous and not used as complete records.
- Among the {actual['dated_generators']} dated generators,
  {actual['eia923_unit_monthly_M_before12']} have numeric M-frequency generation in
  all twelve preceding months. {actual['eia923_unit_monthly_M_two_sided']} have the
  same coverage on both sides of reported retirement.
- Around initial plan dates, {planned['eia923_unit_monthly_M_two_sided']} generators
  have two-sided monthly M-frequency coverage; {planned['eia923_unit_monthly_M_final_two_sided']}
  retain that coverage using final releases only. The 2025 archive remains provisional.
- For {actual['with_at_least_one_record_candidate']} dated generators, at least one
  non-cohort plant in the same annual reported BA has the required 24 monthly records.
  These are possible response-series records, not validated untreated controls.

The generator-level worksheet is an existing data resource beyond the earlier
plant-year reconciliation. EPA state files also include non-target units. These
facts improve observation feasibility, not causal identification.

## Why completeness cannot decide the study

Requiring continued reports after retirement may exclude precisely the units
that physically cease operation. Both-sided reporting is therefore diagnostic,
not an admission rule. Missing reports are not automatically zero; independent
cessation evidence would be needed to distinguish structural exit from missingness.
The strict every-calendar-day EPA check admits no complete two-sided year. This
does not invalidate CEMS or establish the absence of operation: its no-imputation
criterion is stricter than mere record presence and was never the scientific gate.

The existing EIA grid-monitor folder has {len(grid)} files for ERCO/PJM, concentrated
in February 2021 and June-September 2024/2025. Earlier CAISO and stress-event
archives are additional bounded context, not a reconciled whole-cohort regional
panel. National EIA-923 plant data are useful, but do not alone establish complete
regional direct emissions, demand, interchange or an unexposed comparison.

## What is still missing

Same-BA plants may receive the displaced generation and thus cannot automatically
serve as controls. A BA label also does not isolate neighboring emissions or power
flows. Reported-date differences may be endogenous to the conditions that shape
operation. None of these problems is resolved by a larger sample or better date
prediction. The current review has not established one common documented timing
intervention with feasible alternatives and a credible comparison across this pool.

Closure-induced redispatch and network costs are already studied by
[Davis and Hausman](https://www.aeaweb.org/articles?id=10.1257/app.20140473).
Heterogeneity related to cleaner supply and electricity trade also appears in
[recent coal-closure research](https://doi.org/10.1016/j.jeem.2026.103302).
Generic substitution or heterogeneity is therefore not a demonstrated new claim.
This targeted comparison is not an exhaustive novelty review.

The next substantive requirement is a clearly defined intervention and comparison,
not another model. No subsequent experiment is authorized by this report.

## Reproduction

From the project root, run `python scripts/run_phase43_feasibility.py build`,
then the same script with `spotcheck_sources`, `report` and `verify`.
The coverage run used bundled Python 3.12.14 and openpyxl 3.1.5; regression used
the existing project Python 3.12.4 environment. No dependency was installed.
The source/output manifests,
candidate records and nearest-work assessment remain in the Phase 43 directories.
The design rationale is in `docs/phase43_research_design.md`. Manuscripts, SI,
public files and previous scientific conclusions are unchanged.
"""
    (ROOT / "outputs/phase43_feasibility_report.md").write_text(text, encoding="utf-8")
    print(json.dumps({"decision": assessment["scientific_decision"], "report": "outputs/phase43_feasibility_report.md"}))


def freeze():
    validate_outputs()
    check_inputs()
    paths = [ROOT / RAW / "contract.json", ROOT / RAW / "input_lock.json",
             Path(__file__), ROOT / "tests/test_phase43_feasibility.py"]
    paths += sorted((ROOT / OUT).glob("*.json"))
    paths += [p for p in [ROOT / RAW / "literature_and_identification.json", ROOT / "docs/phase43_research_design.md", ROOT / "outputs/phase43_feasibility_report.md"] if p.exists()]
    manifest = [{"path": p.relative_to(ROOT).as_posix(), "bytes": p.stat().st_size, "sha256": sha(p)} for p in paths]
    write_json(ROOT / RAW / "artifact_manifest.json", manifest)
    print(json.dumps({"frozen_artifacts": len(manifest)}))


def verify():
    inputs = check_inputs()
    manifest = read_json(ROOT / RAW / "artifact_manifest.json")
    for row in manifest:
        path = ROOT / row["path"]
        if sha(path) != row["sha256"] or path.stat().st_size != row["bytes"]:
            raise ValueError(f"Frozen artifact mismatch: {row['path']}")
    print(json.dumps({"protected_inputs": inputs, "frozen_artifacts": len(manifest), **validate_outputs()}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["prepare", "build", "spotcheck_sources", "report", "freeze", "verify"])
    globals()[parser.parse_args().mode]()
