"""Offline fixed-action information comparison, with frozen existing inputs."""
import argparse
import csv
import hashlib
import itertools
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
RAW = ROOT / 'data/raw/phase89'
OUT = ROOT / 'data/processed/phase89'
PRODUCTS = ['comparisons.json', 'comparisons.csv', 'summary.json', 'small_enumeration.json']


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2) + '\n', encoding='utf-8')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def freeze():
    if (RAW / 'inputs.json').exists():
        raise ValueError('Phase89 inputs already frozen')
    files = set(read(ROOT / 'outputs/phase88/protected_inputs.json')['files'])
    for folder in ['manuscript/omega_v6', 'delivery/omega_v6_author_review_20261010',
                   'outputs/phase88']:
        files.update(p.relative_to(ROOT).as_posix() for p in (ROOT / folder).rglob('*')
                     if p.is_file())
    files.update(['data/raw/phase89/contract.json', 'tests/fixtures/phase89_information.json',
                  'transition_assets/phase87_review.py'])
    write(RAW / 'inputs.json', {'files': {p: digest(ROOT / p) for p in sorted(files)}})
    print('Frozen predecessor/specification files:', len(files), flush=True)


def preserved():
    files = read(RAW / 'inputs.json')['files']
    for name, expected in files.items():
        if digest(ROOT / name) != expected:
            raise ValueError('Frozen input changed: ' + name)
    return len(files)


def feasible(k, budget):
    return [np.array(s) for s in itertools.product([0, 1], repeat=len(k))
            if np.dot(k, s) <= budget+1e-10]


def direct_regret(lo, hi, w, x, s, actions):
    l = np.where(s, w, lo); u = np.where(s, w, hi)
    return max(float(sum(u[i] if z[i]-x[i] == 1 else -l[i]
                         if z[i]-x[i] == -1 else 0. for i in range(len(x))))
               for z in actions)


def small_enumeration(contract):
    from transition_assets.phase89_information import minimum_records
    rng = np.random.default_rng(contract['seed']); results = []; checks = 0
    for case_id in range(contract['small_cases']):
        n = contract['small_n']; k = rng.integers(1, 5, n)
        lo = rng.integers(-5, 3, n).astype(float); hi = lo+rng.integers(0, 9, n)
        w = np.array([rng.integers(int(l), int(u)+1) for l, u in zip(lo, hi)])
        budget = int(rng.integers(0, int(k.sum())+1)); actions = feasible(k, budget)
        x = max(actions, key=lambda z: (float(w@z), -float(k@z)))
        epsilon = float(rng.integers(0, 3)); querysets = list(itertools.product([0, 1], repeat=n))
        for full in [False, True]:
            best = n+1
            for bits in querysets:
                s = np.array(bits)
                if full and np.any((x == 1) & (hi > lo) & (s == 0)): continue
                regret = direct_regret(lo, hi, w, x, s, actions)
                checks += len(actions)
                if regret <= epsilon+1e-9: best = min(best, int(s.sum()))
            ans = minimum_records(lo, hi, w, k, budget, x, epsilon=epsilon,
                                  value_complete=full)
            if ans['status'] != 'optimal' or ans['query_count'] != best:
                raise ValueError('Independent enumeration disagrees with minimum records')
            results.append(dict(case=case_id, task='value_complete' if full else 'action_only',
                                minimum_records=best, cuts=len(ans['cuts'])))
    return dict(status='pass', seed=contract['seed'], problems=contract['small_cases'],
                task_problems=len(results), checks=checks, results=results)


def source_cases():
    from scripts.run_phase87_review import bounds
    contract = read(RAW / 'contract.json')
    annual = read(ROOT / contract['annual_input']); paths = read(ROOT / contract['paths_input'])
    selected = {tuple(p[k] for k in ['year', 'mu', 'q', 'fraction']): p
                for p in paths if p['policy'] == 'exchange_width'}
    if len(annual) != contract['expected_settings'] or len(selected) != len(annual):
        raise ValueError('Incomplete frozen annual/path input')
    for case in annual:
        path = selected[tuple(case[k] for k in ['year', 'mu', 'q', 'fraction'])]
        lo, hi = bounds(case)
        yield case, path, lo, hi


def run():
    from transition_assets.phase89_information import minimum_records
    protected = preserved(); c = read(RAW / 'contract.json')
    small = small_enumeration(c); write(OUT / 'small_enumeration.json', small)
    comparisons = []; rows = []
    for count, (case, path, lo, hi) in enumerate(source_cases(), 1):
        w = np.array(case['forecast_values_mt'][c['answer_rule_index']])
        x = np.array(path['states'][-1]['x']); k = np.array(case['capacities'])
        common = dict(lower=lo, upper=hi, target=w, capacities=k,
                      budget=case['limit_mw'], x=x, epsilon=c['epsilon_mt'],
                      max_iterations=c['max_iterations'], time_limit=c['case_time_limit_seconds'],
                      acceptance=c['comparison_tolerance_mt'], feasible_queries=path['queried_indices'])
        action = minimum_records(**common)
        required_value = set(np.flatnonzero((x == 1) & (hi > lo)).tolist())
        if required_value <= set(action['queried_indices']):
            value = dict(action, value_complete=True,
                         mandatory_indices=sorted(set(action['mandatory_indices']) | required_value))
        else:
            value_args = dict(common, feasible_queries=sorted(set(path['queried_indices']) | required_value))
            value = minimum_records(**value_args, value_complete=True)
        record = {v: case[v] for v in ['year', 'mu', 'q', 'fraction', 'n', 'keys']}
        record.update(x=x.tolist(), adaptive_queries=path['queries_to_stop'],
                      adaptive_indices=path['queried_indices'], selected_count=int(x.sum()),
                      action_only=action, value_complete=value,
                      maximum_endpoint_roundoff_mt=float(np.max(abs(w-np.clip(w, lo, hi)))))
        comparisons.append(record)
        row = {v: record[v] for v in ['year', 'mu', 'q', 'fraction', 'n', 'selected_count', 'adaptive_queries']}
        row.update(minimum_action_records=action['query_count'], action_lower_bound=action['lower_bound'],
                   action_status=action['status'], minimum_value_records=value['query_count'],
                   value_lower_bound=value['lower_bound'], value_status=value['status'],
                   action_cuts=len(action['cuts']), value_cuts=len(value['cuts']))
        rows.append(row)
        print(f"{count}/108: action {action['query_count']} ({action['status']}), "
              f"value {value['query_count']} ({value['status']}), "
              f"adaptive {path['queries_to_stop']}", flush=True)
    exact = [r for r in rows if r['action_status'] == r['value_status'] == 'optimal']
    summary = dict(settings=len(rows), exact_settings=len(exact), protected_files=protected,
        mean_action_upper_share=float(np.mean([r['minimum_action_records']/r['n'] for r in rows])),
        mean_action_lower_share=float(np.mean([r['action_lower_bound']/r['n'] for r in rows])),
        mean_value_upper_share=float(np.mean([r['minimum_value_records']/r['n'] for r in rows])),
        mean_value_lower_share=float(np.mean([r['value_lower_bound']/r['n'] for r in rows])),
        mean_adaptive_share=float(np.mean([r['adaptive_queries']/r['n'] for r in rows])),
        adaptive_equals_minimum=sum(r['adaptive_queries'] == r['minimum_action_records'] for r in exact),
        adaptive_excess_mean=float(np.mean([r['adaptive_queries']-r['minimum_action_records'] for r in exact]))
            if exact else None,
        action_value_gap_settings=sum(r['minimum_value_records'] > r['minimum_action_records'] for r in exact),
        action_value_gap_max=max(r['minimum_value_records']-r['minimum_action_records'] for r in exact)
            if exact else None,
        zero_query_settings=sum(r['minimum_action_records'] == 0 for r in exact),
        maximum_action_cuts=max(r['action_cuts'] for r in rows),
        maximum_endpoint_roundoff_mt=max(r['maximum_endpoint_roundoff_mt'] for r in comparisons),
        by_cost=[], interpretation=c['interpretation'])
    for cost in sorted({r['q'] for r in rows}):
        group = [r for r in rows if r['q'] == cost]
        summary['by_cost'].append(dict(q=cost, settings=len(group),
            mean_action_share=float(np.mean([r['minimum_action_records']/r['n'] for r in group])),
            mean_value_share=float(np.mean([r['minimum_value_records']/r['n'] for r in group])),
            mean_selected_share=float(np.mean([r['selected_count']/r['n'] for r in group])),
            gap_settings=sum(r['minimum_value_records'] > r['minimum_action_records'] for r in group)))
    write(OUT / 'comparisons.json', comparisons); write(OUT / 'summary.json', summary)
    with (OUT / 'comparisons.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    preserved()
    print('Independent small enumeration:', small['checks'], 'checks', flush=True)
    print(json.dumps(summary, indent=2), flush=True)


def verify():
    from scipy.optimize import Bounds, LinearConstraint, milp
    from transition_assets.phase87_review import interval_regret
    c = read(RAW / 'contract.json'); protected = preserved()
    records = read(OUT / 'comparisons.json'); checks = 0; max_regret = 0.
    if len(records) != c['expected_settings']: raise ValueError('Incomplete annual output')
    for record, (case, path, lo, hi) in zip(records, source_cases()):
        for key in ['year', 'mu', 'q', 'fraction', 'n', 'keys']:
            if record[key] != case[key]: raise ValueError('Annual identity mismatch')
        x = np.array(path['states'][-1]['x']); k = np.array(case['capacities'])
        w = np.clip(np.array(case['forecast_values_mt'][3]), lo, hi)
        if record['x'] != x.tolist(): raise ValueError('Fixed portfolio differs from inherited output')
        for task in ['action_only', 'value_complete']:
            ans = record[task]; s = np.zeros(len(k), dtype=int); s[ans['queried_indices']] = 1
            if s.sum() != ans['query_count']: raise ValueError('Duplicate or mismatched queries')
            l = np.where(s, w, lo); u = np.where(s, w, hi)
            sep = interval_regret(l, u, k, case['limit_mw'], x)
            if sep['upper'] > c['epsilon_mt']+c['comparison_tolerance_mt']:
                raise ValueError('Record set does not verify the fixed portfolio')
            max_regret = max(max_regret, sep['upper']); checks += 3
            low = ((x == 1) & (lo < -c['epsilon_mt']) & (hi > lo)).astype(float)
            if task == 'value_complete':
                low = ((x == 1) & (hi > lo)).astype(float)
            high = ((hi > lo) & (k <= case['limit_mw']+1e-6)).astype(float)
            if np.any(s < low) or np.any(s > high): raise ValueError('Invalid necessary query or screening')
            matrix = []; rhs = []
            for cut in ans['cuts']:
                z = np.array(cut['witness'])
                if k@z > case['limit_mw']+1e-6: raise ValueError('Infeasible exchange cut')
                a = float(sum(hi[i] if z[i]-x[i] == 1 else -lo[i]
                              if z[i]-x[i] == -1 else 0. for i in range(len(k))))
                g = np.array([(hi[i]-w[i]) if x[i] == 0 and z[i] == 1 else
                              (w[i]-lo[i]) if x[i] == 1 and z[i] == 0 else 0.
                              for i in range(len(k))])
                np.testing.assert_allclose(a, cut['contrast'], atol=1e-10)
                np.testing.assert_allclose(g, cut['reduction'], atol=1e-10)
                if a-g@s > c['epsilon_mt']+1e-8: raise ValueError('Returned query set violates stored cut')
                matrix.append(g); rhs.append(a-c['epsilon_mt']); checks += 4
            constraints = None if not matrix else LinearConstraint(np.array(matrix), np.array(rhs), np.inf)
            master = milp(np.ones(len(k)), integrality=np.ones(len(k)),
                bounds=Bounds(low, high), constraints=constraints,
                options=dict(mip_rel_gap=0., time_limit=30.))
            if not master.success: raise ValueError('Independent master lower-bound solve failed')
            if ans['status'] == 'optimal' and abs(master.fun-s.sum()) > 1e-6:
                raise ValueError('Independent master optimum differs from feasible query count')
            checks += 2
        if record['action_only']['query_count'] > path['queries_to_stop']:
            raise ValueError('Offline minimum exceeds a known feasible adaptive query set')
        if case['q'] > 0 and record['action_only']['query_count'] != record['value_complete']['query_count']:
            raise ValueError('Positive-cost deletion necessity disagrees with task equality')
        if case['q'] > 0 and np.any((x == 1) & (hi > lo) & (lo >= -c['epsilon_mt'])):
            raise ValueError('Positive-cost case does not satisfy the stated necessary-query condition')
        checks += 2
    small = small_enumeration(c)
    if small != read(OUT / 'small_enumeration.json'):
        raise ValueError('Independent enumeration changed')
    result = dict(status='pass', annual_checks=checks, small_enumeration_checks=small['checks'],
                  protected_files=protected, maximum_verified_regret_mt=max_regret)
    write(OUT / 'verification.json', result); print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['freeze', 'run', 'verify', 'reproduce'], required=True)
    mode = parser.parse_args().mode
    if mode == 'freeze': freeze()
    elif mode == 'run': run()
    elif mode == 'verify': verify()
    else:
        before = {p: digest(OUT / p) for p in PRODUCTS}; run()
        after = {p: digest(OUT / p) for p in PRODUCTS}
        if before != after: raise ValueError('Scientific products differ on repeat')
        write(OUT / 'reproduction.json', dict(status='pass', sha256=after))
