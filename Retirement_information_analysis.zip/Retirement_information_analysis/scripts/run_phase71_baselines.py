"""Calendar-ordered retirement baselines; not vintage-correct policy effects."""
import argparse
import calendar
from collections import Counter, defaultdict
import csv
from datetime import date, timedelta
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.run_phase68_horizons import checkpoint_state, recorded_event

RAW = ROOT/'data/raw/phase71'
OUT = ROOT/'data/processed/phase71'
RULES = ['initial_older','updated_older','initial_recent','updated_recent','persistence']


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def write(p, value):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def freeze():
    c=read(RAW/'contract.json')
    names={c[k] for k in ['cohort','history','generation','monitor_months','monitor_identity']}
    names.add('data/raw/phase71/contract.json')
    names.add('scripts/run_phase68_horizons.py')
    names.update(r['path'] for r in read(ROOT/'data/raw/phase70/inputs.json'))
    for r in read(ROOT/c['monitor_months']):names.update(r['sources'])
    for folder in ['manuscript/ere_v3','author_review_ere_v3_2026-09-28','data/processed/phase70']:
        names.update(p.relative_to(ROOT).as_posix() for p in (ROOT/folder).rglob('*')
                     if p.is_file() and '__pycache__' not in p.parts)
    rows=[dict(path=p,sha256=sha(ROOT/p)) for p in sorted(names)]
    target=RAW/'inputs.json'
    if target.exists() and read(target)!=rows:raise ValueError('Frozen inputs changed')
    write(target,rows)
    print('Frozen inputs:',len(rows),flush=True)


def check_lock():
    rows=read(RAW/'inputs.json')
    for r in rows:
        if sha(ROOT/r['path'])!=r['sha256']:raise ValueError('Changed input: '+r['path'])
    return len(rows)


def year_hours(y):
    return 24*(366 if calendar.isleap(y) else 365)


def generation_rate(r):
    if r is None:return None,'no_generator_year'
    if r['duplicate']:return None,'duplicate'
    if r['frequency']!='M':return None,'not_monthly_frequency'
    v=r['values']
    if len(v)!=12 or any(x is None or not math.isfinite(x) for x in v):
        return None,'incomplete_months'
    return math.fsum(v)/year_hours(r['year']),'complete'


def exposure_hours(y,plan,include_month=True):
    if not plan:raise ValueError('No date cannot imply full exposure')
    d=date.fromisoformat(plan)
    if d.day!=calendar.monthrange(d.year,d.month)[1]:raise ValueError('Not month-end')
    start,end=date(y+1,1,1),date(y+2,1,1)
    stop=d+timedelta(days=1) if include_month else d.replace(day=1)
    return max(0,(min(end,stop)-start).days)*24


def baseline_values(r0,r1,h0,h1,full):
    return dict(initial_older=r0*h0,updated_older=r0*h1,
                initial_recent=r1*h0,updated_recent=r1*h1,persistence=r1*full)


def decompose(r0,r1,h0,h1):
    return dict(date=.5*(r0+r1)*(h1-h0),operation=.5*(h0+h1)*(r1-r0))


def top_weights(scores,k):
    if k<1 or k>len(scores):raise ValueError('Invalid selection size')
    threshold=sorted(scores,reverse=True)[k-1]
    above=sum(v>threshold for v in scores); tied=sum(v==threshold for v in scores)
    return [1. if v>threshold else (k-above)/tied if v==threshold else 0. for v in scores]


def rank_comparison(scores,actual,k):
    w=top_weights(scores,k); best=top_weights(actual,k)
    captured=math.fsum(a*b for a,b in zip(w,actual))
    oracle=math.fsum(a*b for a,b in zip(best,actual))
    rho=float(spearmanr(scores,actual).statistic) if len(set(scores))>1 and len(set(actual))>1 else None
    return dict(captured=captured,hindsight_best=oracle,shortfall=oracle-captured,
                capture_ratio=captured/oracle if oracle>0 else None,spearman=rho,
                weights=w)


def monitor_year(mm,pair,y,field,mode='conditional'):
    values=[]; inferred=0
    for m in range(1,13):
        r=mm.get((*pair,f'{y}-{m:02}'))
        if r is None:return None,'missing_monitor_month'
        n=calendar.monthrange(y,m)[1]
        v=r.get(mode,{}).get(field,{})
        if r['conflicting_days'] or v.get('valid_days')!=n or v.get('value') is None:
            return None,'incomplete_or_conflicting_days'
        x=v['value']
        if not math.isfinite(x) or x<0:return None,'invalid_value'
        values.append(x);inferred+=r.get('inferred_zero_cells',0)
    return math.fsum(values),dict(inferred_zero_cells_all_metrics=inferred)


def generation_index(generation):
    gm={}
    for g in generation:
        k=(g['plant']+':'+g['unit'],g['year'])
        if k in gm:raise ValueError('Duplicate generator-year key')
        gm[k]=g
    return gm


def build_panel(cohort,history,generation,origins,lag=0,include_month=True):
    hh=defaultdict(list)
    for r in history:hh[r['key']].append(r)
    snapshots=sorted({r['snapshot'] for r in history}); gm=generation_index(generation)
    panel=[]; ledger=[]
    for u in sorted(cohort,key=lambda r:(r['eia_plant_id'],r['eia_generator_id'])):
        key=u['eia_plant_id']+':'+u['eia_generator_id']
        ev=recorded_event(hh[key],'2026-06-30','2026-06-30')
        for y in origins:
            origin=f'{y}-12-31'
            if u['first_plan_snapshot_date']>origin:continue
            st=checkpoint_state(hh[key],snapshots,origin)
            if st['snapshot']!=origin or st['category'] not in {'plan_due','plan_future','plan_blank'}:continue
            row=dict(key=key,plant=u['eia_plant_id'],name=u['plant_name'],fuel=u['fuel_group'],
                     state=u['plant_state'],capacity_mw=float(u['eligibility_nameplate_capacity_mw']),
                     origin=origin,year=y,outcome_year=y+1,initial_plan=u['initial_planned_retirement_date'],
                     current_plan=st['plan_date'],plan_sources=st['source_rows'],
                     historical_event=ev['date'],event_source=ev['source_snapshot'],
                     outcome_exit=bool(ev['date'] and origin<ev['date']<=f'{y+1}-12-31'),
                     retrospectively_already_retired=bool(ev['date'] and ev['date']<=origin))
            yrs=[y-1-lag,y-lag,y+1]; vals=[generation_rate(gm.get((key,j))) for j in yrs]
            row['operating_years']=yrs[:2]
            row['coverage']={k:v[1] for k,v in zip(['older','recent','outcome'],vals)}
            status='complete'
            if not st['plan_date']:status='blank_current_plan'
            else:
                for k,v in zip(['older','recent','outcome'],vals):
                    if v[0] is None:status=k+':'+v[1];break
            row['status']=status; ledger.append(row.copy())
            if status!='complete':continue
            r0,r1,ry=[v[0] for v in vals]
            h0=exposure_hours(y,row['initial_plan'],include_month)
            h1=exposure_hours(y,row['current_plan'],include_month)
            row.update(rate0=r0,rate1=r1,hours0=h0,hours1=h1,full_hours=year_hours(y+1),
                       actual=math.fsum(gm[(key,y+1)]['values']),
                       forecasts=baseline_values(r0,r1,h0,h1,year_hours(y+1)),
                       decomposition=decompose(r0,r1,h0,h1),
                       generation_sources=[{k:gm[(key,j)].get(k) for k in
                           ['year','source','member','row','frequency','release_status']} for j in yrs])
            panel.append(row)
    return panel,ledger


def carbon_panel(panel,monitor,identities):
    mm={(*r['pair'],r['month']):r for r in monitor}
    if len(mm)!=len(monitor):raise ValueError('Duplicate monitor-month')
    identities={r['key']:r for r in identities};out=[];coverage=[]
    for r in panel:
        w=identities[r['key']]; reason='complete';strict=True;rates=[];notes=[]
        if not w['pool_eligible'] or w['identity_status']!='single_static_exclusive':reason='identity'
        else:
            pair=tuple(w['monitor_pairs'][0])
            for y in [*r['operating_years'],r['outcome_year']]:
                gross,gn=monitor_year(mm,pair,y,'gross_mwh')
                co2,cn=monitor_year(mm,pair,y,'co2_tonnes')
                strict &= all(monitor_year(mm,pair,y,f,'strict')[0] is not None
                              for f in ['gross_mwh','co2_tonnes'])
                if gross is None or co2 is None:reason='incomplete_monitor_year'
                rates.append(co2/year_hours(y) if co2 is not None else None)
                notes.append(dict(year=y,gross=gross,co2=co2,gross_coverage=gn,co2_coverage=cn))
        coverage.append(dict(key=r['key'],year=r['year'],status=reason,strict_complete=strict if reason=='complete' else False))
        if reason!='complete':continue
        r0,r1,ry=rates; q=dict(r)
        q.update(rate0=r0,rate1=r1,actual=ry*r['full_hours'],
                 forecasts=baseline_values(r0,r1,r['hours0'],r['hours1'],r['full_hours']),
                 decomposition=decompose(r0,r1,r['hours0'],r['hours1']),
                 monitor_pair=list(pair),monitor_years=notes,strict_complete=strict,
                 historical_identity_validated=w['historical_identity_validated'])
        out.append(q)
    return out,coverage


def counts(rows):
    return dict(rows=len(rows),units=len({r['key'] for r in rows}),plants=len({r['plant'] for r in rows}),
                coal_rows=sum(r['fuel']=='coal' for r in rows),
                mean_capacity_mw=math.fsum(r['capacity_mw'] for r in rows)/len(rows) if rows else None,
                outcome_exit_rows=sum(r['outcome_exit'] for r in rows))


def summarize(rows):
    result=counts(rows); result['rules']={}
    y=[r['actual'] for r in rows];den=math.fsum(abs(v) for v in y);n=len(rows)
    result['actual_total']=math.fsum(y)
    for rule in RULES:
        pred=[r['forecasts'][rule] for r in rows]
        err=[p-a for p,a in zip(pred,y)];absolute=math.fsum(map(abs,err))
        result['rules'][rule]=dict(predicted_total=math.fsum(pred),bias_total=math.fsum(err),
            mae=absolute/n if n else None,wape=absolute/den if den else None,
            mae_per_mw=math.fsum(abs(e)/r['capacity_mw'] for e,r in zip(err,rows))/n if n else None)
    d=[r['decomposition'] for r in rows]
    result['decomposition']=dict(date_total=math.fsum(v['date'] for v in d),
        operation_total=math.fsum(v['operation'] for v in d),
        date_absolute=math.fsum(abs(v['date']) for v in d),operation_absolute=math.fsum(abs(v['operation']) for v in d),
        opposing_rows=sum(v['date']*v['operation']<0 for v in d),
        zero_initial_hours=sum(r['hours0']==0 for r in rows),
        changed_dates=sum(r['hours0']!=r['hours1'] for r in rows),
        negative_actual_rows=sum(r['actual']<0 for r in rows))
    return result


def rankings(rows):
    out=[]
    for y in sorted({r['year'] for r in rows}):
        rr=[r for r in rows if r['year']==y];n=len(rr)
        if n<8:continue
        k=math.ceil(n/4)
        for scale in ['total','per_mw']:
            denom=[r['capacity_mw'] if scale=='per_mw' else 1. for r in rr]
            actual=[r['actual']/d for r,d in zip(rr,denom)]
            results={a:rank_comparison([r['forecasts'][a]/d for r,d in zip(rr,denom)],actual,k) for a in RULES}
            w0=results['initial_older']['weights'];w1=results['updated_recent']['weights']
            wp=results['persistence']['weights']
            out.append(dict(year=y,outcome_year=y+1,n=n,k=k,scale=scale,
                initial_updated_overlap=math.fsum(min(a,b) for a,b in zip(w0,w1))/k,
                persistence_updated_overlap=math.fsum(min(a,b) for a,b in zip(wp,w1))/k,
                keys=[r['key'] for r in rr],rules=results))
    return out


def comparisons(rows,repetitions,seed):
    if not rows:return {}
    plants=sorted({r['plant'] for r in rows});result={}
    rng=np.random.default_rng(seed)
    sampled=rng.integers(0,len(plants),size=(repetitions,len(plants)))
    for ref in ['initial_older','persistence']:
        # Positive differences indicate lower error for updated_recent.
        delta=[abs(r['forecasts'][ref]-r['actual'])-abs(r['forecasts']['updated_recent']-r['actual']) for r in rows]
        sums=np.array([math.fsum(d for r,d in zip(rows,delta) if r['plant']==p) for p in plants])
        ns=np.array([sum(r['plant']==p for r in rows) for p in plants])
        boot=sums[sampled].sum(axis=1)/ns[sampled].sum(axis=1)
        loo=[dict(plant=p,mae_improvement=float((math.fsum(delta)-s)/(len(rows)-n)))
             for p,s,n in zip(plants,sums,ns) if n<len(rows)]
        result[ref]=dict(mae_improvement=math.fsum(delta)/len(rows),
            cluster_bootstrap_ci95=[float(v) for v in np.quantile(boot,[.025,.975])],
            leave_one_plant_out=loo,loo_positive=sum(r['mae_improvement']>0 for r in loo),
            loo_range=[min(r['mae_improvement'] for r in loo),max(r['mae_improvement'] for r in loo)] if loo else None)
    return result


def first_rows(rows):
    out={}
    for r in sorted(rows,key=lambda r:(r['year'],r['key'])):out.setdefault(r['key'],r)
    return list(out.values())


def concentration(rows):
    pp=defaultdict(lambda:defaultdict(float))
    for r in rows:
        p=pp[r['plant']];p['actual']+=r['actual']
        for rule in RULES:p[rule]+=abs(r['forecasts'][rule]-r['actual'])
    return [dict(plant=k,**v) for k,v in sorted(pp.items(),key=lambda kv:-kv[1]['initial_older'])]


def products():
    c=read(RAW/'contract.json')
    with (ROOT/c['cohort']).open(encoding='utf-8-sig',newline='') as f:cohort=list(csv.DictReader(f))
    h=read(ROOT/c['history']);g=read(ROOT/c['generation'])
    panel,ledger=build_panel(cohort,h,g,c['origins'])
    lagged,_=build_panel(cohort,h,g,c['origins'],lag=1)
    support={(r['key'],r['year']) for r in lagged}
    lag_match=[r for r in panel if (r['key'],r['year']) in support]
    lag_support={(r['key'],r['year']) for r in lag_match}
    lagged=[r for r in lagged if (r['key'],r['year']) in lag_support]
    boundary,_=build_panel(cohort,h,g,c['origins'],include_month=False)
    carbon,cl=carbon_panel(panel,read(ROOT/c['monitor_months']),read(ROOT/c['monitor_identity']))
    selection={s:counts([r for r in ledger if r['status']==s]) for s in sorted({r['status'] for r in ledger})}
    groups={'primary':panel,'coal':[r for r in panel if r['fuel']=='coal'],
        'gas':[r for r in panel if r['fuel']=='gas'],
        'initial_plan_future':[r for r in panel if r['initial_plan']>r['origin']],
        'first_complete_origin':first_rows(panel),'final_outcomes':[r for r in panel if r['outcome_year']<2025],
        'exclude_planned_month':boundary,'lag_matched_standard':lag_match,'lag_matched_earlier':lagged,
        'carbon_nested':carbon}
    groups.update({f'origin_{y}':[r for r in panel if r['year']==y] for y in c['origins']})
    result=dict(contract_sha256=sha(RAW/'contract.json'),coverage=counts(ledger),selection=selection,
                complete=counts(panel),incomplete=counts([r for r in ledger if r['status']!='complete']),
                subsets={k:summarize(v) for k,v in groups.items()},
                paired_errors=comparisons(panel,c['bootstrap_repetitions'],c['seed']),
                carbon_paired_errors=comparisons(carbon,c['bootstrap_repetitions'],c['seed']),
                carbon_coverage=dict(Counter(r['status'] for r in cl)),
                carbon_strict_complete=sum(r['strict_complete'] for r in carbon),
                vintage_correct_real_time=False)
    return {'panel.json':panel,'coverage.json':ledger,'carbon_panel.json':carbon,
            'carbon_coverage.json':cl,'lagged_panel.json':lagged,'results.json':result,
            'rankings.json':rankings(panel),'carbon_rankings.json':rankings(carbon),
            'concentration.json':concentration(panel)}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['freeze','run','verify'],required=True)
    args=parser.parse_args()
    if args.mode=='freeze':freeze();return
    n=check_lock(); outputs=products()
    for name,v in outputs.items():
        if args.mode=='verify':
            if read(OUT/name)!=v:raise ValueError('Reproduction mismatch: '+name)
        else:write(OUT/name,v)
    print(json.dumps(dict(mode=args.mode,protected_files=n,products=len(outputs),
                          sample=outputs['results.json']['complete'])),flush=True)


if __name__=='__main__':main()
