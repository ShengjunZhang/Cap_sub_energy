"""Generate checked budget summaries and legible review figures from replay data."""
from pathlib import Path
import shutil
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from scripts.run_phase84_support import read,write,write_csv

OUT=ROOT/'outputs/phase87'; DOC=ROOT/'manuscript/phase87_note'
POLICIES=['exchange_width','interval_width','capacity','initial_disagreement','random']
LABELS=['Exchange-directed','Interval width','Capacity','Initial disagreement','Random']
COLORS=['#007C83','#4C78A8','#B25B34','#796285','#6F7378']


def main():
    c=read(ROOT/'data/raw/phase87/contract.json'); s=read(ROOT/'data/processed/phase87/summary.json')
    paths=read(ROOT/'data/processed/phase87/paths.json')
    OUT.mkdir(parents=True,exist_ok=True); DOC.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,
        'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})
    fig,axs=plt.subplots(1,2,figsize=(8.5,3.1),layout='constrained')
    source=[]
    for panel,field in enumerate(['updated_forecast_loss_mt','observed_loss_mt']):
        for policy,label,color in zip(POLICIES,LABELS,COLORS):
            group=[p for p in paths if p['policy']==policy]
            means=[]
            for f in c['budget_fractions']:
                vals=[r[field] for p in group for r in p['budgets'] if r['review_fraction']==f]
                means.append(float(np.mean(vals)))
                source.append(dict(panel=panel,metric=field,policy=policy,review_fraction=f,
                                   mean_loss_mt=means[-1],path_count=len(vals)))
            axs[panel].plot(np.array(c['budget_fractions'])*100,means,label=label,color=color,
                lw=2 if policy=='exchange_width' else 1.2,marker='o',ms=3,
                ls='--' if policy=='random' else '-')
        axs[panel].set_xlabel('Plan records allowed to be retrieved (%)')
        axs[panel].set_ylabel('Mean conditional loss (Mt)')
        axs[panel].set_title(('(a) Fully updated forecast benchmark',
                              '(b) Observed operating benchmark')[panel],loc='left',fontsize=10)
        axs[panel].set_xlim(-2,102); axs[panel].grid(axis='y',alpha=.18)
    axs[0].legend(frameon=False,fontsize=7.4,loc='upper right')
    fig.savefig(OUT/'review_budget.pdf'); fig.savefig(OUT/'review_budget.png',dpi=180); plt.close(fig)
    shutil.copy2(OUT/'review_budget.pdf',DOC/'review_budget.pdf')
    write_csv(OUT/'review_budget_source.csv',source)
    rows=[]
    for policy,label in zip(POLICIES,LABELS):
        v=s['policies'][policy]
        rows.append(f"{label} & {v['median_queries_to_stop']:.1f} & "
                    f"{100*v['mean_review_share']:.1f} & {100*v['median_review_share']:.1f}\\\\")
    (DOC/'review_rows.tex').write_text('\n'.join(rows)+'\n\\bottomrule\n',encoding='utf-8')
    macros={'ReviewSettings':str(s['settings']),'ReviewPaths':str(s['paths']),
        'ReviewActualLossCases':str(s['certificates_with_actual_loss']),
        'ReviewActualIncreaseCases':str(s['actual_loss_increases_after_a_query'])}
    for p,name in [('exchange_width','Exchange'),('random','Random'),('capacity','Capacity')]:
        v=s['policies'][p]
        macros[name+'ReviewShare']=f"{100*v['mean_review_share']:.1f}"
        macros[name+'MedianQueries']=f"{v['median_queries_to_stop']:.1f}"
        for f,suffix in [(.25,'Quarter'),(.5,'Half')]:
            v=next(a for a in s['policies'][p]['budget_means'] if a['review_fraction']==f)
            for field,t in [('updated_forecast_loss_mt','ForecastLoss'),('observed_loss_mt','ActualLoss')]:
                macros[name+suffix+t]=f"{v[field]:.3f}"
    (DOC/'review_numbers.tex').write_text(''.join('\\newcommand{\\'+k+'}{'+v+'}\n' for k,v in macros.items()),encoding='utf-8')
    write(OUT/'display_manifest.json',dict(macros=macros,stopping_rows=rows,
        source='data/processed/phase87/summary.json',figure_source='review_budget_source.csv'))
    print('Two-panel source figure; checked stopping table and',len(macros),'numbers')


if __name__=='__main__': main()
