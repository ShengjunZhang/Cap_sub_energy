"""Rebuild annual sample support from existing files; preserve predecessor products."""
import argparse
import calendar
from collections import Counter, defaultdict
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import platform
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.run_phase43_feasibility import identifier, numeric, xlsx_records
from scripts.run_phase71_baselines import (
    build_panel, carbon_panel, generation_index, generation_rate, monitor_year,
    baseline_values, decompose, exposure_hours, year_hours, summarize, counts, RULES)
from scripts.run_phase73_decisions import pair_panels
from transition_assets.phase84_support import (
    annual_support, reported_annual_support, origin_grid, stage_counts, project_margin_interval)

RAW = ROOT / 'data/raw/phase84'
OUT = ROOT / 'data/processed/phase84'
PRODUCTS = ['results.json', 'origin_ledger.csv', 'annual_validation.csv',
            'annual_net_panel.json', 'annual_carbon_panel.json', 'annual_pair_panel.json',
            'reported_annual_net_panel.json', 'reported_annual_carbon_panel.json',
            'reported_annual_pair_panel.json', 'case_alignment.json']
MODES = ['original_M', 'annual_M_AM', 'reported_annual']
STAGES = ['grid', 'eligible_origin', 'plan_supported', 'net_supported',
          'carbon_supported', 'paired_supported']


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def csv_rows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted(set().union(*(r.keys() for r in rows)))
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: json.dumps(v, sort_keys=True, allow_nan=False)
                             if isinstance(v, (dict, list)) else v for k, v in r.items()})


def freeze():
    if (RAW / 'inputs.json').exists():
        raise ValueError('Phase84 inputs already frozen')
    previous = read(ROOT / 'data/raw/phase83/inputs.json')['files']
    for p, h in previous.items():
        if digest(ROOT / p) != h:
            raise ValueError('Inherited protected file changed: ' + p)
    names = set(previous)
    for folder in ['data/raw/phase83', 'data/processed/phase83', 'outputs/phase83']:
        names.update(p.relative_to(ROOT).as_posix() for p in (ROOT / folder).rglob('*') if p.is_file())
    names.update(['outputs/phase83_report.md', 'scripts/run_phase83_action_windows.py',
                  'transition_assets/phase83_action_windows.py', 'tests/test_phase83_action_windows.py',
                  'data/raw/phase84/contract.json', 'tests/fixtures/phase84_support.json',
                  'scripts/run_phase71_baselines.py', 'scripts/run_phase73_decisions.py',
                  'scripts/run_phase43_feasibility.py'])
    contract = read(RAW / 'contract.json')
    parent = read(ROOT / contract['parent_contract'])
    names.add(contract['parent_contract'])
    names.update(contract[k] for k in ['original_net_panel', 'original_coverage', 'original_carbon_panel',
                                     'original_carbon_coverage', 'original_pair_panel',
                                     'original_pair_coverage', 'case_snapshots', 'case_results'])
    names.update(parent[k] for k in ['cohort', 'history', 'generation', 'monitor_months', 'monitor_identity'])
    names.update(r['source'] for r in read(ROOT / parent['generation']))
    write(RAW / 'inputs.json', {'files': {p: digest(ROOT / p) for p in sorted(names)}})
    print('Frozen input and predecessor files:', len(names), flush=True)


def preserved():
    files = read(RAW / 'inputs.json')['files']
    bad = [p for p, h in files.items() if not (ROOT / p).is_file() or digest(ROOT / p) != h]
    if bad:
        raise ValueError('Protected file changed: ' + str(bad[:5]))
    if (RAW / 'reported_annual_inputs.json').exists():
        supplement = read(RAW / 'reported_annual_inputs.json')
        for p, h in supplement['files'].items():
            if digest(ROOT/p) != h:
                raise ValueError('Changed supplemental contract: ' + p)
    return len(files)


def mode_digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def freeze_reported():
    if (RAW / 'reported_annual_inputs.json').exists():
        raise ValueError('Supplement already frozen')
    preserved()
    result = read(OUT / 'results.json')
    path = 'data/raw/phase84/reported_annual_contract.json'
    write(RAW / 'reported_annual_inputs.json', {
        'files': {path: digest(ROOT/path)},
        'original_sample_mode_digests': {m: mode_digest(result['sample_modes'][m]) for m in MODES[:2]}})
    print('Frozen reported-annual extension; two previous mode summaries protected', flush=True)


def validate_workbooks(generation, contract):
    import openpyxl
    grouped = defaultdict(list)
    for r in generation:
        grouped[(r['source'], r['member'], r['sheet'])].append(r)
    checks = []
    for (source, member, sheet), rows in sorted(grouped.items()):
        print('Annual reconciliation:', source, flush=True)
        by_row = {r['row']: r for r in rows}
        if len(by_row) != len(rows):
            raise ValueError('Duplicate raw row locator')
        with zipfile.ZipFile(ROOT / source) as archive:
            workbook = openpyxl.load_workbook(io.BytesIO(archive.read(member)), read_only=True, data_only=True)
            _, records = xlsx_records(workbook[sheet].iter_rows(values_only=True))
            found = set()
            for row_number, raw in records:
                if row_number > max(by_row):
                    break
                if row_number not in by_row:
                    continue
                found.add(row_number)
                r = by_row[row_number]
                values = [numeric(raw.get('Net Generation ' + name)) for name in list(calendar.month_name)[1:]]
                fields_match = (identifier(raw.get('Plant Id')) == r['plant'] and
                                identifier(raw.get('Generator Id')) == r['unit'] and
                                identifier(raw.get('YEAR')) == str(r['year']) and
                                identifier(raw.get('Respondent Frequency')) == r['frequency'])
                monthly_match = len(values) == len(r['values']) and all(
                    a == b for a, b in zip(values, r['values']))
                annual = numeric(raw.get('Net Generation Year To Date'))
                result = annual_support(r, annual, fields_match and monthly_match,
                                        contract['annual_absolute_tolerance_mwh'],
                                        contract['annual_relative_tolerance'])
                checks.append({'key': r['plant'] + ':' + r['unit'], 'year': r['year'],
                               'frequency': r['frequency'], 'source': source, 'member': member,
                               'sheet': sheet, 'row': row_number, 'fields_match': fields_match,
                               'monthly_match': monthly_match, 'reported_annual_mwh': annual,
                               **result})
            workbook.close()
        if found != set(by_row):
            raise ValueError('Missing original row locator')
    return sorted(checks, key=lambda r: (r['key'], r['year']))


def annual_panel(coverage, generation, validation, basis='raw annual total reconciled; no AM timing interpretation'):
    gm = generation_index(generation)
    vm = {(r['key'], r['year']): r for r in validation}
    panel, ledger = [], []
    for old in coverage:
        r = dict(old)
        years = [*r['operating_years'], r['outcome_year']]
        values = [vm.get((r['key'], y), {'status': 'no_generator_year', 'rate_mw': None}) for y in years]
        r['coverage'] = {k: v['status'] for k, v in zip(['older', 'recent', 'outcome'], values)}
        r['status'] = 'complete' if r['current_plan'] else 'blank_current_plan'
        if r['status'] == 'complete':
            for k, v in zip(['older', 'recent', 'outcome'], values):
                if v['status'] != 'complete':
                    r['status'] = k + ':' + v['status']; break
        ledger.append(r.copy())
        if r['status'] != 'complete':
            continue
        r0, r1, ry = [v['rate_mw'] for v in values]
        h0 = exposure_hours(r['year'], r['initial_plan'])
        h1 = exposure_hours(r['year'], r['current_plan'])
        full = year_hours(r['outcome_year'])
        r.update(rate0=r0, rate1=r1, hours0=h0, hours1=h1, full_hours=full,
                 actual=values[2]['annual_mwh'], forecasts=baseline_values(r0, r1, h0, h1, full),
                 decomposition=decompose(r0, r1, h0, h1),
                 generation_sources=[{k: gm[(r['key'], y)].get(k) for k in
                     ['year', 'source', 'member', 'row', 'frequency', 'release_status']} for y in years],
                 annual_validation=basis)
        panel.append(r)
    return panel, ledger


def monitor_diagnostic(row, monitor_index, identities):
    identity = identities[row['key']]
    if not identity['pool_eligible'] or identity['identity_status'] != 'single_static_exclusive':
        return {'identity_status': 'excluded', 'years': {}, 'all_complete': False, 'strict_complete': False}
    pair = tuple(identity['monitor_pairs'][0])
    by_year, strict = {}, True
    for label, y in zip(['older', 'recent', 'outcome'], [row['year']-1, row['year'], row['outcome_year']]):
        gross, gn = monitor_year(monitor_index, pair, y, 'gross_mwh')
        co2, cn = monitor_year(monitor_index, pair, y, 'co2_tonnes')
        valid = gross is not None and co2 is not None
        strict &= all(monitor_year(monitor_index, pair, y, f, 'strict')[0] is not None
                      for f in ['gross_mwh', 'co2_tonnes'])
        by_year[label] = {'year': y, 'complete': valid,
                          'gross_status': 'complete' if gross is not None else gn,
                          'co2_status': 'complete' if co2 is not None else cn}
    return {'identity_status': 'included', 'years': by_year,
            'all_complete': all(r['complete'] for r in by_year.values()), 'strict_complete': strict}


def support_ledger(grid, net_coverage, net, carbon, paired, monitor_index, identities, mode):
    coverage = {(r['key'], r['year']): r for r in net_coverage}
    net_keys = {(r['key'], r['year']) for r in net}
    carbon_keys = {(r['key'], r['year']) for r in carbon}
    pair_keys = {(r['key'], r['year']) for r in paired}
    out = []
    for original in grid:
        r = dict(original, mode=mode)
        key = r['key'], r['year']
        diagnostics = monitor_diagnostic(r, monitor_index, identities) if r['risk_eligible'] else None
        r.update(plan_supported=bool(r['risk_eligible'] and r['current_plan']),
                 net_supported=key in net_keys, carbon_supported=key in carbon_keys,
                 paired_supported=key in pair_keys, monitor_diagnostic=diagnostics,
                 generation_coverage=coverage[key]['coverage'] if key in coverage else {},
                 measurement_gaps=[])
        if key in coverage:
            for k, status in coverage[key]['coverage'].items():
                if status != 'complete':
                    r['measurement_gaps'].append('generation:' + k + ':' + status)
            if diagnostics['identity_status'] != 'included':
                r['measurement_gaps'].append('monitor:identity')
            else:
                for k, values in diagnostics['years'].items():
                    if not values['complete']:
                        r['measurement_gaps'].append('monitor:' + k)
        if not r['risk_eligible']:
            reason = r['origin_status']
        elif not r['plan_supported']:
            reason = 'blank_current_plan'
        elif not r['net_supported']:
            reason = coverage[key]['status']
        elif not r['carbon_supported']:
            reason = 'monitor:identity' if diagnostics['identity_status'] != 'included' else 'monitor:incomplete_year'
        elif not r['paired_supported']:
            reason = 'pair:negative_or_invalid'
        else:
            reason = 'paired_supported'
        r['sequential_status'] = reason
        out.append(r)
    return out


def group_summary(ledger):
    summaries = []
    strata = ['all', 'recorded_outcome_exit', 'no_recorded_outcome_exit', 'unknown_exit_status']
    for y in [None, *sorted({r['year'] for r in ledger})]:
        for stratum in strata:
            rows = [r for r in ledger if (y is None or r['year'] == y) and
                    (stratum == 'all' or r['exit_stratum'] == stratum)]
            stages = {}
            for stage in STAGES:
                if stage == 'grid':
                    selected = rows
                elif stage == 'eligible_origin':
                    selected = [r for r in rows if r['risk_eligible']]
                else:
                    selected = [r for r in rows if r[stage]]
                stages[stage] = stage_counts(selected)
            risk = [r for r in rows if r['risk_eligible']]
            summaries.append({'origin_year': y, 'stratum': stratum, 'stages': stages,
                              'first_exclusion': dict(Counter(r['sequential_status'] for r in risk)),
                              'all_measurement_gaps': dict(Counter(g for r in risk for g in r['measurement_gaps'])),
                              'paired_retention_of_eligible_origins': len([r for r in risk if r['paired_supported']])/len(risk) if risk else None})
    return summaries


def error_summary(net, carbon, ledger, paired=False):
    strata = {(r['key'], r['year']): r['exit_stratum'] for r in ledger}
    out = []
    for metric, panel in [('net_mwh', net), ('co2_tonnes', carbon)]:
        for group in ['all', 'recorded_outcome_exit', 'no_recorded_outcome_exit', 'unknown_exit_status']:
            rows = [r for r in panel if group == 'all' or strata[(r['key'], r['year'])] == group]
            differences = [abs(r['forecasts']['persistence']-r['actual']) -
                           abs(r['forecasts']['updated_recent']-r['actual']) for r in rows]
            by_plant = [{'plant': p,
                         'rows': sum(r['plant'] == p for r in rows),
                         'absolute_error_reduction': math.fsum(d for r, d in zip(rows, differences) if r['plant'] == p)}
                        for p in sorted({r['plant'] for r in rows})]
            total = math.fsum(differences)
            if paired:
                base = dict(counts(rows), actual_total=math.fsum(r['actual'] for r in rows), rules={})
                denominator = math.fsum(abs(r['actual']) for r in rows)
                for rule in RULES:
                    errors = [r['forecasts'][rule]-r['actual'] for r in rows]
                    absolute = math.fsum(abs(e) for e in errors)
                    base['rules'][rule] = dict(
                        predicted_total=math.fsum(r['forecasts'][rule] for r in rows),
                        bias_total=math.fsum(errors), mae=absolute/len(rows) if rows else None,
                        wape=absolute/denominator if denominator else None,
                        mae_per_mw=math.fsum(abs(e)/r['capacity_mw'] for r, e in zip(rows, errors))/len(rows) if rows else None)
            else:
                base = summarize(rows)
            out.append({'metric': metric, 'stratum': group, **base,
                        'updated_vs_persistence': {
                            'absolute_error_reduction_total': total,
                            'plants': by_plant,
                            'leave_one_plant_out': [dict(omitted_plant=r['plant'],
                                remaining_rows=len(rows)-r['rows'],
                                absolute_error_reduction_total=total-r['absolute_error_reduction'])
                                for r in by_plant if r['rows'] < len(rows)],
                            'interpretation': 'positive means lower updated-plan error; descriptive, not a prospective decision rule'}})
    return out


def paired_error_summary(pairs, ledger):
    def view(prefix):
        return [dict(r, actual=r[prefix+'_actual'], forecasts=r[prefix+'_forecasts']) for r in pairs]
    return error_summary(view('g'), view('e'), ledger, paired=True)


def case_alignment(contract):
    rows = csv_rows(ROOT / contract['case_snapshots'])
    out = []
    for r in rows:
        upper = float(r['net_exposure_ceiling_tonnes'])
        lower = float(r['benefit_lower_bound_tonnes'])
        out.append({'case_id': r['case_id'], 'year': int(r['year']), 'asof': r['asof'],
                    'mu': float(r['mu']), 'constraint_type': r['constraint_type'],
                    'continuation_remaining_tonnes': float(r['remaining_net_exposure_ceiling_tonnes']),
                    'action_exposure_ceiling_tonnes': upper,
                    'lower_bound_tonnes': lower, 'window_days': int(r['ceiling_days']),
                    'release_status': r['release_status'],
                    'break_even_period_cost_ceiling_at_v100': upper*100,
                    'window_to_continuation_ratio': upper/float(r['remaining_net_exposure_ceiling_tonnes'])
                         if float(r['remaining_net_exposure_ceiling_tonnes']) else None,
                    'at_ceiling_cost': project_margin_interval(lower, upper, 100, upper*100),
                    'at_zero_cost': project_margin_interval(lower, upper, 100, 0)})
    return out


def calculate(validation):
    contract = read(RAW / 'contract.json')
    parent = read(ROOT / contract['parent_contract'])
    cohort = csv_rows(ROOT / parent['cohort'])
    history = read(ROOT / parent['history']); generation = read(ROOT / parent['generation'])
    monitor = read(ROOT / parent['monitor_months']); identities = read(ROOT / parent['monitor_identity'])
    net, coverage = build_panel(cohort, history, generation, contract['origins'])
    carbon, carbon_coverage = carbon_panel(net, monitor, identities)
    pairs, pair_coverage = pair_panels(net, carbon)
    controls = {'original_net_panel': net, 'original_coverage': coverage,
                'original_carbon_panel': carbon, 'original_carbon_coverage': carbon_coverage,
                'original_pair_panel': pairs, 'original_pair_coverage': pair_coverage}
    for name, values in controls.items():
        if values != read(ROOT / contract[name]):
            raise ValueError('Predecessor ledger differs: ' + name)
    anet, acoverage = annual_panel(coverage, generation, validation)
    acarbon, _ = carbon_panel(anet, monitor, identities)
    apairs, _ = pair_panels(anet, acarbon)
    gm = generation_index(generation)
    reported_validation = [dict(r, **reported_annual_support(gm[(r['key'], r['year'])],
        r['reported_annual_mwh'], r['fields_match'] and r['monthly_match'])) for r in validation]
    rnet, rcoverage = annual_panel(coverage, generation, reported_validation,
        basis='official reported annual total; missing months not imputed; within-year timing not identified')
    rcarbon, _ = carbon_panel(rnet, monitor, identities)
    rpairs, _ = pair_panels(rnet, rcarbon)
    grid = origin_grid(cohort, history, contract['origins'], contract['exit_census'])
    if {(r['key'], r['year']) for r in grid if r['risk_eligible']} != {(r['key'], r['year']) for r in coverage}:
        raise ValueError('Risk-set reconstruction differs')
    mm = {(*r['pair'], r['month']): r for r in monitor}
    ii = {r['key']: r for r in identities}
    original = support_ledger(grid, coverage, net, carbon, pairs, mm, ii, 'original_M')
    annual = support_ledger(grid, acoverage, anet, acarbon, apairs, mm, ii, 'annual_M_AM')
    reported = support_ledger(grid, rcoverage, rnet, rcarbon, rpairs, mm, ii, 'reported_annual')
    old = {(r['key'], r['year']) for r in pairs}; new = {(r['key'], r['year']) for r in apairs}
    frequencies = {f: dict(Counter(r['status'] for r in validation if r['frequency'] == f))
                   for f in sorted({r['frequency'] for r in validation})}
    case_rows = case_alignment(contract)
    old_net = {(r['key'], r['year']) for r in net}
    new_net = {(r['key'], r['year']) for r in anet}
    incomplete = [r for r in validation if r['status'] == 'incomplete_months']
    results = {'phase': 84, 'cohort': stage_counts(grid), 'original_controls_exact': list(controls),
               'frequency_validation': frequencies, 'annual_validation_rows': len(validation),
               'incomplete_month_records': {
                   'rows': len(incomplete),
                   'with_reported_annual_total': sum(r['reported_annual_mwh'] is not None for r in incomplete),
                   'with_nonnegative_reported_annual_total': sum(r['reported_annual_mwh'] is not None and r['reported_annual_mwh'] >= 0 for r in incomplete),
                   'included_in_current_sensitivity': False,
                   'interpretation': 'annual-total-only analysis is a separate design; no missing month is filled with zero'},
               'sample_modes': {
                   'original_M': {'support': group_summary(original), 'annual_errors': error_summary(net, carbon, original),
                                  'paired_errors': paired_error_summary(pairs, original)},
                   'annual_M_AM': {'support': group_summary(annual), 'annual_errors': error_summary(anet, acarbon, annual),
                                    'paired_errors': paired_error_summary(apairs, annual)},
                   'reported_annual': {'support': group_summary(reported), 'annual_errors': error_summary(rnet, rcarbon, reported),
                                       'paired_errors': paired_error_summary(rpairs, reported)}},
               'net_support_additions': [dict(key=k, year=y, outcome_year=y+1) for k, y in sorted(new_net-old_net)],
               'net_support_losses': [dict(key=k, year=y, outcome_year=y+1) for k, y in sorted(old_net-new_net)],
               'paired_additions': [dict(key=k, year=y, outcome_year=y+1) for k, y in sorted(new-old)],
               'paired_losses': [dict(key=k, year=y, outcome_year=y+1) for k, y in sorted(old-new)],
               'strict_pair_support': {mode: stage_counts([r for r in panel if r['strict_complete']])
                   for mode, panel in [('original_M', pairs), ('annual_M_AM', apairs), ('reported_annual', rpairs)]},
               'reported_annual_pair_additions': [dict(key=k, year=y, outcome_year=y+1)
                   for k, y in sorted({(r['key'], r['year']) for r in rpairs}-old)],
               'reported_annual_pair_losses': [dict(key=k, year=y, outcome_year=y+1)
                   for k, y in sorted(old-{(r['key'], r['year']) for r in rpairs})],
               'reported_annual_status': read(RAW / 'reported_annual_contract.json'),
               'retrospectively_already_retired_risk_rows': sum(r['risk_eligible'] and r['retrospectively_already_retired'] for r in grid),
               'case_alignment_rows': len(case_rows),
               'interpretation': 'Annual support sensitivity; recorded exits are post-hoc strata. No missing reports filled with zero.'}
    locked_modes = read(RAW / 'reported_annual_inputs.json')['original_sample_mode_digests']
    if any(mode_digest(results['sample_modes'][m]) != h for m, h in locked_modes.items()):
        raise ValueError('An earlier sample-mode summary changed')
    return results, original+annual+reported, anet, acarbon, apairs, case_rows, rnet, rcarbon, rpairs


def save(output, computed, validation):
    results, ledger, net, carbon, pairs, cases, rnet, rcarbon, rpairs = computed
    write(output / 'results.json', results)
    write_csv(output / 'origin_ledger.csv', ledger)
    write_csv(output / 'annual_validation.csv', validation)
    write(output / 'annual_net_panel.json', net)
    write(output / 'annual_carbon_panel.json', carbon)
    write(output / 'annual_pair_panel.json', pairs)
    write(output / 'reported_annual_net_panel.json', rnet)
    write(output / 'reported_annual_carbon_panel.json', rcarbon)
    write(output / 'reported_annual_pair_panel.json', rpairs)
    write(output / 'case_alignment.json', cases)


def verify(computed, validation):
    results, ledger, net, carbon, pairs, cases, rnet, rcarbon, rpairs = computed
    checks = 0
    def require(condition, message):
        nonlocal checks
        if not condition:
            raise ValueError(message)
        checks += 1
    for mode in MODES:
        rows = [r for r in ledger if r['mode'] == mode]
        aggregate = next(r for r in results['sample_modes'][mode]['support'] if r['origin_year'] is None and r['stratum'] == 'all')
        for stage in STAGES:
            flags = (lambda r: True) if stage == 'grid' else (lambda r: r['risk_eligible']) if stage == 'eligible_origin' else (lambda r: r[stage])
            selected = [r for r in rows if flags(r)]
            require(aggregate['stages'][stage]['rows'] == len(selected), 'Stage row count')
            require(aggregate['stages'][stage]['units'] == len(set(r['key'] for r in selected)), 'Stage unit count')
            require(math.isclose(aggregate['stages'][stage]['repeated_origin_capacity_mw'], sum(r['capacity_mw'] for r in selected), abs_tol=1e-7), 'Stage capacity sum')
        for r in rows:
            require(not r['paired_supported'] or r['carbon_supported'], 'Pair hierarchy')
            require(not r['carbon_supported'] or r['net_supported'], 'Carbon hierarchy')
            require(not r['net_supported'] or r['plan_supported'], 'Net hierarchy')
    vm = {(r['key'], r['year']): r for r in validation}
    contract = read(RAW / 'contract.json'); parent = read(ROOT / contract['parent_contract'])
    raw_generators = generation_index(read(ROOT / parent['generation']))
    identity = {r['key']: r for r in read(ROOT / parent['monitor_identity'])}
    monitor = {(*r['pair'], r['month']): r for r in read(ROOT / parent['monitor_months'])}
    for r in validation:
        g = raw_generators[(r['key'], r['year'])]
        require(r['fields_match'] and r['monthly_match'], 'Raw extraction differs from original workbook')
        if r['status'] == 'complete':
            require(r['frequency'] in contract['annual_frequencies'], 'Unsupported included frequency')
            total = sum(g['values'])
            require(abs(total-r['reported_annual_mwh']) <= contract['annual_absolute_tolerance_mwh'] +
                    contract['annual_relative_tolerance']*abs(r['reported_annual_mwh']), 'Independent month sum')
    for r in net:
        require(vm[(r['key'], r['outcome_year'])]['status'] == 'complete', 'Unvalidated annual outcome')
        require(math.isclose(r['actual'], vm[(r['key'], r['outcome_year'])]['reported_annual_mwh'], abs_tol=1e-6, rel_tol=1e-10), 'Reported annual mismatch')
        require(math.isclose(r['forecasts']['persistence'], r['rate1'] * year_hours(r['outcome_year']), abs_tol=1e-7), 'Persistence formula')
    for r in rnet:
        require(r['actual'] == vm[(r['key'], r['outcome_year'])]['reported_annual_mwh'], 'Reported annual quantity not used directly')
        prior = vm[(r['key'], r['year'])]['reported_annual_mwh']
        require(math.isclose(r['forecasts']['persistence'], prior * year_hours(r['outcome_year'])/year_hours(r['year']), abs_tol=1e-7), 'Reported annual persistence formula')
    for r in pairs + rpairs:
        require(r['g_actual'] >= 0 and r['e_actual'] >= 0, 'Negative final outcome')
        require(r['historical_identity_validated'] == identity[r['key']]['historical_identity_validated'], 'Changed historical identity status')
        pair = tuple(identity[r['key']]['monitor_pairs'][0])
        prior = sum(monitor[(*pair, f"{r['year']}-{m:02}")]['conditional']['co2_tonnes']['value'] for m in range(1, 13))
        actual = sum(monitor[(*pair, f"{r['outcome_year']}-{m:02}")]['conditional']['co2_tonnes']['value'] for m in range(1, 13))
        require(math.isclose(r['e_actual'], actual, abs_tol=1e-6), 'Independent CO2 total')
        expected = prior * ((366 if calendar.isleap(r['outcome_year']) else 365) /
                            (366 if calendar.isleap(r['year']) else 365))
        require(math.isclose(r['e_forecasts']['persistence'], expected, abs_tol=1e-6), 'Independent CO2 persistence')
    old_pairs = {(r['key'], r['outcome_year']): r for r in read(ROOT / contract['original_pair_panel'])}
    new_pairs = {(r['key'], r['outcome_year']): r for r in rpairs}
    for case in read(ROOT / 'data/raw/phase83/cases.json'):
        for unit in case['units']:
            key = case['facility_id']+':'+unit, case['year']
            require(new_pairs[key] == old_pairs[key], 'Case and annual panel changed inconsistently')
    source = csv_rows(ROOT / read(RAW / 'contract.json')['case_snapshots'])
    require(len(cases) == len(source), 'Case snapshot count differs')
    for new, old in zip(cases, source):
        require(new['action_exposure_ceiling_tonnes'] == float(old['net_exposure_ceiling_tonnes']), 'Changed case exposure')
        require(new['break_even_period_cost_ceiling_at_v100'] == 100 * float(old['net_exposure_ceiling_tonnes']), 'Case cost boundary')
        require(new['lower_bound_tonnes'] == 0, 'Unidentified benefit lower bound')
        require(new['at_ceiling_cost']['carbon_margin_status'] == 'nonpositive_under_fixed_inputs', 'Tie boundary')
    return {'checks': checks, 'passed': True, 'protected_files_unchanged': preserved(),
            'original_ledgers_exact': results['original_controls_exact'],
            'raw_generator_year_rows': len(validation), 'case_alignment_rows': len(cases)}


def plots(results):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'axes.spines.top': False,
                         'axes.spines.right': False, 'pdf.fonttype': 42})
    folder = ROOT / 'outputs/phase84'; folder.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.1), sharey=True)
    labels = ['Eligible\norigin', 'Plan\nsupported', 'Net\ngeneration', 'CO2\nmonitor', 'Final\npaired']
    for ax, mode, title in zip(axes, MODES, ['Original M-only support', 'Reconciled M/AM sensitivity', 'Reported annual totals']):
        for group, color, marker in [('recorded_outcome_exit', '#bd4b3d', 'o'), ('no_recorded_outcome_exit', '#187f86', 's')]:
            r = next(x for x in results['sample_modes'][mode]['support'] if x['origin_year'] is None and x['stratum'] == group)
            n = r['stages']['eligible_origin']['rows']
            values = [100*r['stages'][s]['rows']/n if n else 0 for s in STAGES[1:]]
            ax.plot(range(5), values, marker=marker, color=color, lw=1.8,
                    label=f"{'Recorded exits' if group == 'recorded_outcome_exit' else 'Other known exit status'} (n={n})")
            ax.text(4.04, values[-1], f"{r['stages']['paired_supported']['rows']}/{n}", color=color, fontsize=9, va='center')
        ax.set_xticks(range(5), labels); ax.set_ylim(-3, 107); ax.set_xlim(-.15, 4.65)
        ax.set_title(title, fontsize=11); ax.legend(frameon=False, fontsize=8, loc='upper right')
    axes[0].set_ylabel('Retained eligible-origin rows (%)')
    fig.tight_layout(); fig.savefig(folder / 'sample_support.png', dpi=180); plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(9, 3.9))
    for ax, metric, label in zip(axes, ['net_mwh', 'co2_tonnes'], ['Net generation', 'CO2']):
        records = [r for r in results['sample_modes']['reported_annual']['paired_errors'] if r['metric'] == metric]
        groups = ['recorded_outcome_exit', 'no_recorded_outcome_exit']
        for shift, rule, color in [(-.18, 'updated_recent', '#187f86'), (.18, 'persistence', '#ad6650')]:
            vals = [next(r for r in records if r['stratum'] == g)['rules'][rule]['wape'] for g in groups]
            ax.bar([i+shift for i in range(2)], [100*v if v is not None else 0 for v in vals], .34,
                   label='Updated plan + recent rate' if rule == 'updated_recent' else 'Recent-rate continuation', color=color)
        ns = [next(r for r in records if r['stratum'] == g)['rows'] for g in groups]
        ax.set_xticks(range(2), [f'Recorded exits\n(n={ns[0]})', f'Other known status\n(n={ns[1]})'])
        ax.set_title(label, fontsize=11); ax.set_ylabel('Absolute error / observed total (%)')
        ax.legend(frameon=False, fontsize=8)
    fig.tight_layout(); fig.savefig(folder / 'annual_errors_by_exit.png', dpi=180); plt.close(fig)


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--mode', choices=['freeze', 'freeze-reported', 'run', 'verify', 'reproduce'], required=True)
    args = parser.parse_args()
    if args.mode == 'freeze':
        freeze(); return
    if args.mode == 'freeze-reported':
        freeze_reported(); return
    preserved()
    contract = read(RAW / 'contract.json'); parent = read(ROOT / contract['parent_contract'])
    if args.mode in {'run', 'reproduce'}:
        validation = validate_workbooks(read(ROOT / parent['generation']), contract)
    else:
        validation = []
        for r in csv_rows(OUT / 'annual_validation.csv'):
            r['year'] = int(r['year']); r['row'] = int(r['row'])
            for k in ['annual_mwh', 'rate_mw', 'annual_discrepancy_mwh', 'reported_annual_mwh']:
                r[k] = float(r[k]) if r[k] else None
            for k in ['fields_match', 'monthly_match']:
                r[k] = r[k] == 'True'
            validation.append(r)
    computed = calculate(validation)
    verification = verify(computed, validation)
    if args.mode == 'run':
        save(OUT, computed, validation)
        write(OUT / 'verification.json', verification)
        import openpyxl
        write(OUT / 'environment.json', {'python': sys.version, 'platform': platform.platform(), 'openpyxl': openpyxl.__version__})
        plots(computed[0])
        write(OUT / 'product_manifest.json', {p: digest(OUT / p) for p in PRODUCTS})
    elif args.mode == 'reproduce':
        target = OUT / 'reproduction'; save(target, computed, validation)
        equal = {p: digest(target/p) == digest(OUT/p) for p in PRODUCTS}
        if not all(equal.values()):
            raise ValueError('Scientific products do not repeat')
        write(OUT / 'reproduction.json', {'byte_identical': equal, **verification})
    else:
        if computed[0] != read(OUT / 'results.json'):
            raise ValueError('Saved summary differs from rebuild')
        for p, h in read(OUT / 'product_manifest.json').items():
            if digest(OUT/p) != h:
                raise ValueError('Changed product: ' + p)
        write(OUT / 'verification.json', verification)
    print(json.dumps(verification), flush=True)


if __name__ == '__main__':
    main()
