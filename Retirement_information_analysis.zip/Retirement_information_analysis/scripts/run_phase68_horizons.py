"""Equal-horizon descriptions using fixed local retirement records."""
import argparse
import calendar
from collections import defaultdict
import csv
from datetime import date
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data/raw/phase68'
OUT = ROOT / 'data/processed/phase68'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n', encoding='utf-8')


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()


def add_months(anchor, months):
    d = date.fromisoformat(anchor)
    if d.day != calendar.monthrange(d.year, d.month)[1]:
        raise ValueError('Anchor must be month-end')
    y, m = divmod(d.year*12+d.month-1+months, 12)
    return date(y, m+1, calendar.monthrange(y, m+1)[1]).isoformat()


def parse_plan(raw):
    y, m = raw.get('Planned Retirement Year'), raw.get('Planned Retirement Month')
    blank = lambda v: v is None or str(v).strip() == ''
    if blank(y) and blank(m):
        return None, 'blank'
    try:
        y, m = float(y), float(m)
        if not y.is_integer() or not m.is_integer():
            return None, 'invalid'
        return date(int(y), int(m), calendar.monthrange(int(y), int(m))[1]).isoformat(), 'valid'
    except (ValueError, TypeError, OverflowError):
        return None, 'invalid'


def checkpoint_state(history, snapshots, checkpoint):
    available = [s for s in snapshots if s <= checkpoint]
    result = {'category':'no_snapshot','snapshot':None,'snapshot_age_months':None,
              'plan_date':None,'reported_retirement':None,'source_rows':[]}
    if not available:
        return result
    snapshot = max(available)
    a, b = date.fromisoformat(checkpoint), date.fromisoformat(snapshot)
    result.update(snapshot=snapshot, snapshot_age_months=(a.year-b.year)*12+a.month-b.month)
    rs = [r for r in history if r['snapshot'] == snapshot]
    result['source_rows'] = [{k:r.get(k) for k in ('source','sheet','row')} for r in rs]
    if not rs:
        return dict(result, category='missing_row')
    signatures = {(r['inventory'], r.get('retirement'), *parse_plan(r['raw'])) for r in rs}
    if len(signatures) != 1:
        return dict(result, category='conflicting_rows')
    inventory, retirement, plan, validity = signatures.pop()
    result.update(plan_date=plan, reported_retirement=retirement)
    if inventory == 'retired':
        category = 'invalid_retirement' if retirement and retirement > snapshot else 'registered_retired'
    elif inventory != 'operating':
        category = 'unknown_inventory'
    elif retirement:
        category = 'invalid_retirement'
    elif validity != 'valid':
        category = 'plan_'+validity
    else:
        category = 'plan_due' if plan <= checkpoint else 'plan_future'
    return dict(result, category=category)


def retrospective_state(history, snapshots, checkpoint, census):
    s = checkpoint_state(history, snapshots, census)
    retirement = s['reported_retirement']
    if s['snapshot'] != census:
        state = 'unknown'
    elif s['category'] == 'registered_retired' and retirement:
        state = 'retired_by_checkpoint' if retirement <= checkpoint else 'retired_later'
    elif s['category'] in {'plan_due','plan_future','plan_blank','plan_invalid'}:
        state = 'not_registered_by_census'
    else:
        state = 'unknown'
    return {'state':state, 'date':retirement}


def recorded_event(history, checkpoint, census):
    available = [r for r in history if r['snapshot'] <= census]
    if not available:
        return {'state':'unknown','date':None,'source_snapshot':None}
    latest = max(r['snapshot'] for r in available)
    s = checkpoint_state(available,[latest],latest)
    d = s['reported_retirement']
    if s['category']=='registered_retired' and d:
        state = 'retired_by_checkpoint' if d <= checkpoint else 'retired_later'
    elif latest==census and s['category'] in {'plan_due','plan_future','plan_blank','plan_invalid'}:
        state = 'not_registered_by_census'
    else:
        state = 'unknown'
    return {'state':state,'date':d,'source_snapshot':latest}


def horizon_eligible(anchor, months, cutoff):
    return add_months(anchor, months) <= cutoff


def totals(rows):
    return {'n':len(rows), 'mw':round(math.fsum(r['capacity_mw'] for r in rows), 8)}


def summarize(rows):
    s = totals(rows)
    s['categories'] = {v:totals([r for r in rows if r['category'] == v])
                       for v in sorted({r['category'] for r in rows})}
    s['retrospective'] = {v:totals([r for r in rows if r['retrospective_state'] == v])
                         for v in sorted({r['retrospective_state'] for r in rows})}
    if rows and 'recorded_event_state' in rows[0]:
        s['recorded_event'] = {v:totals([r for r in rows if r['recorded_event_state']==v])
                              for v in sorted({r['recorded_event_state'] for r in rows})}
    s['cross_classification'] = [dict(category=c,retrospective_state=t,**totals(rs))
        for c in sorted(s['categories']) for t in sorted(s['retrospective'])
        if (rs := [r for r in rows if r['category']==c and r['retrospective_state']==t])]
    ages = [r['snapshot_age_months'] for r in rows if r['snapshot_age_months'] is not None]
    s['snapshot_age_months'] = {'min':min(ages,default=None),'max':max(ages,default=None),
        'mean':math.fsum(ages)/len(ages) if ages else None}
    s['known_current_schedule'] = totals([r for r in rows if r['category'] in
        {'registered_retired','plan_due','plan_future'}])
    s['current_schedule_due_or_retired'] = totals([r for r in rows if r['category'] in
        {'registered_retired','plan_due'}])
    return s


def monitoring_row(w):
    if not w['pool_eligible'] or not w['window']['followup_complete']:
        return None
    f = w['full_window']; metrics = f['metrics']
    gross, carbon = (metrics[m]['conditional_full_total'] for m in ('gross','co2'))
    retirement = w['latest_reported_date']; anchor = w['plan_date']
    group = ('before_or_at_plan' if retirement and retirement <= anchor else
             'during_window' if retirement and retirement <= add_months(anchor,12) else 'not_by_window_end')
    gross_state = ('observed_positive' if f['positive_gross_days'] > 0 else
                   'complete_zero' if gross == 0 else 'unknown')
    return {'key':w['key'], 'capacity_mw':w['capacity_mw'], 'retirement_group':group,
            'gross_state':gross_state, 'gross_mwh':gross,
            'co2_metric_tonnes':carbon*0.90718474 if carbon is not None else None,
            'joint_complete':gross is not None and carbon is not None,
            'positive_gross_days':f['positive_gross_days'],
            'positive_activity_days':f['positive_activity_days'],
            'plan_date':anchor, 'latest_reported_date':retirement}


def monitoring_summary(rows):
    matched = [r for r in rows if r['joint_complete']]
    joint = dict(totals(matched), gross_mwh=math.fsum(r['gross_mwh'] for r in matched),
                 co2_metric_tonnes=math.fsum(r['co2_metric_tonnes'] for r in matched))
    s = dict(totals(rows), joint_complete=joint)
    s['gross_states'] = {v:totals([r for r in rows if r['gross_state']==v])
                         for v in ('observed_positive','complete_zero','unknown')}
    s['metric_complete'] = {m:dict(totals(rs), total=math.fsum(r[m] for r in rs))
        for m in ('gross_mwh','co2_metric_tonnes') if (rs := [r for r in rows if r[m] is not None])}
    return s


def freeze():
    c = read(RAW/'contract.json')
    names = {c[k] for k in ('cohort','history','date_ledger','monitoring')}
    names.update(r['source'] for r in read(ROOT/c['history']))
    names.update({'data/raw/phase68/contract.json','data/raw/phase46/contract.json',
        'data/raw/phase13_1/source_manifest.csv','data/raw/phase45/input_lock.json',
        'scripts/run_phase45_reconciliation.py','scripts/run_phase46_windows.py'})
    for folder in ['manuscript/ere_v1','author_review_ere_v1_2026-09-27']:
        names.update(p.relative_to(ROOT).as_posix() for p in (ROOT/folder).rglob('*') if p.is_file())
    for stem in ['draft_nature_sustainability_analysis_v1_2','supplementary_information_nature_sustainability_v1_2',
                 'draft_ne_main_v3_6','supplementary_information_v3_6']:
        for ext in ('.tex','.pdf'):
            p = ROOT/'manuscript'/(stem+ext)
            if p.exists():
                names.add(p.relative_to(ROOT).as_posix())
    records = [{'path':s,'sha256':digest(ROOT/s),'bytes':(ROOT/s).stat().st_size} for s in sorted(names)]
    target = RAW/'inputs.json'
    if target.exists() and read(target) != records:
        raise ValueError('Refusing to replace input freeze')
    write(target,records)
    print(json.dumps({'frozen_files':len(records)}))


def check_inputs():
    records = read(RAW/'inputs.json')
    for r in records:
        if digest(ROOT/r['path']) != r['sha256']:
            raise ValueError('Changed input: '+r['path'])
    return len(records)


def build():
    check_inputs(); c = read(RAW/'contract.json')
    with (ROOT/c['cohort']).open(encoding='utf-8-sig',newline='') as f:
        cohort = list(csv.DictReader(f))
    history = read(ROOT/c['history']); by_key = defaultdict(list)
    for r in history:
        by_key[r['key']].append(r)
    snapshots = sorted({r['snapshot'] for r in history})
    date_ledger = {r['key']:r for r in read(ROOT/c['date_ledger'])}
    ledger, reconciliation, census_rows = [], [], []
    for unit in cohort:
        key = unit['eia_plant_id']+':'+unit['eia_generator_id']
        anchor = unit[c['anchor']]; weight = float(unit[c['weight']])
        final = recorded_event(by_key[key],c['census_end'],c['census_end'])
        latest_status=checkpoint_state(by_key[key],snapshots,c['census_end'])
        strict=retrospective_state(by_key[key],snapshots,c['census_end'],c['census_end'])
        census_rows.append(dict(latest_status,key=key,capacity_mw=weight,
            retrospective_state=strict['state'],recorded_event_state=final['state']))
        old = date_ledger[key]['date_history']
        if final['date']!=old['latest_reported'] or final['source_snapshot']!=c['census_end']:
            reconciliation.append({'key':key,'plant_name':unit['plant_name'],'capacity_mw':weight,
                'prior_date':old['latest_reported'],'prior_selected_snapshot':old['latest_snapshot'],
                'latest_recorded_event':final,
                'final_snapshot_status':checkpoint_state(by_key[key],snapshots,c['census_end'])})
        for h in c['horizons']:
            checkpoint = add_months(anchor,h)
            eligible = checkpoint <= c['census_end']
            state = checkpoint_state(by_key[key],snapshots,checkpoint) if eligible else {
                'category':'beyond_census','snapshot':None,'snapshot_age_months':None,
                'plan_date':None,'reported_retirement':None,'source_rows':[]}
            retro = retrospective_state(by_key[key],snapshots,checkpoint,c['census_end']) if eligible else {'state':'beyond_census','date':None}
            event = recorded_event(by_key[key],checkpoint,c['census_end']) if eligible else {'state':'beyond_census','date':None,'source_snapshot':None}
            ledger.append(dict(state,key=key,plant_name=unit['plant_name'],state=unit['plant_state'],
                fuel=unit['fuel_group'],ba=unit['balancing_authority_code'],capacity_mw=weight,
                initial_plan=anchor,first_plan_snapshot=unit['first_plan_snapshot_date'],
                horizon=h,checkpoint=checkpoint,eligible=eligible,
                balanced_eligible=horizon_eligible(anchor,max(c['horizons']),c['census_end']),
                retrospective_state=retro['state'],retrospective_date=retro['date'],
                recorded_event_state=event['state'],recorded_event_date=event['date'],
                recorded_event_snapshot=event['source_snapshot']))
    summary = {'cohort_n':len(cohort),'cohort_mw':math.fsum(float(r[c['weight']]) for r in cohort),
               'snapshots':snapshots,'primary_horizon':c['primary_months'],'groups':{}}
    valid_plans=[(r,parse_plan(r['raw'])[0]) for r in history if r['inventory']=='operating' and parse_plan(r['raw'])[1]=='valid']
    summary['plan_field_diagnostic']={'valid_operating_plan_rows':len(valid_plans),
        'before_own_snapshot':sum(p<r['snapshot'] for r,p in valid_plans),
        'equal_own_snapshot':sum(p==r['snapshot'] for r,p in valid_plans),
        'after_own_snapshot':sum(p>r['snapshot'] for r,p in valid_plans)}
    summary['census_endpoint']=summarize(census_rows)
    for h in c['horizons']:
        eligible = [r for r in ledger if r['horizon']==h and r['eligible']]
        subsets = {'all_eligible':eligible,'balanced':[r for r in eligible if r['balanced_eligible']],
            'exact_snapshot':[r for r in eligible if r['snapshot_age_months']==0],
            'recent_snapshot':[r for r in eligible if r['snapshot_age_months'] is not None and r['snapshot_age_months']<=3]}
        summary['groups'][str(h)] = {name:summarize(rs) for name,rs in subsets.items()}
    windows = read(ROOT/c['monitoring'])
    monitoring = []
    for w in windows:
        assert w['latest_reported_date'] == date_ledger[w['key']]['date_history']['latest_reported']
        corrected_date = recorded_event(by_key[w['key']],c['census_end'],c['census_end'])['date']
        r = monitoring_row(dict(w,latest_reported_date=corrected_date))
        if r is not None:
            r['prior_reported_date']=w['latest_reported_date']
            monitoring.append(r)
    ms = {'all':monitoring_summary(monitoring),'groups':{}}
    for group in ('before_or_at_plan','during_window','not_by_window_end'):
        ms['groups'][group] = monitoring_summary([r for r in monitoring if r['retirement_group']==group])
    by_plant = defaultdict(list)
    for r in monitoring:
        if r['joint_complete']:
            by_plant[r['key'].split(':')[0]].append(r)
    ms['joint_plant_totals'] = sorted([dict(plant_id=p,**monitoring_summary(rs)['joint_complete'])
        for p,rs in by_plant.items()],key=lambda r:-r['co2_metric_tonnes'])
    # Paired horizon transitions prevent changing samples from creating persistence.
    pairs = []
    for unit in cohort:
        key = unit['eia_plant_id']+':'+unit['eia_generator_id']
        rs = [r for r in ledger if r['key']==key and r['balanced_eligible']]
        if rs:
            pairs.append({'key':key,'capacity_mw':rs[0]['capacity_mw'],
                'categories':{str(r['horizon']):r['category'] for r in rs},
                'retrospective':{str(r['horizon']):r['retrospective_state'] for r in rs}})
    products = {'checkpoint_ledger.json':ledger,'summary.json':summary,
                'monitoring_ledger.json':monitoring,'monitoring_summary.json':ms,'balanced_paths.json':pairs,
                'date_reconciliation.json':reconciliation}
    for name, value in products.items():
        write(OUT/name,value)
    verify()
    print(json.dumps({'rows':len(ledger),'monitoring_units':len(monitoring),
                      'balanced_units':len(pairs),'primary':summary['groups']['12']['all_eligible']},indent=2))


def verify():
    n = check_inputs(); rows = read(OUT/'checkpoint_ledger.json'); s = read(OUT/'summary.json')
    assert len(rows)==s['cohort_n']*3==888
    assert len({(r['key'],r['horizon']) for r in rows})==len(rows)
    for r in rows:
        assert r['snapshot'] is None or r['snapshot'] <= r['checkpoint']
        assert r['checkpoint']==add_months(r['initial_plan'],r['horizon'])
    for groups in s['groups'].values():
        for g in groups.values():
            assert sum(r['n'] for r in g['categories'].values())==g['n']
            assert abs(math.fsum(r['mw'] for r in g['categories'].values())-g['mw'])<1e-6
            assert sum(r['n'] for r in g['retrospective'].values())==g['n']
    assert len({s['groups'][str(h)]['balanced']['n'] for h in (6,12,24)})==1
    m = read(OUT/'monitoring_ledger.json'); ms = read(OUT/'monitoring_summary.json')
    assert len(m)==187==ms['all']['n']
    assert len({r['key'] for r in m})==len(m)
    assert sum(r['n'] for r in ms['groups'].values())==187
    assert abs(ms['all']['metric_complete']['gross_mwh']['total']-41413969.03)<1e-5
    assert abs(ms['all']['metric_complete']['co2_metric_tonnes']['total']-37806414.953732)<1e-5
    print(json.dumps({'verification':'pass','frozen_unchanged':n,'checkpoint_rows':len(rows)}))


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=['freeze','build','verify'])
    mode = p.parse_args().mode
    {'freeze':freeze,'build':build,'verify':verify}[mode]()
