"""Generate manuscript displays directly from verified integration products."""
import csv
import json
from pathlib import Path
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts.run_phase84_support import read, write_csv, write, digest

DEST=ROOT/'manuscript/omega_v3'
OUT=ROOT/'outputs/phase85'
TEAL='#007D80'; GRAY='#444B52'; GOLD='#B57B24'; BLUE='#337BB0'; RED='#B55350'
MODES=['original_M','annual_M_AM','reported_annual']
MODE_LABELS=['Monthly-only','Reconciled','Reported annual']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'axes.labelsize':8.5,
                     'axes.titlesize':9,'xtick.labelsize':8,'ytick.labelsize':8,
                     'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,
                     'axes.spines.right':False,'axes.linewidth':.7,'savefig.dpi':220})


def error(result,mode,metric,stratum):
    return next(r for r in result['sample_modes'][mode]['paired_errors']
                if r['metric']==metric and r['stratum']==stratum)


def support(result,mode,stratum):
    return next(r['stages'] for r in result['sample_modes'][mode]['support']
                if r['origin_year'] is None and r['stratum']==stratum)


def save(fig,name,source):
    fig.savefig(DEST/(name+'.pdf'))
    fig.savefig(OUT/(name+'.png'))
    write_csv(OUT/(name+'_source.csv'),source)
    plt.close(fig)


def label(ax,letter,title):
    ax.set_title(title,loc='left',pad=12)
    ax.text(-.16,1.06,'('+letter+')',transform=ax.transAxes,fontweight='bold',fontsize=10)


def main():
    DEST.mkdir(parents=True,exist_ok=True); OUT.mkdir(parents=True,exist_ok=True)
    verified=read(ROOT/'data/processed/phase85/verification.json')
    if verified['status']!='pass': raise ValueError('Displays require verified results')
    a=read(ROOT/'data/processed/phase84/results.json')
    s=read(ROOT/'data/processed/phase85/summary.json')
    cases=read(ROOT/'data/processed/phase83/results.json')
    annual=read(ROOT/'data/processed/phase85/annual.json')
    macros={}
    def put(key,value,decimals=None):
        macros[key]=str(value) if decimals is None else f'{value:.{decimals}f}'
    for k in ['rows','generators','plants','exit_rows']:
        put({'rows':'PanelRows','generators':'PanelUnits','plants':'PanelPlants','exit_rows':'PanelExits'}[k],s['panel'][k])
    put('UniqueGW',s['panel']['unique_capacity_mw']/1000,3)
    for stratum,prefix in [('all','All'),('recorded_outcome_exit','Exit'),('no_recorded_outcome_exit','Other')]:
        e=error(a,'reported_annual','co2_tonnes',stratum)
        put(prefix+'Updated',100*e['rules']['updated_recent']['wape'],2)
        put(prefix+'Persistence',100*e['rules']['persistence']['wape'],2)
        put(prefix+'Saving',e['updated_vs_persistence']['absolute_error_reduction_total']/1e6,3)
    for mode,prefix in [('original_M','Original'),('annual_M_AM','Reconciled')]:
        e=error(a,mode,'co2_tonnes','all')
        put(prefix+'Updated',100*e['rules']['updated_recent']['wape'],2)
        put(prefix+'Persistence',100*e['rules']['persistence']['wape'],2)
    for method,prefix,comparator in [('updated_recent','UpdatedVsPersistence','persistence'),
                                    ('minimax_regret','RobustVsUpdated','updated_recent'),
                                    ('minimax_regret','RobustVsPersistence','persistence')]:
        c=s['annual_comparisons'][method][comparator]
        for k in ['lower','higher','ties']: put(prefix+k.title(),c[k])
    put('CoverageRows',sum(c['in_baseline_range_rows'] for c in s['central']))
    put('LooCases',s['sensitivity_comparisons']['central_leave_one_plant_out']['minimax_regret']['updated_recent']['n'])
    put('Tests',184)
    (DEST/'numbers.tex').write_text('\n'.join('\\newcommand{\\'+k+'}{'+v+'}' for k,v in macros.items())+'\n',encoding='utf-8')

    source=[]; fig,axes=plt.subplots(1,2,figsize=(6.35,3.45))
    for j,stage in enumerate(['net_supported','carbon_supported','paired_supported']):
        v=[support(a,m,'all')[stage]['rows'] for m in MODES]
        bars=axes[0].bar(np.arange(3)+(j-1)*.24,v,width=.22,color=[BLUE,GOLD,TEAL][j],
                         label=['Net generation','Carbon dioxide','Paired'][j])
        if j==2: axes[0].bar_label(bars,padding=3,fontsize=8)
        source += [dict(panel='all',mode=m,stage=stage,rows=n) for m,n in zip(MODES,v)]
    axes[0].set_xticks(range(3),['Monthly\nonly','Reconciled','Reported\nannual'])
    axes[0].set_ylabel('Generator-year observations'); axes[0].set_ylim(0,570)
    label(axes[0],'a','Annual measurement support')
    x=np.arange(4)
    for m,color,name in zip(MODES,[GRAY,BLUE,TEAL],MODE_LABELS):
        v=[support(a,m,'recorded_outcome_exit')[k]['rows'] for k in
           ['plan_supported','net_supported','carbon_supported','paired_supported']]
        axes[1].plot(x,v,'o-',color=color,label=name,markersize=4)
        source += [dict(panel='recorded_exit',mode=m,stage=stage,rows=n) for stage,n in
                   zip(['plan','generation','carbon','paired'],v)]
    axes[1].set_xticks(x,['Plan','Net\ngeneration','Carbon','Paired'])
    axes[1].set_ylim(0,158); axes[1].set_ylabel('Recorded-exit observations')
    label(axes[1],'b','Coverage near completed exits')
    axes[0].legend(frameon=False,fontsize=7,loc='upper left')
    axes[1].legend(frameon=False,fontsize=7,loc='upper right')
    fig.subplots_adjust(left=.105,right=.98,bottom=.2,top=.85,wspace=.46)
    save(fig,'figure1_support',source)

    source=[]; fig,axes=plt.subplots(1,2,figsize=(6.35,3.05))
    for ax,panel,groups,labels in [(axes[0],'pooled',MODES,['Monthly\nonly','Reconciled','Reported\nannual']),
                                  (axes[1],'strata',['recorded_outcome_exit','no_recorded_outcome_exit'],['Recorded exit\n(n=12)','No recorded exit\n(n=140)'])]:
        for j,(rule,color,name) in enumerate([('updated_recent',TEAL,'Updated date'),('persistence',GRAY,'Persistence')]):
            vals=[100*error(a,g if panel=='pooled' else 'reported_annual','co2_tonnes',
                           'all' if panel=='pooled' else g)['rules'][rule]['wape'] for g in groups]
            bars=ax.bar(np.arange(len(groups))+(j-.5)*.3,vals,width=.28,color=color,label=name)
            ax.bar_label(bars,fmt='%.1f',padding=3,fontsize=7.5)
            source += [dict(panel=panel,group=g,rule=rule,wape_percent=v) for g,v in zip(groups,vals)]
        ax.set_xticks(range(len(groups)),labels); ax.set_ylabel('CO$_2$ forecast error (%)')
        ax.set_ylim(0,29 if panel=='pooled' else 96)
    label(axes[0],'a','Pooled comparison by support'); label(axes[1],'b','Reported-annual exit strata')
    handles,labels=axes[1].get_legend_handles_labels()
    fig.legend(handles,labels,frameon=False,ncol=2,loc='lower center',bbox_to_anchor=(.53,.005),fontsize=8)
    fig.subplots_adjust(left=.105,right=.98,bottom=.27,top=.85,wspace=.49)
    save(fig,'figure2_prediction',source)

    source=[]; fig,axes=plt.subplots(1,2,figsize=(6.35,3.25))
    colors={2022:GRAY,2023:TEAL,2024:BLUE,2025:RED}
    for ax,comparator,title in zip(axes,['updated_recent','persistence'],['Updated-date selection','Persistence selection']):
        maximum=max(max(c['methods'][comparator]['observed_regret_mt'],c['methods']['minimax_regret']['observed_regret_mt']) for c in annual)*1.08
        ax.plot([0,maximum],[0,maximum],color='#B9BEC2',lw=.8,zorder=0)
        for year,color in colors.items():
            subset=[c for c in annual if c['year']==year]
            ax.scatter([c['methods'][comparator]['observed_regret_mt'] for c in subset],
                       [c['methods']['minimax_regret']['observed_regret_mt'] for c in subset],
                       s=19,color=color,alpha=.7,label=str(year),linewidths=.3,edgecolors='white')
        ax.set_xlim(-.08,maximum); ax.set_ylim(-.08,maximum)
        ax.set_xlabel('Comparator observed loss (Mt)'); ax.set_ylabel('Five-baseline regret selection\nObserved loss (Mt)')
        source += [dict(comparator=comparator,year=c['year'],mu=c['mu'],q=c['q'],fraction=c['fraction'],
                       comparator_loss_mt=c['methods'][comparator]['observed_regret_mt'],
                       minimax_loss_mt=c['methods']['minimax_regret']['observed_regret_mt']) for c in annual]
    label(axes[0],'a',title='Against updated information'); label(axes[1],'b',title='Against recent operation')
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,frameon=False,ncol=4,loc='lower center',bbox_to_anchor=(.53,.005),fontsize=8)
    fig.subplots_adjust(left=.115,right=.98,bottom=.25,top=.86,wspace=.5)
    save(fig,'figure3_allocation',source)

    source=[]; fig,axes=plt.subplots(1,2,figsize=(6.35,3.15))
    snaps=cases['snapshots']
    chosen=[next(r for r in snaps if r['case_id']==key and r['asof']=='2025-08-20' and r['mu']==0) for key in ['campbell','brandon']]
    for j,(field,color,name) in enumerate([('remaining_net_exposure_ceiling_tonnes',GRAY,'Remaining forecast'),
                                          ('net_exposure_ceiling_tonnes',TEAL,'Clause-conditioned ceiling')]):
        vals=[r[field]/next(c['nameplate_mw'] for c in cases['cases'] if c['case_id']==r['case_id']) for r in chosen]
        bars=axes[0].bar(np.arange(2)+(j-.5)*.3,vals,width=.28,color=color,label=name)
        axes[0].bar_label(bars,fmt='%.0f',padding=3,fontsize=7.5)
        source += [dict(panel='2025_per_mw',case=r['case_id'],asof=r['asof'],measure=field,value=v,unit='tCO2/MW') for r,v in zip(chosen,vals)]
    axes[0].set_xticks([0,1],['Campbell','Brandon\nShores']); axes[0].set_ylabel('2025 exposure ceiling (tCO$_2$/MW)')
    axes[0].set_ylim(0,2200)
    axes[0].legend(frameon=False,fontsize=7,loc='upper right')
    rush=[next(r for r in snaps if r['case_id']=='rush' and r['asof']==d and r['mu']==0) for d in ['2024-05-31','2024-09-05']]
    for j,(field,color,name) in enumerate([('remaining_forecast_tonnes',GRAY,'Year-end forecast'),
                                          ('net_exposure_ceiling_tonnes',TEAL,'Boiler-deadline window'),
                                          ('actual',GOLD,'Observed remaining')]):
        vals=[(r['observed_remaining']['co2_tonnes'] if field=='actual' else r[field])/1000 for r in rush]
        bars=axes[1].bar(np.arange(2)+(j-1)*.24,vals,width=.22,color=color,label=name)
        axes[1].bar_label(bars,fmt='%.0f',padding=3,fontsize=7.5)
        source += [dict(panel='rush',asof=r['asof'],measure=field,value=v,unit='ktCO2') for r,v in zip(rush,vals)]
    axes[1].set_xticks([0,1],['31 May','5 September']); axes[1].set_ylabel('2024 remaining CO$_2$ (kt)'); axes[1].set_ylim(0,640)
    axes[1].legend(frameon=False,fontsize=7,loc='upper right')
    label(axes[0],'a','Availability and contract release'); label(axes[1],'b','Rush Island operating deadline')
    fig.subplots_adjust(left=.105,right=.98,bottom=.2,top=.85,wspace=.51)
    save(fig,'figure4_windows',source)

    rows=[]
    for mode,name in zip(MODES,MODE_LABELS):
        st=support(a,mode,'all'); ex=support(a,mode,'recorded_outcome_exit')
        rows.append(f"{name} & {st['net_supported']['rows']} & {st['carbon_supported']['rows']} & {st['paired_supported']['rows']} & {st['paired_supported']['units']} & {ex['paired_supported']['rows']} \\\\")
    (DEST/'support_rows.tex').write_text('\n'.join(rows)+'\n\\bottomrule\n',encoding='utf-8')
    rows=[]
    for mode,name in zip(MODES,MODE_LABELS):
        for stratum,short in [('all','All'),('recorded_outcome_exit','Recorded exit'),('no_recorded_outcome_exit','No recorded exit')]:
            e=error(a,mode,'co2_tonnes',stratum)
            rows.append(f"{name} & {short} & {e['rows']} & {100*e['rules']['updated_recent']['wape']:.2f} & {100*e['rules']['persistence']['wape']:.2f} \\\\")
    (DEST/'error_rows.tex').write_text('\n'.join(rows)+'\n\\bottomrule\n',encoding='utf-8')
    rows=[]
    for c in s['central']:
        rows.append(str(c['year'])+' & '+str(c['n'])+' & '+' & '.join(f"{c['methods'][m]['observed_regret_mt']:.3f}" for m in RULE_NAMES)+' \\\\')
    (DEST/'central_rows.tex').write_text('\n'.join(rows)+'\n\\bottomrule\n',encoding='utf-8')
    names={'updated_recent_median':'Updated-date median','updated_recent_calibrated_regret':'Updated-date error stress',
           'persistence_median':'Persistence median','persistence_calibrated_regret':'Persistence error stress'}
    rows=[]
    for method,name in names.items():
        vs=s['calibrated_comparisons'][method]
        rows.append(name+' & '+' & '.join('/'.join(str(vs[b][k]) for k in ['lower','higher','ties']) for b in ['updated_recent','persistence','minimax_regret'])+' \\\\')
    (DEST/'calibration_rows.tex').write_text('\n'.join(rows)+'\n\\bottomrule\n',encoding='utf-8')
    write(OUT/'display_manifest.json',{'files':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(DEST.iterdir()) if p.suffix in ['.pdf','.tex']},'macros':macros})
    print(json.dumps(macros,indent=2))


RULE_NAMES=['initial_older','updated_recent','persistence','minimax_regret']
if __name__=='__main__': main()
