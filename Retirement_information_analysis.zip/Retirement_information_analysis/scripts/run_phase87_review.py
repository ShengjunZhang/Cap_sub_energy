"""Frozen concealed-plan replay; operating outcomes enter evaluation only."""
import argparse
import json
import math
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from scripts.run_phase84_support import read, write, digest, write_csv
from scripts.run_phase86_margins import preserved as previous_preserved
from transition_assets.phase87_review import exposure_bounds, interval_regret, review_path, next_record

RAW = ROOT/'data/raw/phase87'; OUT = ROOT/'data/processed/phase87'
PRODUCTS = ['paths.json', 'budgets.csv', 'summary.json']


def freeze():
    if (RAW/'inputs.json').exists():
        raise ValueError('Phase87 specification is already frozen')
    previous_preserved()
    names = set(read(ROOT/'data/raw/phase86/inputs.json')['files'])
    for folder in ['data/raw/phase86', 'data/processed/phase86', 'outputs/phase86',
                   'manuscript/omega_v4', 'delivery/omega_v4_author_review_20261010']:
        names.update(p.relative_to(ROOT).as_posix() for p in (ROOT/folder).rglob('*') if p.is_file())
    names.update(['data/raw/phase87/contract.json', 'tests/fixtures/phase87_review.json',
                  'transition_assets/phase86_margins.py', 'scripts/run_phase86_margins.py',
                  'transition_assets/phase85_solver_v2.py'])
    write(RAW/'inputs.json', dict(files={n: digest(ROOT/n) for n in sorted(names)}))
    print('Frozen files:', len(names), flush=True)


def preserved():
    names = read(RAW/'inputs.json')['files']
    for p, h in names.items():
        if digest(ROOT/p) != h:
            raise ValueError('Inherited file changed: '+p)
    if (RAW/'amendment_inputs.json').exists():
        for p,h in read(RAW/'amendment_inputs.json')['files'].items():
            if digest(ROOT/p)!=h: raise ValueError('Frozen replay amendment changed: '+p)
    return len(names)


def bounds(case):
    k = np.array(case['capacities']); forecasts = np.array(case['forecast_values_mt'])
    h = forecasts[4]+case['q']*k/1e6
    return exposure_bounds(h, k, case['q'])


def comparison(paths, policy, comparator, field, fraction):
    a = [p for p in paths if p['policy'] == policy]
    changes = []
    for p in a:
        case_id = tuple(p[k] for k in ['year', 'mu', 'q', 'fraction'])
        peers = [v for v in paths if tuple(v[k] for k in ['year','mu','q','fraction']) == case_id
                 and v['policy'] == comparator]
        def metric(v):
            return next(r[field] for r in v['budgets'] if r['review_fraction'] == fraction)
        changes.append(float(np.mean([metric(v) for v in peers]))-metric(p))
    d = np.array(changes); tol = 1e-7
    return dict(n=len(d), lower=int((d > tol).sum()), higher=int((d < -tol).sum()),
                ties=int((abs(d) <= tol).sum()), mean_improvement=float(d.mean()))


def make_summary(paths, contract):
    summary = dict(settings=contract['expected_settings'], paths=len(paths), policies={}, comparisons={})
    for policy in contract['policies']:
        group = [p for p in paths if p['policy'] == policy]
        summary['policies'][policy] = dict(paths=len(group),
            median_queries_to_stop=float(np.median([p['queries_to_stop'] for p in group])),
            mean_review_share=float(np.mean([p['queries_to_stop']/p['n'] for p in group])),
            median_review_share=float(np.median([p['queries_to_stop']/p['n'] for p in group])),
            stops_without_query=sum(p['queries_to_stop'] == 0 for p in group))
        summary['policies'][policy]['budget_means'] = [dict(review_fraction=f,
            observed_loss_mt=float(np.mean([r['observed_loss_mt'] for p in group for r in p['budgets'] if r['review_fraction']==f])),
            updated_forecast_loss_mt=float(np.mean([r['updated_forecast_loss_mt'] for p in group for r in p['budgets'] if r['review_fraction']==f])),
            regret_upper_mt=float(np.mean([r['regret_upper_mt'] for p in group for r in p['budgets'] if r['review_fraction']==f])))
            for f in contract['budget_fractions']]
    for comparator in ['interval_width', 'capacity', 'initial_disagreement', 'random']:
        summary['comparisons'][comparator] = {str(f): {
            field: comparison(paths, 'exchange_width', comparator, field, f)
            for field in ['updated_forecast_loss_mt','observed_loss_mt','regret_upper_mt']}
            for f in [.1, .25, .5]}
    summary['central_paths'] = [p for p in paths if p['policy'] != 'random'
        and all(p[k] == v for k,v in contract['central'].items())]
    summary['certificates_with_actual_loss'] = sum(
        p['states'][-1]['observed_loss_mt'] > 1e-7 for p in paths if p['policy']=='exchange_width')
    summary['actual_loss_increases_after_a_query'] = sum(any(
        b['observed_loss_mt'] > a['observed_loss_mt']+1e-7
        for a,b in zip(p['states'],p['states'][1:])) for p in paths if p['policy']=='exchange_width')
    summary['interpretation'] = contract['interpretation']
    return summary


def run():
    preserved(); c = read(RAW/'contract.json'); annual = read(ROOT/c['annual_input'])
    if len(annual) != c['expected_settings']:
        raise ValueError('Annual settings differ')
    paths = []; csv = []
    for count, case in enumerate(annual, 1):
        forecasts = np.array(case['forecast_values_mt']); initial = forecasts[c['start_rule_index']]
        updated = forecasts[c['reveal_rule_index']]; k = np.array(case['capacities'])
        lo, hi = bounds(case)
        if np.any(updated < lo-1e-9) or np.any(updated > hi+1e-9):
            raise ValueError('Updated forecast outside plan-exposure bounds')
        disagreement = abs(forecasts[0]-initial)
        cache = {'nominal': {}, 'separation': {}}
        for policy in c['policies']:
            seeds = c['random_seeds'] if policy == 'random' else [8700]
            for seed in seeds:
                p = review_path(initial, lo, hi, k, case['limit_mw'],
                    lambda i: updated[i], policy, disagreement, seed,
                    c['certificate_tolerance_mt'], cache)
                if p['maximum_absolute_solver_gap_mt'] > c['solver_absolute_acceptance_mt']:
                    raise ValueError('Review solver gap exceeds frozen acceptance')
                # The policy has returned its entire path before outcomes are accessed.
                actual = np.array(case['observed_values_mt'])
                target_value = case['methods']['updated_recent']['scenario_values_mt'][3]
                for s in p['states']:
                    x = np.array(s['x'])
                    s['updated_forecast_loss_mt'] = max(0., float(target_value-updated@x))
                    s['observed_loss_mt'] = max(0., float(case['reference_value_mt']-actual@x))
                p.update({t:case[t] for t in ['year','mu','q','fraction','n','keys']})
                p['queried_keys'] = [case['keys'][i] for i in p['queried_indices']]
                p['budgets'] = []
                for f in c['budget_fractions']:
                    allowed = math.ceil(f*case['n']); s = p['states'][min(allowed, p['queries_to_stop'])]
                    row = dict(review_fraction=f, allowed_queries=allowed, used_queries=s['queries'],
                        updated_forecast_loss_mt=s['updated_forecast_loss_mt'],
                        observed_loss_mt=s['observed_loss_mt'], regret_upper_mt=s['regret_upper'])
                    p['budgets'].append(row)
                    csv.append({**{t:p[t] for t in ['year','mu','q','fraction','policy','seed','n']}, **row})
                paths.append(p)
        if count%27 == 0:
            print('Settings:',count,'paths:',len(paths),flush=True)
    write(OUT/'paths.json', paths); write_csv(OUT/'budgets.csv',csv)
    summary = make_summary(paths,c); write(OUT/'summary.json',summary)
    verify()
    print(json.dumps({k:summary[k] for k in ['policies','certificates_with_actual_loss',
          'actual_loss_increases_after_a_query']},indent=2),flush=True)


def verify():
    frozen = preserved(); c = read(RAW/'contract.json'); paths = read(OUT/'paths.json')
    annual = read(ROOT/c['annual_input']); byid = {tuple(a[k] for k in ['year','mu','q','fraction']):a for a in annual}
    if len(paths) != 108*(4+len(c['random_seeds'])):
        raise ValueError('Incomplete review comparisons')
    checks=0; max_stop_loss=0.; max_bound_excess=0.; nominal_cache={}
    for p in paths:
        case = byid[tuple(p[k] for k in ['year','mu','q','fraction'])]
        forecasts=np.array(case['forecast_values_mt']); updated=forecasts[3]; k=np.array(case['capacities'])
        initial=forecasts[2].copy(); actual=np.array(case['observed_values_mt']); lo,hi=bounds(case)
        reviewed=set(); target=case['methods']['updated_recent']['scenario_values_mt'][3]
        disagreement=abs(forecasts[0]-forecasts[2])
        random_order=np.random.default_rng(p['seed'] if p['seed'] is not None else 8700).permutation(len(k)).tolist()
        checkpoints={min(math.ceil(f*case['n']),p['queries_to_stop']) for f in c['budget_fractions']}
        for step,s in enumerate(p['states']):
            if step:
                i=p['queried_indices'][step-1]
                if i in reviewed: raise ValueError('Repeated query')
                previous=p['states'][step-1]
                available={j for j in range(len(k)) if j not in reviewed and hi[j]-lo[j]>1e-12
                           and k[j]<=case['limit_mw']+1e-6}
                expected=next_record(p['policy'],lo,hi,k,previous['x'],previous['witness'],
                                     available,disagreement,random_order)
                if i!=expected: raise ValueError('Stored query violates visible-information priority')
                reviewed.add(i); initial[i]=updated[i]; lo[i]=hi[i]=updated[i]
            x=np.array(s['x']); z=np.array(s['witness'])
            if not np.all((x==0)|(x==1)) or k@x > case['limit_mw']+1e-6:
                raise ValueError('Infeasible review selection')
            witness_value=float(sum(hi[i] if z[i]-x[i]==1 else -lo[i]
                                    if z[i]-x[i]==-1 else 0. for i in range(len(k))))
            np.testing.assert_allclose(witness_value,s['regret_bound'],atol=1e-7)
            np.testing.assert_allclose(initial@x,s['forecast_value'],atol=1e-8)
            np.testing.assert_allclose(max(0.,target-updated@x),s['updated_forecast_loss_mt'],atol=1e-8)
            np.testing.assert_allclose(max(0.,case['reference_value_mt']-actual@x),s['observed_loss_mt'],atol=1e-8)
            if s['updated_forecast_loss_mt'] > s['regret_upper']+1e-7:
                raise ValueError('Updated-forecast regret exceeds valid interval bound')
            max_bound_excess=max(max_bound_excess,s['updated_forecast_loss_mt']-s['regret_upper'])
            checks+=6
            if step in checkpoints:
                cachekey=(case['year'],case['mu'],case['q'],case['fraction'],initial.tobytes(),tuple(x))
                if cachekey not in nominal_cache:
                    nominal_cache[cachekey]=interval_regret(initial,initial,k,case['limit_mw'],x)
                if nominal_cache[cachekey]['upper']>1e-7:
                    raise ValueError('Checkpoint selection is not a nominal optimum within tolerance')
                checks+=1
        final=p['states'][-1]; max_stop_loss=max(max_stop_loss,final['updated_forecast_loss_mt'])
        if final['regret_upper'] > c['certificate_tolerance_mt'] or final['updated_forecast_loss_mt'] > 1e-7:
            raise ValueError('Invalid forecast stopping condition')
        # Recompute final interval separation rather than accepting stored witnesses alone.
        sep=interval_regret(lo,hi,k,case['limit_mw'],final['x'])
        if sep['upper'] > 1e-7: raise ValueError('Independent final separation failed')
        checks+=2
    write(OUT/'verification.json',dict(status='pass',checks=checks,protected_files=frozen,
        maximum_forecast_loss_at_stop_mt=max_stop_loss, maximum_bound_excess_mt=max_bound_excess))
    print('Verified:',checks,'checks;',frozen,'unchanged files',flush=True)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--mode',
        choices=['freeze','run','verify','reproduce'],default='run'); mode=parser.parse_args().mode
    if mode == 'freeze': freeze()
    elif mode == 'verify': verify()
    elif mode == 'reproduce':
        before={p:digest(OUT/p) for p in PRODUCTS}; run()
        after={p:digest(OUT/p) for p in PRODUCTS}
        if before!=after: raise ValueError('Scientific replay changed on repeat')
        write(OUT/'reproduction.json',dict(status='pass',sha256=after))
    else: run()
