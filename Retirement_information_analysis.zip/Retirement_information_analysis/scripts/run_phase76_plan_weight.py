"""One post-hoc, calendar-ordered retirement-plan weight experiment."""
import argparse
from collections import Counter
from datetime import date, timedelta
import hashlib
import json
import math
from pathlib import Path
import platform
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts import run_phase73_decisions as decision

RAW = ROOT / 'data/raw/phase76'
OUT = ROOT / 'data/processed/phase76'
RULES = decision.RULES + ['blend']
COMPARATORS = ['persistence', 'updated_recent']


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n', encoding='utf-8')


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def freeze():
    prior = read(ROOT/'data/raw/ere_v5_2/inputs.json')
    for r in prior:
        if sha(ROOT/r['path']) != r['sha256']:
            raise ValueError('Inherited input changed: '+r['path'])
    names = {r['path'] for r in prior}
    for folder in ['manuscript/ere_v5_2', 'author_review_ere_v5_2_2026-09-29',
                   'data/processed/phase71', 'data/processed/phase73', 'data/raw/phase73']:
        names.update(p.relative_to(ROOT).as_posix() for p in (ROOT/folder).rglob('*')
                     if p.is_file() and '__pycache__' not in p.parts)
    names.update(['data/raw/phase76/contract.json', 'tests/fixtures/phase76_plan_weight.json',
                  'scripts/run_phase71_baselines.py', 'scripts/run_phase73_decisions.py'])
    rows = [dict(path=n, sha256=sha(ROOT/n)) for n in sorted(names)]
    target = RAW/'inputs.json'
    if target.exists() and read(target) != rows:
        raise ValueError('Cannot revise frozen input manifest')
    write(target, rows)
    return len(rows)


def check_lock():
    rows = read(RAW/'inputs.json')
    for r in rows:
        if sha(ROOT/r['path']) != r['sha256']:
            raise ValueError('Protected file changed: '+r['path'])
    return len(rows)


def blend(p, u, weight):
    if not math.isfinite(weight) or not 0 <= weight <= 1:
        raise ValueError('Weight outside [0,1]')
    return np.asarray(p) + weight*(np.asarray(u)-np.asarray(p))


def fit_weight(p, u, actual, multiplicity=None):
    p, u, y = (np.asarray(x, dtype=float) for x in (p, u, actual))
    if p.ndim != 1 or p.shape != u.shape or p.shape != y.shape or not len(p):
        raise ValueError('Nonempty, equally shaped vectors required')
    w = np.ones(len(p)) if multiplicity is None else np.asarray(multiplicity, dtype=float)
    if w.shape != p.shape or not np.all(np.isfinite([p, u, y, w])) or np.any(w < 0) or w.sum() <= 0:
        raise ValueError('Invalid observations or weights')
    d = u-p
    active = (d != 0) & (w > 0)
    if not active.any():
        return dict(weight=0., interval=[0., 1.], identified=False,
                    objective_mae=float(w@np.abs(p-y)/w.sum()), active_rows=0)
    # Absolute loss is a weighted absolute-distance objective in lambda.
    # Its minimizers are the weighted-median interval, clipped to [0,1].
    z = (y[active]-p[active])/d[active]
    a = w[active]*np.abs(d[active])
    order = np.argsort(z, kind='stable')
    z, a = z[order], a[order]
    cumulative = np.cumsum(a)
    half = a.sum()/2
    tol = 1e-12*a.sum()
    lo = int(np.flatnonzero(cumulative >= half-tol)[0])
    above = np.flatnonzero(cumulative > half+tol)
    hi = int(above[0]) if len(above) else len(z)-1
    lower, upper = np.clip([z[lo], z[hi]], 0, 1).tolist()
    return dict(weight=float(lower), interval=[float(lower), float(upper)], identified=True,
                objective_mae=float(w@np.abs(blend(p, u, lower)-y)/w.sum()),
                active_rows=int(active.sum()))


def split_rows(rows):
    keys = [(r['key'], r['year']) for r in rows]
    if len(keys) != len(set(keys)):
        raise ValueError('Duplicate unit-origin')
    if any(r['outcome_year'] not in [2021, 2022, 2023, 2024, 2025] for r in rows):
        raise ValueError('Unapproved outcome year')
    for r in rows:
        if r['year']+1 != r['outcome_year'] or r['origin'] != str(r['year'])+'-12-31':
            raise ValueError('Time alignment mismatch')
    return ([r for r in rows if r['outcome_year'] <= 2022],
            [r for r in rows if r['outcome_year'] >= 2023])


def fit_training(rows, multiplicity=None):
    if any(r['outcome_year'] not in [2021, 2022] for r in rows):
        raise ValueError('Test outcome in training')
    return fit_weight([r['forecasts']['persistence'] for r in rows],
                      [r['forecasts']['updated_recent'] for r in rows],
                      [r['actual'] for r in rows], multiplicity)


def exposure_hours(outcome_year, plan):
    stop = date.fromisoformat(plan)+timedelta(days=1)
    start, end = date(outcome_year, 1, 1), date(outcome_year+1, 1, 1)
    return max(0, (min(end, stop)-start).days)*24


def groups(rows):
    return dict(all=rows, date_active=[r for r in rows if r['hours1'] < r['full_hours']],
                **{'year_'+str(y): [r for r in rows if r['outcome_year'] == y]
                   for y in [2023, 2024, 2025]})


def metrics(prediction, actual, capacity):
    p, y, k = (np.asarray(x, dtype=float) for x in (prediction, actual, capacity))
    if not len(y):
        return dict(n=0, mae=None, wape=None, bias=None, mae_per_mw=None)
    error = p-y
    denom = np.abs(y).sum()
    return dict(n=len(y), mae=float(np.abs(error).mean()),
                wape=float(np.abs(error).sum()/denom) if denom else None,
                bias=float(error.sum()), mae_per_mw=float(np.mean(np.abs(error)/k)))


def predictions(rows, weight):
    p = {b: np.array([r['forecasts'][b] for r in rows]) for b in decision.RULES}
    p['blend'] = blend(p['persistence'], p['updated_recent'], weight)
    return p


def prediction_summary(rows, weight):
    result = {}
    for name, rr in groups(rows).items():
        actual = np.array([r['actual'] for r in rr])
        capacity = np.array([r['capacity_mw'] for r in rr])
        result[name] = {b: metrics(p, actual, capacity) for b, p in predictions(rr, weight).items()}
    return result


def cluster_draws(rows, draws, seed):
    plants = sorted({r['plant'] for r in rows})
    rng = np.random.default_rng(seed)
    return plants, rng.multinomial(len(plants), np.ones(len(plants))/len(plants), size=draws)


def load_inputs():
    c = read(RAW/'contract.json')
    return (read(ROOT/c['net_panel']), read(ROOT/c['carbon_panel']),
            read(ROOT/c['coverage']), read(ROOT/c['carbon_coverage']))


def audit(net, carbon, coverage, carbon_coverage):
    train, test = split_rows(net)
    split_rows(carbon)
    ci = {(r['key'], r['year']): r for r in carbon}
    mi = {(r['key'], r['year']): r for r in carbon_coverage}
    gi = {(r['key'], r['year']): r for r in net}
    active_rows = []
    for r in net+carbon:
        full = exposure_hours(r['outcome_year'], str(r['outcome_year'])+'-12-31')
        h0 = exposure_hours(r['outcome_year'], r['initial_plan'])
        h1 = exposure_hours(r['outcome_year'], r['current_plan'])
        if [full, h0, h1] != [r['full_hours'], r['hours0'], r['hours1']]:
            raise ValueError('Exposure mismatch: '+r['key'])
        expected = dict(initial_older=r['rate0']*h0, updated_older=r['rate0']*h1,
                        initial_recent=r['rate1']*h0, updated_recent=r['rate1']*h1,
                        persistence=r['rate1']*full)
        for b, value in expected.items():
            if not math.isclose(value, r['forecasts'][b], rel_tol=1e-12, abs_tol=1e-6):
                raise ValueError('Forecast mismatch')
    for r in net:
        if r['operating_years'] != [r['year']-1, r['year']]:
            raise ValueError('Future operation used as input')
        if r['hours1'] == r['full_hours']:
            if r['forecasts']['persistence'] != r['forecasts']['updated_recent']:
                raise ValueError('Inactive forecasts differ')
            continue
        item = {k: r[k] for k in ['key', 'year', 'outcome_year', 'origin', 'plant', 'name',
                'state', 'fuel', 'capacity_mw', 'current_plan', 'initial_plan', 'hours1',
                'full_hours', 'coverage', 'historical_event', 'outcome_exit', 'plan_sources',
                'generation_sources', 'actual', 'rate1']}
        p, u = (r['forecasts'][b] for b in ['persistence', 'updated_recent'])
        item.update(split='train' if r['outcome_year'] <= 2022 else 'test',
                    persistence=p, updated_recent=u, forecast_difference=u-p,
                    month_end=date.fromisoformat(r['current_plan']).month !=
                    (date.fromisoformat(r['current_plan'])+timedelta(days=1)).month,
                    carbon_included=(r['key'], r['year']) in ci,
                    carbon_status=mi[(r['key'], r['year'])]['status'])
        if not item['month_end']:
            raise ValueError('Planned date is not month-end')
        active_rows.append(item)
    ledgers = []
    for r in coverage:
        plan = r['current_plan']
        a = (None if not plan else exposure_hours(r['outcome_year'], plan) <
             exposure_hours(r['outcome_year'], str(r['outcome_year'])+'-12-31'))
        ledgers.append(dict(key=r['key'], year=r['year'], outcome_year=r['outcome_year'],
                            split='train' if r['outcome_year'] <= 2022 else 'test',
                            date_active=a, included=(r['key'], r['year']) in gi,
                            status=r['status'], outcome_exit=r['outcome_exit'],
                            coverage=r.get('coverage', {})))
    summary = {}
    for name, rows in [('all', net), ('train', train), ('test', test), ('carbon', carbon)]:
        aa = [r for r in rows if r['hours1'] < r['full_hours']]
        plant_leverage = Counter()
        for r in aa:
            plant_leverage[r['plant']] += abs(r['forecasts']['updated_recent']-r['forecasts']['persistence'])
        total = sum(plant_leverage.values())
        summary[name] = dict(n=len(rows), plants=len({r['plant'] for r in rows}),
                             date_active=len(aa), active_plants=len(plant_leverage),
                             different_predictions=sum(r['forecasts']['updated_recent'] !=
                                 r['forecasts']['persistence'] for r in rows),
                             identifying_plants=sum(v > 0 for v in plant_leverage.values()),
                             outcome_year_counts=dict(Counter(str(r['outcome_year']) for r in rows)),
                             active_year_counts=dict(Counter(str(r['outcome_year']) for r in aa)),
                             forecast_leverage=[dict(plant=p, absolute_shift=v,
                                share=v/total if total else None) for p, v in plant_leverage.most_common()])
    missing = {}
    for split in ['train', 'test']:
        for group in ['all', 'date_active']:
            rr = [r for r in ledgers if r['split'] == split and
                  (group == 'all' or r['date_active'] is True)]
            missing[split+'_'+group] = dict(n=len(rr), included=sum(r['included'] for r in rr),
                excluded_status=dict(Counter(r['status'] for r in rr if not r['included'])),
                recorded_exits=sum(r['outcome_exit'] for r in rr),
                included_exits=sum(r['outcome_exit'] and r['included'] for r in rr))
    return dict(summary=summary, missingness=missing, active_rows=active_rows,
                coverage_ledger=ledgers, prior_comparison_status='post-hoc; not blind')


def decision_arrays(rows, weight, mu):
    p, obs, k = decision.arrays(rows, mu)
    p['blend'] = blend(p['persistence'], p['updated_recent'], weight)
    return p, obs, k


def comparison_targets(net_test, carbon_test, paired_test, economic, plants):
    targets = []
    for kind, rows in [('generation', net_test), ('carbon', carbon_test)]:
        for name, rr in groups(rows).items():
            targets.append(dict(id=kind+'/'+name, kind='prediction',
                indices=np.array([plants.index(r['plant']) for r in rr], dtype=int),
                p=np.array([r['forecasts']['persistence'] for r in rr]),
                u=np.array([r['forecasts']['updated_recent'] for r in rr]),
                y=np.array([r['actual'] for r in rr]), k=np.ones(len(rr))))
    for mu in economic['uncertainty_mu']:
        for q in economic['uncertainty_q']:
            for name, rr in groups(paired_test).items():
                pp, obs, k = decision_arrays(rr, 0, mu)
                targets.append(dict(id=f'decision/{name}/mu{mu:g}/q{q:g}', kind='decision',
                    indices=np.array([plants.index(r['plant']) for r in rr], dtype=int),
                    p=pp['persistence'], u=pp['updated_recent'], y=obs, k=k, q=q))
    return targets


def improvements(targets, weight, multiplicities):
    result = {}
    for t in targets:
        w = multiplicities[t['indices']]*t['k']
        if w.sum() == 0:
            result[t['id']] = {b: None for b in COMPARATORS}
            continue
        bp = blend(t['p'], t['u'], weight)
        if t['kind'] == 'prediction':
            fitted = np.abs(bp-t['y'])
            losses = [np.abs(p-t['y']) for p in [t['p'], t['u']]]
        else:
            fitted = decision.loss(bp, t['y'], t['q'])
            losses = [decision.loss(p, t['y'], t['q']) for p in [t['p'], t['u']]]
        result[t['id']] = {b: float(w@(err-fitted)/w.sum())
                           for b, err in zip(COMPARATORS, losses)}
    return result


def resample(training, net_test, carbon_test, paired_test, fitted, economic, contract):
    plants, draws = cluster_draws(training+net_test, contract['draws'], contract['seed'])
    train_ids = np.array([plants.index(r['plant']) for r in training], dtype=int)
    targets = comparison_targets(net_test, carbon_test, paired_test, economic, plants)
    point = improvements(targets, fitted['weight'], np.ones(len(plants)))
    samples = {t['id']: {b: [] for b in COMPARATORS} for t in targets}
    fit_draws = []
    for number, counts in enumerate(draws):
        counts = counts.astype(float)
        if counts[train_ids].sum() == 0:
            fit_draws.append(dict(draw=number, valid=False, reason='empty_training'))
            continue
        fit = fit_training(training, counts[train_ids])
        values = improvements(targets, fit['weight'], counts)
        fit_draws.append(dict(draw=number, valid=True, weight=fit['weight'],
                              interval=fit['interval'], identified=fit['identified']))
        for name, comps in values.items():
            for b, value in comps.items():
                if value is not None:
                    samples[name][b].append(value)
    intervals = []
    for name, comps in samples.items():
        for b, values in comps.items():
            intervals.append(dict(target=name, comparator=b, improvement=point[name][b],
                valid_draws=len(values), invalid_or_empty_draws=contract['draws']-len(values),
                ci95=np.percentile(values, [2.5, 97.5]).tolist() if values else None))
    lopo = []
    for i, plant in enumerate(plants):
        counts = np.ones(len(plants)); counts[i] = 0
        if counts[train_ids].sum() == 0:
            lopo.append(dict(plant=plant, valid=False, reason='empty_training'))
            continue
        fit = fit_training(training, counts[train_ids])
        lopo.append(dict(plant=plant, valid=True, fit=fit,
                         improvements=improvements(targets, fit['weight'], counts)))
    valid = [r for r in fit_draws if r['valid']]
    weights = [r['weight'] for r in valid]
    uncertainty = dict(plants=plants, draws=fit_draws, comparisons=intervals,
        weight_summary=dict(valid=len(valid), unidentified=sum(not r['identified'] for r in valid),
            at_zero=sum(r['weight'] == 0 for r in valid), at_one=sum(r['weight'] == 1 for r in valid),
            percentiles=np.percentile(weights, [0, 2.5, 25, 50, 75, 97.5, 100]).tolist()),
        interval_status='pointwise exploratory; joint training/test plant resampling with refit')
    return uncertainty, lopo


def calculate():
    contract = read(RAW/'contract.json')
    economic = read(ROOT/contract['decision_contract'])
    net, carbon, coverage, carbon_coverage = load_inputs()
    checked = audit(net, carbon, coverage, carbon_coverage)
    training, test = split_rows(net)
    _, carbon_test = split_rows(carbon)
    fit = fit_training(training)
    weight = fit['weight']
    fit.update(training_years=[2021, 2022], test_years=[2023, 2024, 2025],
               training_rows=len(training), test_rows=len(test),
               test_outcomes_used_for_fit=False)
    rows, ledger = decision.pair_panels(net, carbon)
    expected = read(ROOT/'data/processed/phase73/panel.json')
    if rows != expected:
        raise ValueError('Inherited appraisal pairing changed')
    checked['decision_pairing'] = ledger
    paired = [r.copy() for r in rows if r['outcome_year'] in [2023, 2024, 2025]]
    net_index = {(r['key'], r['year']): r for r in net}
    for r in paired:
        source = net_index[(r['key'], r['year'])]
        r.update(hours1=source['hours1'], full_hours=source['full_hours'])
    points, frontiers = [], []
    for mu in economic['replacement_intensity_t_per_mwh']:
        for group, rr in groups(paired).items():
            if not rr:
                continue
            p, obs, k = decision_arrays(rr, weight, mu)
            f = decision.frontier(p, obs, k)
            f.update(mu=mu, group=group, n=len(rr),
                     beyond_last='all rules choose no intervention; loss=0')
            frontiers.append(f)
            if mu in economic['uncertainty_mu']:
                for q in economic['uncertainty_q']:
                    points.append(dict(mu=mu, q=q, group=group, n=len(rr),
                        rules={b: decision.summarize(v, obs, k, q) for b, v in p.items()}))
    predicted_rows = []
    for kind, rows0 in [('generation', test), ('carbon', carbon_test)]:
        for r in rows0:
            f = r['forecasts']
            predicted_rows.append(dict(kind=kind, key=r['key'], year=r['year'],
                outcome_year=r['outcome_year'], plant=r['plant'], actual=r['actual'],
                date_active=r['hours1'] < r['full_hours'],
                forecasts=dict(f, blend=float(blend(f['persistence'], f['updated_recent'], weight)))))
    uncertainty, influence = resample(training, test, carbon_test, paired, fit, economic,
                                     contract['bootstrap'])
    return dict(audit=checked, fit=fit, predictions=predicted_rows,
                prediction_metrics=dict(generation=prediction_summary(test, weight),
                                        carbon=prediction_summary(carbon_test, weight)),
                decision_panel=paired, decision_points=points, decision_frontiers=frontiers,
                uncertainty=uncertainty, influence=influence)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', required=True, choices=['freeze', 'audit', 'run', 'verify'])
    args = parser.parse_args()
    if args.mode == 'freeze':
        print('Frozen files:', freeze()); return
    protected = check_lock()
    if args.mode == 'audit':
        result = audit(*load_inputs())
        write(ROOT/'outputs/phase76/pre_fit_audit.json', result)
        print(json.dumps(dict(summary=result['summary'], missingness=result['missingness']), indent=2))
        return
    products = calculate()
    for name, value in products.items():
        path = OUT/(name+'.json')
        if args.mode == 'verify':
            if read(path) != value:
                raise ValueError('Reproduction mismatch: '+name)
        else:
            if path.exists() and read(path) != value:
                raise ValueError('Refusing to overwrite differing results: '+name)
            write(path, value)
    if args.mode == 'run':
        write(ROOT/'outputs/phase76/environment.json', dict(python=platform.python_version(),
            numpy=np.__version__, platform=platform.platform(), protected_files=protected,
            script_sha256=sha(Path(__file__)), contract_sha256=sha(RAW/'contract.json')))
    print(json.dumps(dict(mode=args.mode, protected_files=protected, products=len(products),
                         fit=products['fit']), indent=2))


if __name__ == '__main__':
    main()
