"""Post-announcement exit associations from frozen existing records."""
import argparse
import calendar
from collections import Counter, defaultdict
import csv
from datetime import date
import hashlib
import json
import math
from pathlib import Path
import sys
import warnings

import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts.run_phase68_horizons import checkpoint_state, recorded_event, add_months
RAW = ROOT/'data/raw/phase70'
OUT = ROOT/'data/processed/phase70'

def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,v):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def freeze():
    c=read(RAW/'contract.json')
    names={c[k] for k in ('cohort','history','generation')}
    names.add('data/raw/phase70/contract.json')
    names.update(r['source'] for r in read(ROOT/c['history']))
    names.update(r['source'] for r in read(ROOT/c['generation']))
    names.update(r['path'] for r in read(ROOT/'data/raw/phase69/inputs.json'))
    for f in ('manuscript/ere_v2','author_review_ere_v2_2026-09-27'):
        names.update(p.relative_to(ROOT).as_posix() for p in (ROOT/f).rglob('*')
                     if p.is_file() and '__pycache__' not in p.parts)
    data=[{'path':p,'sha256':sha(ROOT/p)} for p in sorted(names)]
    lock=RAW/'inputs.json'
    if lock.exists() and read(lock)!=data: raise ValueError('Refusing to change frozen inputs')
    write(lock,data); print('Frozen files:',len(data))

def check_lock():
    rows=read(RAW/'inputs.json')
    for r in rows:
        if sha(ROOT/r['path'])!=r['sha256']: raise ValueError('Changed: '+r['path'])
    return len(rows)

def utilization(r,capacity):
    if r is None: return None,'no_generator_year'
    if r['duplicate']: return None,'duplicate'
    if r['frequency']!='M': return None,'not_monthly_frequency'
    if len(r['values'])!=12 or any(v is None or not math.isfinite(v) for v in r['values']):
        return None,'incomplete_months'
    if capacity<=0: raise ValueError('Nonpositive capacity')
    return math.fsum(r['values'])/(capacity*24*(366 if calendar.isleap(r['year']) else 365)),'complete'

def exit_outcome(retirement,origin,end,last_operating):
    if retirement:
        if retirement<=origin: return None
        return int(retirement<=end)
    return 0 if last_operating and last_operating>=end else None

def plan_transition(p0,p1,category,outcome):
    if outcome==1: return 'retired'
    if category=='plan_blank': return 'blank'
    if category not in {'plan_future','plan_due'}: return 'missing_or_unknown'
    if not p0 or not p1: return 'origin_plan_blank_or_invalid'
    return 'later' if p1>p0 else 'earlier' if p1<p0 else 'unchanged'

def region(state):
    regions={'Northeast':'CT ME MA NH RI VT NJ NY PA',
             'Midwest':'IN IL MI OH WI IA KS MN MO NE ND SD',
             'South':'DE DC FL GA MD NC SC VA WV AL KY MS TN AR LA OK TX',
             'West':'AZ CO ID MT NV NM UT WY AK CA HI OR WA'}
    for k,v in regions.items():
        if state in v.split(): return k
    raise ValueError('Unknown state: '+state)

def years(a,b): return (date.fromisoformat(a)-date.fromisoformat(b)).days/365.25

def build_panel(cohort,history,generation,contract):
    histories=defaultdict(list)
    for r in history: histories[r['key']].append(r)
    gm={}
    for g in generation:
        k=(g['plant']+':'+g['unit'],g['year'])
        if k in gm: raise ValueError('Duplicate processed year key')
        gm[k]=g
    snapshots=sorted({r['snapshot'] for r in history})
    panel=[]; excluded=[]
    for u in cohort:
        key=u['eia_plant_id']+':'+u['eia_generator_id']; hh=histories[key]
        ev=recorded_event(hh,contract['census'],contract['census'])
        retired=ev['date'] if ev['state']=='retired_by_checkpoint' else None
        operating=max((r['snapshot'] for r in hh if r['inventory']=='operating'),default=None)
        for year in contract['origins']:
            origin=f'{year}-12-31'
            if origin<u['first_plan_snapshot_date']: continue
            st=checkpoint_state(hh,snapshots,origin)
            reason=None
            if st['snapshot']!=origin or st['category'] not in {'plan_future','plan_due','plan_blank'}:
                reason='not_exact_operating_row'
            elif retired and retired<=origin: reason='retrospective_exit_already_occurred'
            if reason:
                excluded.append({'key':key,'origin':origin,'reason':reason}); continue
            cap=float(u['eligibility_nameplate_capacity_mw'])
            age=years(origin,u['commercial_operation_date']) if u['commercial_operation_date'] else None
            p=st['plan_date']
            row={'key':key,'plant':u['eia_plant_id'],'name':u['plant_name'],'origin':origin,'year':year,
                 'capacity_mw':cap,'age10':age/10 if age is not None else None,
                 'ln_mw':math.log(cap),'coal':int(u['fuel_group']=='coal'),
                 'region':region(u['plant_state']),'initial_plan':u['initial_planned_retirement_date'],
                 'elapsed':years(origin,u['initial_planned_retirement_date']),
                 'plan_lead':years(p,origin) if p else 0.,'blank_plan':int(not p),'current_plan':p,
                 'event_date':retired,'event_source':ev['source_snapshot'],'last_operating':operating,
                 'origin_sources':st['source_rows']}
            for lag,field in [(0,'util'),(1,'util_earlier')]:
                g=gm.get((key,year-lag)); v,status=utilization(g,cap)
                row[field]=v; row[field+'_status']=status
                row[field+'_source']={k:g[k] for k in ('source','member','sheet','row','year')} if g else None
            for h in (6,12,24):
                end=add_months(origin,h)
                row[f'exit{h}']=exit_outcome(retired,origin,end,operating) if end<=contract['census'] else None
            nxt=checkpoint_state(hh,snapshots,f'{year+1}-12-31')
            row['next_plan']=nxt['plan_date']; row['next_category']=nxt['category']
            row['transition']=plan_transition(p,nxt['plan_date'],nxt['category'],row['exit12'])
            panel.append(row)
    return panel,excluded

CONTROLS=['age10','ln_mw','coal','elapsed','plan_lead','blank_plan']
def design(rows,util=True,field='util'):
    d=pd.DataFrame(rows)
    x=d[CONTROLS].astype(float).copy()
    if util: x['util10']=d[field]/.1
    x=pd.concat([pd.DataFrame({'const':np.ones(len(d))}),x,
                 pd.get_dummies(d['year'].astype(str),prefix='year',drop_first=True,dtype=float),
                 pd.get_dummies(d['region'],prefix='region',drop_first=True,dtype=float)],axis=1)
    # Keep a deterministic full-rank basis; never select using outcome values.
    keep=[]; omitted=[]
    for col in x.columns:
        proposed=x[keep+[col]].to_numpy(float)
        if np.linalg.matrix_rank(proposed)==len(keep)+1: keep.append(col)
        else: omitted.append(col)
    return x[keep].to_numpy(float),keep,omitted

def clustered_lpm(x,y,groups):
    n,k=x.shape; labels=np.unique(groups); g=len(labels)
    if g<2 or n<=k or np.linalg.matrix_rank(x)!=k: raise ValueError('Insufficient rank/clusters')
    beta=np.linalg.lstsq(x,y,rcond=None)[0]; resid=y-x@beta
    bread=np.linalg.inv(x.T@x)
    scores=np.array([x[groups==v].T@resid[groups==v] for v in labels])
    cov=bread@(scores.T@scores)@bread*(g/(g-1))*((n-1)/(n-k))
    return {'coef':beta,'cov':cov,'fitted':x@beta,'groups':g}

def fit(rows,outcome='exit12',util=True,field='util',logit=False):
    x,names,omitted=design(rows,util,field)
    y=np.array([r[outcome] for r in rows],float); groups=np.array([r['plant'] for r in rows])
    g=len(np.unique(groups)); crit=stats.t.ppf(.975,g-1)
    with warnings.catch_warnings(record=True) as ws:
        warnings.simplefilter('always')
        if logit:
            m=sm.GLM(y,x,family=sm.families.Binomial()).fit(maxiter=200,tol=1e-10,
                cov_type='cluster',cov_kwds={'groups':groups},use_t=True)
            beta=np.asarray(m.params); cov=np.asarray(m.cov_params()); pred=np.asarray(m.predict(x))
            if not m.converged or np.max(np.abs(beta))>30: raise ValueError('Logit convergence/separation diagnostic')
        else:
            manual=clustered_lpm(x,y,groups)
            beta=manual['coef']; cov=manual['cov']; pred=manual['fitted']
            m=sm.OLS(y,x).fit(cov_type='cluster',cov_kwds={'groups':groups},use_t=True)
            np.testing.assert_allclose(beta,m.params,atol=1e-9,rtol=1e-8)
            np.testing.assert_allclose(cov,m.cov_params(),atol=1e-9,rtol=1e-8)
    se=np.sqrt(np.maximum(np.diag(cov),0))
    coefs={n:{'estimate':float(b),'se':float(s),'lower':float(b-crit*s),'upper':float(b+crit*s),
              'p':float(2*stats.t.sf(abs(b/s),g-1)) if s else None} for n,b,s in zip(names,beta,se)}
    result={'n':len(rows),'units':len({r['key'] for r in rows}),'plants':g,'events':int(y.sum()),
            'coefficients':coefs,'omitted':omitted,'rank':len(names),'condition':float(np.linalg.cond(x)),
            'fitted_range':[float(pred.min()),float(pred.max())],
            'outside_unit_interval':int(((pred<0)|(pred>1)).sum()),'warnings':[str(w.message) for w in ws]}
    if util and 'util10' in names:
        j=names.index('util10')
        if logit:
            w=pred*(1-pred); ame=beta[j]*w.mean()
            grad=beta[j]*np.mean((w*(1-2*pred))[:,None]*x,axis=0); grad[j]+=w.mean()
            ase=math.sqrt(float(grad@cov@grad))
            result['focal']={'estimate':float(ame),'se':ase,'lower':float(ame-crit*ase),'upper':float(ame+crit*ase)}
        else: result['focal']=coefs['util10']
    return result

def valid_controls(r): return all(r[v] is not None and math.isfinite(r[v]) for v in CONTROLS)
def summary(rows):
    return {'rows':len(rows),'units':len({r['key'] for r in rows}),'plants':len({r['plant'] for r in rows}),
            'exits':sum(r['exit12'] for r in rows if r['exit12'] is not None),
            'mean_mw':float(np.mean([r['capacity_mw'] for r in rows])) if rows else None,
            'mean_age':float(np.mean([r['age10']*10 for r in rows if r['age10'] is not None])) if rows else None,
            'coal_share':float(np.mean([r['coal'] for r in rows])) if rows else None}

def analyze(panel):
    base=[r for r in panel if r['exit12'] is not None and valid_controls(r)]
    sample=[r for r in base if r['util'] is not None]
    results={'risk':summary(panel),'eligible':summary(base),'covered':summary(sample),
        'uncovered':summary([r for r in base if r['util'] is None]),
        'coverage_reasons':dict(Counter(r['util_status'] for r in base)),
        'by_year':{str(y):summary([r for r in sample if r['year']==y]) for y in sorted({r['year'] for r in base})},
        'transitions_all':dict(Counter(r['transition'] for r in base)),
        'transitions_covered':dict(Counter(r['transition'] for r in sample)),
        'util_range':[min(r['util'] for r in sample),max(r['util'] for r in sample)],
        'unknown_outcomes':sum(r['exit12'] is None for r in panel)}
    models={}
    models['baseline_all']=fit(base,util=False)
    models['baseline_covered']=fit(sample,util=False)
    models['primary']=fit(sample)
    try: models['logit']=fit(sample,logit=True)
    except (ValueError,np.linalg.LinAlgError) as e: models['logit']={'failure':str(e)}
    for h in (6,24):
        ss=[r for r in panel if r[f'exit{h}'] is not None and r['util'] is not None and valid_controls(r)]
        models[f'horizon{h}']=fit(ss,outcome=f'exit{h}')
    earlier=[r for r in sample if r['util_earlier'] is not None]
    models['earlier_same_sample_current']=fit(earlier)
    models['earlier_operation']=fit(earlier,field='util_earlier')
    first={}
    for r in sorted(base,key=lambda r:r['origin']): first.setdefault(r['key'],r)
    models['first_origin']=fit([r for r in first.values() if r['util'] is not None])
    paired=[dict(r,postponed=int(r['transition']=='later')) for r in sample
            if r['transition'] in {'later','earlier','unchanged'}]
    if len({r['plant'] for r in paired})>=30 and sum(r['postponed'] for r in paired)>=10 and sum(1-r['postponed'] for r in paired)>=10:
        models['conditional_postponement']=fit(paired,outcome='postponed')
    else: models['conditional_postponement']={'not_fitted':'Prespecified sample/event threshold','n':len(paired)}
    lopo=[]
    for plant in sorted({r['plant'] for r in sample}):
        f=fit([r for r in sample if r['plant']!=plant])
        lopo.append({'omitted_plant':plant,'name':next(r['name'] for r in sample if r['plant']==plant),**f['focal']})
    results['lopo']={'n':len(lopo),'min':min(r['estimate'] for r in lopo),'max':max(r['estimate'] for r in lopo)}
    results['models']=models
    return results,lopo

def build():
    check_lock(); c=read(RAW/'contract.json')
    with (ROOT/c['cohort']).open(encoding='utf-8-sig',newline='') as f: cohort=list(csv.DictReader(f))
    panel,excluded=build_panel(cohort,read(ROOT/c['history']),read(ROOT/c['generation']),c)
    write(OUT/'panel.json',panel); write(OUT/'exclusions.json',excluded)
    results,lopo=analyze(panel)
    write(OUT/'results.json',results); write(OUT/'leave_one_plant_out.json',lopo)
    print(json.dumps({k:v for k,v in results.items() if k!='models'},indent=2))
    print(json.dumps({k:{x:v.get(x) for x in ('n','plants','events','focal','failure','outside_unit_interval')}
                      for k,v in results['models'].items()},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('mode',choices=['freeze','run','verify']); a=p.parse_args()
    if a.mode=='freeze': freeze()
    elif a.mode=='run': build()
    else: print('Unchanged inputs:',check_lock())
