"""Conditional annual project decisions; no identified policy welfare."""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import platform

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT/'data/raw/phase73'
OUT = ROOT/'data/processed/phase73'
RULES = ['initial_older','updated_older','initial_recent','updated_recent','persistence']


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def write(p, value):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8')


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def freeze():
    prior=read(ROOT/'data/raw/phase72/inputs.json')
    for r in prior:
        if sha(ROOT/r['path'])!=r['sha256']:raise ValueError('Prior lock changed:'+r['path'])
    names={r['path'] for r in prior}
    for folder in ['manuscript/ere_v4','author_review_ere_v4_2026-09-28','data/processed/phase72']:
        names.update(p.relative_to(ROOT).as_posix() for p in (ROOT/folder).rglob('*')
                     if p.is_file() and '__pycache__' not in p.parts)
    names.update(['data/raw/phase73/contract.json','tests/fixtures/phase73_decisions.json'])
    rows=[dict(path=p,sha256=sha(ROOT/p)) for p in sorted(names)]
    target=RAW/'inputs.json'
    if target.exists() and read(target)!=rows:raise ValueError('Phase73 freeze cannot be revised')
    write(target,rows)
    print('Frozen inputs:',len(rows),flush=True)


def check_lock():
    rows=read(RAW/'inputs.json')
    for r in rows:
        if sha(ROOT/r['path'])!=r['sha256']:raise ValueError('Changed input:'+r['path'])
    return len(rows)


def score(e,g,k,mu):
    if np.any(np.asarray(k)<=0):raise ValueError('Positive capacity required')
    return (np.asarray(e)-mu*np.asarray(g))/np.asarray(k)


def action(predicted,q):
    return np.asarray(predicted)>q


def loss(predicted,observed,q):
    if np.any(np.asarray(q)<0):raise ValueError('Negative cost outside contract')
    surplus=np.asarray(observed)-q
    return np.maximum(surplus,0)-action(predicted,q)*surplus


def pair_panels(net,carbon):
    def index(rows):
        out={(r['key'],r['year']):r for r in rows}
        if len(out)!=len(rows):raise ValueError('Duplicate unit-origin')
        return out
    gg=index(net);ee=index(carbon); out=[];ledger=[]
    contract=read(RAW/'contract.json')
    for key,e in sorted(ee.items()):
        g=gg.get(key); reasons=[]
        if g is None:reasons.append('no_net_match')
        else:
            for field in contract['pair_metadata']:
                if g[field]!=e[field]:reasons.append('metadata:'+field)
            if any(g[x]<0 for x in contract['exclude_negative']):reasons.append('negative_net')
            if any(not math.isfinite(g[x]) for x in contract['exclude_negative']):reasons.append('nonfinite_net')
        if any(e[x]<0 for x in contract['exclude_negative']):reasons.append('negative_co2')
        if any(not math.isfinite(e[x]) for x in contract['exclude_negative']):reasons.append('nonfinite_co2')
        if not math.isfinite(e['capacity_mw']) or e['capacity_mw']<=0:reasons.append('nonpositive_capacity')
        ledger.append(dict(key=key[0],year=key[1],reasons=reasons,eligible=not reasons))
        if reasons:continue
        fields=['key','year','plant','capacity_mw','fuel','outcome_year','origin',
                'initial_plan','current_plan','outcome_exit','strict_complete',
                'historical_identity_validated']
        row={k:e[k] for k in fields}
        row.update(g_actual=g['actual'],e_actual=e['actual'],
                   g_forecasts=g['forecasts'],e_forecasts=e['forecasts'])
        out.append(row)
    return out,ledger


def arrays(rows,mu):
    k=np.array([r['capacity_mw'] for r in rows])
    obs=score([r['e_actual'] for r in rows],[r['g_actual'] for r in rows],k,mu)
    p={b:score([r['e_forecasts'][b] for r in rows],[r['g_forecasts'][b] for r in rows],k,mu) for b in RULES}
    return p,obs,k


def summarize(predicted,observed,k,q):
    a=action(predicted,q);o=action(observed,q);l=loss(predicted,observed,q)
    return dict(loss_per_mw=float(np.dot(k,l)/k.sum()),
                loss_t_equivalent=float(np.dot(k,l)),
                selected_rows=int(a.sum()),reference_selected_rows=int(o.sum()),
                disagreement_rows=int((a!=o).sum()),
                false_positive_rows=int((a&~o).sum()),
                false_negative_rows=int((~a&o).sum()),
                disagreement_capacity_share=float(k[a!=o].sum()/k.sum()))


def frontier(preds,obs,k):
    q=np.unique(np.maximum(0,np.concatenate([obs,*preds.values()])))
    q=np.unique(np.r_[0.,q]);mid=(q[:-1]+q[1:])/2
    out=dict(q=q.tolist(),at_point={},left_limit={},right_limit={})
    # Decisions jump at forecast thresholds. Within each OPEN cost cell,
    # decisions are fixed; preserve distinct one-sided limits at boundaries.
    for b,p in preds.items():
        point=loss(p[:,None],obs[:,None],q)
        out['at_point'][b]=(k@point/k.sum()).tolist()
        a=action(p[:,None],mid)
        lm=k@loss(p[:,None],obs[:,None],mid)/k.sum()
        slope=k@(a.astype(float)-(obs[:,None]>mid))/k.sum()
        out['left_limit'][b]=(lm+slope*(q[:-1]-mid)).tolist()
        out['right_limit'][b]=(lm+slope*(q[1:]-mid)).tolist()
    return out


def sign_regions(q,left,right):
    out=[]
    for lo,hi,dl,dr in zip(q[:-1],q[1:],left,right):
        points=[lo,hi]
        if dl*dr<0:points.insert(1,lo+(hi-lo)*(-dl)/(dr-dl))
        for a,b in zip(points[:-1],points[1:]):
            d=dl+(dr-dl)*((a+b)/2-lo)/(hi-lo)
            label='equal' if abs(d)<1e-9 else ('updated_lower' if d<0 else 'persistence_lower')
            if out and out[-1]['label']==label and math.isclose(out[-1]['hi'],a,abs_tol=1e-9):
                out[-1]['hi']=float(b)
            else:out.append(dict(lo=float(a),hi=float(b),label=label))
    return out


def group_rows(rows):
    groups={'all':rows,'coal':[r for r in rows if r['fuel']=='coal'],
            'gas':[r for r in rows if r['fuel']=='gas'],
            'future_initial':[r for r in rows if r['initial_plan']>r['origin']]}
    for y in sorted({r['outcome_year'] for r in rows}):
        groups['year_'+str(y)]=[r for r in rows if r['outcome_year']==y]
    first={}
    for r in sorted(rows,key=lambda r:(r['year'],r['key'])):first.setdefault(r['key'],r)
    groups['first_origin']=list(first.values())
    return {k:v for k,v in groups.items() if v}


def errors(rows):
    out={}
    for field in ['g','e']:
        actual=np.array([r[field+'_actual'] for r in rows])
        out[field]={}
        for b in RULES:
            p=np.array([r[field+'_forecasts'][b] for r in rows])
            out[field][b]=dict(mae=float(np.abs(p-actual).mean()),
                             wape=float(np.abs(p-actual).sum()/np.abs(actual).sum()),
                             bias=float((p-actual).sum()))
    return out


def resampling(rows,mu_values,q_values,contract):
    plants=sorted({r['plant'] for r in rows});ng=len(plants)
    ids=np.array([plants.index(r['plant']) for r in rows])
    k=np.array([r['capacity_mw'] for r in rows])
    ks=np.bincount(ids,weights=k,minlength=ng)
    rng=np.random.default_rng(contract['seed'])
    draws=rng.multinomial(ng,np.ones(ng)/ng,size=contract['draws'])
    den=draws@ks;out=[]
    for mu in mu_values:
        preds,obs,_=arrays(rows,mu)
        for q in q_values:
            for comp in ['initial_older','persistence']:
                improvement=loss(preds[comp],obs,q)-loss(preds['updated_recent'],obs,q)
                totals=np.bincount(ids,weights=k*improvement,minlength=ng)
                boot=(draws@totals)/den
                lopo=(totals.sum()-totals)/(ks.sum()-ks)
                out.append(dict(mu=mu,q=q,comparator=comp,
                                improvement=float(totals.sum()/ks.sum()),
                                ci95=np.percentile(boot,[2.5,97.5]).tolist(),
                                lopo_min=float(lopo.min()),lopo_max=float(lopo.max()),
                                lopo_positive=int((lopo>1e-9).sum()),plants=ng))
    return out


def calculate():
    c=read(RAW/'contract.json')
    net=read(ROOT/c['net_panel']);carbon=read(ROOT/c['carbon_panel'])
    rows,ledger=pair_panels(net,carbon);groups=group_rows(rows)
    scores=[];frontiers=[];points=[];intervals=[]
    for mu in c['replacement_intensity_t_per_mwh']:
        p,o,k=arrays(rows,mu)
        for i,r in enumerate(rows):
            scores.append(dict(key=r['key'],year=r['year'],mu=mu,
                               observed=float(o[i]),**{b:float(p[b][i]) for b in RULES}))
        for name,subset in groups.items():
            sp,so,sk=arrays(subset,mu);f=frontier(sp,so,sk)
            dl=np.array(f['left_limit']['updated_recent'])-f['left_limit']['persistence']
            dr=np.array(f['right_limit']['updated_recent'])-f['right_limit']['persistence']
            f.update(mu=mu,group=name,n=len(subset),
                     regions_updated_vs_persistence=sign_regions(f['q'],dl,dr),
                     beyond_last='all rules choose no intervention; loss=0')
            frontiers.append(f)
        for q in c['uncertainty_q']:
            if mu not in c['uncertainty_mu']:continue
            for name,subset in groups.items():
                sp,so,sk=arrays(subset,mu)
                points.append(dict(mu=mu,q=q,group=name,n=len(subset),
                                   rules={b:summarize(sp[b],so,sk,q) for b in RULES}))
        for i,r in enumerate(rows):
            thresholds=[p[b][i] for b in RULES];lo=max(0,min(thresholds));hi=max(0,max(thresholds))
            intervals.append(dict(key=r['key'],year=r['year'],mu=mu,lo=float(lo),hi=float(hi),
                                  width=float(hi-lo),capacity_mw=r['capacity_mw']))
    counts=Counter(r['fuel'] for r in rows)
    shares={}
    for r in rows:shares[r['plant']]=shares.get(r['plant'],0)+r['capacity_mw']
    total=sum(shares.values())
    coverage=dict(net_rows=len(net),carbon_rows=len(carbon),paired_rows=len(rows),
                  units=len({r['key'] for r in rows}),plants=len(shares),fuel=dict(counts),
                  exits=sum(r['outcome_exit'] for r in rows),
                  strict_complete=sum(r['strict_complete'] for r in rows),
                  historically_validated_links=sum(r['historical_identity_validated'] for r in rows),
                  capacity_mw_year_sum=total,
                  observed_net_twh=sum(r['g_actual'] for r in rows)/1e6,
                  observed_co2_mt=sum(r['e_actual'] for r in rows)/1e6,
                  group_sizes={g:len(v) for g,v in groups.items()},
                  plant_capacity_shares=sorted([dict(plant=p,share=k/total) for p,k in shares.items()],key=lambda r:-r['share']))
    return dict(panel=rows,coverage_ledger=ledger,coverage=coverage,scores=scores,
                decision_intervals=intervals,frontiers=frontiers,fixed_points=points,
                paired_errors={g:errors(s) for g,s in groups.items()},
                uncertainty=resampling(rows,c['uncertainty_mu'],c['uncertainty_q'],c['bootstrap']))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=['freeze','run','verify'],required=True)
    args=parser.parse_args()
    if args.mode=='freeze':freeze();return
    locked=check_lock();products=calculate()
    for name,data in products.items():
        target=OUT/(name+'.json')
        if args.mode=='verify':
            if read(target)!=data:raise ValueError('Reproduction mismatch:'+name)
        else:write(target,data)
    if args.mode=='run':
        write(ROOT/'outputs/phase73/environment.json',dict(python=platform.python_version(),
              numpy=np.__version__,platform=platform.platform(),protected_files=locked,
              products=len(products),source_sha256=sha(Path(__file__))))
    print(json.dumps(dict(mode=args.mode,products=len(products),protected=locked,
                          coverage=products['coverage']),indent=2))


if __name__=='__main__':
    main()
